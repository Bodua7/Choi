// TAB4.2: Mở Rộng Căn Cứ

export const BASE_STRUCTURES = {
    TURRET_CANH_GAC: {
        id: 'TURRET_CANH_GAC',
        name: 'Tháp Súng Canh Gác',
        description: 'Tự động khai hỏa phòng thủ khi bị Thú Triều quấy nhiễu'
    },
    XUONG_PHAN_RA_TAI_CHE: {
        id: 'XUONG_PHAN_RA_TAI_CHE',
        name: 'Xưởng Phân Rã & Tái Chế',
        recycleRate: 0.7 // hoàn 70% nguyên liệu cơ bản
    },
    TRAN_PHAP_HO_THANH: {
        id: 'TRAN_PHAP_HO_THANH',
        name: 'Trận Pháp Hộ Thành',
        description: 'Tăng lượng giáp ảo che chắn cho toàn bộ hệ thống phòng thủ'
    },
    TRAM_RADAR_TRINH_SAT: {
        id: 'TRAM_RADAR_TRINH_SAT',
        name: 'Trạm Radar Trinh Sát',
        description: 'Tăng % tỉ lệ rớt vật liệu tier Vàng (Thần Cấp) khi Càn Quét'
    },
    LO_NANG_LUONG_TONG: {
        id: 'LO_NANG_LUONG_TONG',
        name: 'Lò Năng Lượng Tổng',
        description: 'Miễn phí chi phí Tinh Thể Biến Dị khi tung Combo Tuyệt Kỹ'
    }
};

/** Xưởng Phân Rã & Tái Chế: đưa vật liệu/trang bị cũ vào, thu hồi 70% nguyên liệu cơ bản (làm tròn xuống). */
export function recycleItem(baseMaterialCost) {
    const recovered = {};
    for (const [mat, qty] of Object.entries(baseMaterialCost)) {
        recovered[mat] = Math.floor(qty * BASE_STRUCTURES.XUONG_PHAN_RA_TAI_CHE.recycleRate);
    }
    return recovered;
}

// GIẢ ĐỊNH: Trận Pháp Hộ Thành cộng +5% giáp ảo mỗi cấp — GDD không cho số cụ thể.
const SHIELD_PERCENT_PER_LEVEL = 0.05;

/** Trận Pháp Hộ Thành: % giáp ảo cộng thêm cho toàn hệ thống phòng thủ theo cấp độ. */
export function getVirtualShieldBonus(level) {
    return level * SHIELD_PERCENT_PER_LEVEL;
}

/** Tháp Súng Canh Gác: chỉ kích hoạt tự động khi Căn Cứ đang bị Thú Triều quấy nhiễu. */
export function isTurretActive(isUnderHordeAttack) {
    return Boolean(isUnderHordeAttack);
}
