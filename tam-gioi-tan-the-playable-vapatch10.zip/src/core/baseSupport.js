// TAB2.2: Cơ Chế Phối Hợp Căn Cứ Vào Trận Đánh

export const BASE_SUPPORT = {
    TRAN_PHAP_HO_CAN_CU: {
        id: 'TRAN_PHAP_HO_CAN_CU',
        name: 'Trận Pháp Hộ Căn Cứ',
        owner: 'HAN_LAP',
        minMitigation: 0.20,
        maxMitigation: 0.40
    },
    TURRET: {
        id: 'TURRET',
        name: 'Tháp Súng Tự Động / Turret',
        owner: 'BAO',
        fireIntervalSeconds: 1.5
    },
    RAO_CHAN_SAT_DOC: {
        id: 'RAO_CHAN_SAT_DOC',
        name: 'Rào Chắn Bọc Thép Sát Độc',
        owner: 'A_TUN',
        autoCollect: true
    },
    LO_NANG_LUONG_TONG: {
        id: 'LO_NANG_LUONG_TONG',
        name: 'Lò Năng Lượng Tổng',
        owner: null, // dùng chung cho cả 3 Main
        grantsFreeUlti: true
    }
};

/** Trận Pháp Hộ Căn Cứ: % giảm dmg nhận theo cấp độ trận pháp, nội suy 20%→40%. */
export function getTranPhapMitigation(level, maxLevel = 10) {
    const clamped = Math.max(0, Math.min(1, level / maxLevel));
    const { minMitigation, maxMitigation } = BASE_SUPPORT.TRAN_PHAP_HO_CAN_CU;
    return minMitigation + (maxMitigation - minMitigation) * clamped;
}

/** Turret: số lượt bắn được trong khoảng thời gian elapsedSeconds (chu kỳ 1.5s). */
export function getTurretShotsFired(elapsedSeconds) {
    return Math.floor(elapsedSeconds / BASE_SUPPORT.TURRET.fireIntervalSeconds);
}

/** Rào Chắn Sát Độc: tự động gộp tài nguyên rớt ra sau 1 wave, không cần thao tác thủ công. */
export function autoCollectFromWave(dropsList) {
    const collected = {};
    for (const drop of dropsList) {
        collected[drop.name] = (collected[drop.name] || 0) + drop.qty;
    }
    return collected;
}

/** Lò Năng Lượng Tổng: cho phép tung Ulti miễn phí mana cá nhân nếu còn Lõi Năng Lượng. */
export function canCastUltiFree(hasEnergyCore = true) {
    return BASE_SUPPORT.LO_NANG_LUONG_TONG.grantsFreeUlti && hasEnergyCore;
}
