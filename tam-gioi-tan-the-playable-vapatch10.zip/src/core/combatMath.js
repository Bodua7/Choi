// TAB10: Công Thức Tính Sát Thương & Math Model.
// Damage_Thực = Damage_CơBản * (1000 / (1000 + DEF - ArmorPen)) * (1 + CritDamage) * (1 - Resist)

/**
 * @param {number} baseDamage   Damage_CơBản
 * @param {number} def          DEF của mục tiêu
 * @param {number} armorPen     ArmorPen của người đánh (0 nếu không có)
 * @param {number} critDamage   hệ số cộng thêm khi chí mạng, vd 0.5 = +50% (0 nếu không chí mạng)
 * @param {number} resist       kháng của mục tiêu, dạng tỉ lệ 0..1
 */
export function calcDamage(baseDamage, def, armorPen = 0, critDamage = 0, resist = 0) {
    const effectiveDef = Math.max(0, def - armorPen);
    const defMitigation = 1000 / (1000 + effectiveDef);
    const raw = baseDamage * defMitigation * (1 + critDamage) * (1 - resist);
    return Math.max(0, raw);
}

// Bảng mốc Lv1 / Lv100 lấy đúng từ TAB10 — dùng làm 2 đầu mút để nội suy.
// GIẢ ĐỊNH: nội suy TUYẾN TÍNH giữa Lv1 và Lv100 (đường cong đơn giản nhất, dễ cân bằng
// ban đầu). Nếu muốn tăng chậm đầu/nhanh cuối (hoặc ngược lại) có thể đổi CURVE_EXPONENT
// bên dưới (1 = tuyến tính, >1 = tăng chậm rồi vọt cuối, <1 = tăng nhanh đầu rồi chậm lại).
const CURVE_EXPONENT = 1;

const STAT_TABLE = {
    A_TUN: {
        hp:  { lv1: 500, lv100: 80000 },
        atk: { lv1: 45,  lv100: 6500 },
        def: { lv1: 20,  lv100: 2500 }
    },
    BAO: {
        hp:   { lv1: 350, lv100: 55000 },
        atk:  { lv1: 60,  lv100: 9500 },
        def:  { lv1: 15,  lv100: 350 },   // VÁ #22: thêm mới, xem ghi chú trên
        crit: { lv1: 0.05, lv100: 0.75 } // Crit Rate: 5% -> 75%
    },
    HAN_LAP: {
        hp:  { lv1: 300, lv100: 45000 },
        mp:  { lv1: 200, lv100: 25000 },
        atk: { lv1: 50,  lv100: 8000 },
        def: { lv1: 15,  lv100: 2000 }   // VÁ #22: thêm mới, xem ghi chú trên
    }
};

/**
 * Nội suy chỉ số của nhân vật tại 1 level bất kỳ (1-100) giữa mốc Lv1 và Lv100.
 * @param {string} charId    'A_TUN' | 'BAO' | 'HAN_LAP'
 * @param {string} statName  vd 'hp', 'atk', 'def', 'crit', 'mp'
 * @param {number} level     1-100
 */
export function scaleStat(charId, statName, level) {
    const stat = STAT_TABLE[charId]?.[statName];
    if (!stat) throw new Error(`Không có dữ liệu chỉ số '${statName}' cho ${charId}`);
    const clamped = Math.max(1, Math.min(100, level));
    const progress = (clamped - 1) / 99; // 0 tại Lv1, 1 tại Lv100
    const curved = Math.pow(progress, CURVE_EXPONENT);
    return stat.lv1 + (stat.lv100 - stat.lv1) * curved;
}

/** Trả về toàn bộ chỉ số trọng tâm của nhân vật tại 1 level, dạng object. */
export function getStatsAtLevel(charId, level) {
    const keys = Object.keys(STAT_TABLE[charId] || {});
    const result = {};
    for (const key of keys) {
        result[key] = scaleStat(charId, key, level);
    }
    return result;
}
