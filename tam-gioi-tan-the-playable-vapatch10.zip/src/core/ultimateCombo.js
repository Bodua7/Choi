// TAB2.3: Chuỗi Combo Tuyệt Kỹ Phối Hợp Dồn Sát Thương (Ultimate Synergy)

export const ULTIMATE_COMBO_STEPS = [
    {
        step: 1,
        actor: 'HAN_LAP',
        name: 'Chân Ngôn Bảo Luân',
        effect: 'freeze_battlefield',
        durationSeconds: 5,
        description: 'Đóng băng thời gian toàn chiến trường trong 5s, ngắt chiêu của Boss'
    },
    {
        step: 2,
        actor: 'A_TUN',
        name: 'Chiến Hạm Phân Rã',
        effect: 'armor_shred',
        armorReductionBP: 0.5,
        resistReductionBP: 0.5,
        description: 'Phóng Trường Sát Độc Tối Cao, bào mòn 50% Giáp và Kháng tính của Boss'
    },
    {
        step: 3,
        actor: 'BAO_AND_BASE',
        name: 'Pháo Plasma Hạt Nhân',
        effect: 'burst_damage',
        critDamageBonus: 10.0, // +1000%
        description: 'Khóa mục tiêu định vị, khai hỏa gây 1000% Sát thương Bạo kích trực tiếp'
    },
    {
        step: 4,
        actor: 'HAN_LAP_AND_A_TUN',
        name: 'Phạn Thánh Chân Ma Thể & Thần Phạt Cơ Khí',
        effect: 'finisher_barrage',
        description: 'Dội bão tên lửa dồn sát thương kết liễu'
    }
];

/**
 * Thực thi toàn bộ chuỗi combo 4 bước lên 1 boss.
 * GIẢ ĐỊNH: Bước 4 (đòn kết liễu) gây sát thương gấp đôi Bước 3 để mô phỏng "bão tên lửa
 * dồn sát thương" — GDD không cho công thức riêng cho bước này.
 * @param {object} boss  { hp, armor, resist }
 * @param {number} baseHitDamage  sát thương gốc dùng cho Bước 3 (trước khi nhân crit)
 */
export function runUltimateCombo(boss, baseHitDamage) {
    let armor = boss.armor;
    let resist = boss.resist || 0;
    let hp = boss.hp;
    const log = [];

    // Bước 1: không gây dmg trực tiếp, chỉ đóng băng + ngắt chiêu
    log.push({ step: 1, name: ULTIMATE_COMBO_STEPS[0].name, effect: 'boss bị đóng băng 5s, ngắt chiêu' });

    // Bước 2: bào mòn giáp/kháng
    const step2 = ULTIMATE_COMBO_STEPS[1];
    armor *= (1 - step2.armorReductionBP);
    resist *= (1 - step2.resistReductionBP);
    log.push({ step: 2, name: step2.name, armorAfter: armor, resistAfter: resist });

    // Bước 3: sát thương bùng nổ +1000% crit
    const step3 = ULTIMATE_COMBO_STEPS[2];
    const defMitigation = 1000 / (1000 + armor);
    const step3Damage = baseHitDamage * defMitigation * (1 + step3.critDamageBonus) * (1 - resist);
    hp -= step3Damage;
    log.push({ step: 3, name: step3.name, damageDealt: step3Damage, hpRemaining: Math.max(0, hp) });

    // Bước 4: đòn kết liễu
    const step4Damage = step3Damage * 2;
    hp -= step4Damage;
    log.push({ step: 4, name: ULTIMATE_COMBO_STEPS[3].name, damageDealt: step4Damage, hpRemaining: Math.max(0, hp) });

    return { totalDamage: step3Damage + step4Damage, finalHp: Math.max(0, hp), win: hp <= 0, log };
}
