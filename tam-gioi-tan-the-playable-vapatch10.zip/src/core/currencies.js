// TAB7.1: Tiền Tệ & Năng Lượng.
// 4 loại: Phế Liệu Sắt (base), Linh Thạch 3 cấp (Hạ/Trung/Cao), Tinh Thể Biến Dị,
// Lõi Đồng Hóa. GDD không nêu công dụng riêng từng loại theo hàm số — quy ước dưới đây
// (nguồn gốc + vai trò gợi ý) là GIẢ ĐỊNH hợp lý để nối vào combat/enhancement/rebirth,
// cần bạn xác nhận nếu muốn gán khác.

export const CURRENCIES = {
    PHE_LIEU_SAT: {
        id: 'PHE_LIEU_SAT',
        name: 'Phế Liệu Sắt',
        desc: 'Tiền tệ nền tảng, rớt từ Đánh Thường, dùng chế tạo trang bị thường.'
    },
    LINH_THACH_HA: {
        id: 'LINH_THACH_HA',
        name: 'Linh Thạch Hạ Cấp',
        desc: 'Rớt từ Đột Phá Vòng Vây, dùng cường hóa +1..+5.'
    },
    LINH_THACH_TRUNG: {
        id: 'LINH_THACH_TRUNG',
        name: 'Linh Thạch Trung Cấp',
        desc: 'Rớt từ Boss SSS / Wave lớn, dùng cường hóa +6..+8.'
    },
    LINH_THACH_CAO: {
        id: 'LINH_THACH_CAO',
        name: 'Linh Thạch Cao Cấp',
        desc: 'Hiếm, dùng cường hóa +9..+10 và công thức [THẦN CẤP].'
    },
    TINH_THE_BIEN_DI: {
        id: 'TINH_THE_BIEN_DI',
        name: 'Tinh Thể Biến Dị',
        desc: 'Rớt từ Boss SSS, dùng làm điều kiện đột phá mốc tiến hóa.'
    },
    LOI_DONG_HOA: {
        id: 'LOI_DONG_HOA',
        name: 'Lõi Đồng Hóa',
        desc: 'Vật liệu hiếm nhất, dùng cho Trọng Sinh Vô Cực + đột phá mốc 5.'
    }
};

export const CURRENCY_IDS = Object.keys(CURRENCIES);

/** Tạo 1 ví trống, tất cả currency = 0. */
export function createWallet() {
    const wallet = {};
    for (const id of CURRENCY_IDS) wallet[id] = 0;
    return wallet;
}

/** Cộng thêm tiền tệ vào ví (không âm). */
export function addCurrency(wallet, currencyId, amount) {
    if (!CURRENCIES[currencyId]) throw new Error(`Không tìm thấy tiền tệ: ${currencyId}`);
    wallet[currencyId] = (wallet[currencyId] || 0) + Math.max(0, amount);
    return wallet;
}

/** Kiểm tra ví có đủ 1 tập hợp chi phí { currencyId: amount, ... } không. */
export function canAfford(wallet, cost) {
    return Object.entries(cost).every(([id, amt]) => (wallet[id] || 0) >= amt);
}

/** Trừ tiền theo cost nếu đủ, trả về true/false; không trừ nếu thiếu bất kỳ loại nào. */
export function spendCurrency(wallet, cost) {
    if (!canAfford(wallet, cost)) return false;
    for (const [id, amt] of Object.entries(cost)) {
        wallet[id] -= amt;
    }
    return true;
}
