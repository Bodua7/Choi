import { calcDamage } from './combatMath.js';

// TAB2.1: Các Chế Độ Chiến Đấu

/** Đánh Thường (Càn Quét Dã Ngoại): diệt toán quái lẻ, không cơ chế đặc biệt. */
export function normalScavenge({ atk, armorPen = 0, critDamage = 0 }, { def, resist = 0, hp }) {
    const dmg = calcDamage(atk, def, armorPen, critDamage, resist);
    const hitsToKill = dmg > 0 ? Math.ceil(hp / dmg) : Infinity;
    return { damagePerHit: dmg, hitsToKill, win: dmg > 0 };
}

/**
 * Đột Phá Vòng Vây (Thú Triều / Zombie Horde): Căn Cứ chịu nhiều wave liên tiếp.
 * @param {number} baseHp        HP hiện tại của Căn Cứ
 * @param {Array<{count:number, dmgPerEnemy:number}>} waves  mỗi wave: số quái x dmg/con
 * @param {number} mitigationBP  % giảm dmg nhận (0-1), lấy từ baseSupport.getTranPhapMitigation
 */
export function runHordeDefense(baseHp, waves, mitigationBP = 0) {
    let hp = baseHp;
    const log = [];
    for (const wave of waves) {
        const rawDamage = wave.count * wave.dmgPerEnemy;
        const mitigated = rawDamage * (1 - mitigationBP);
        hp -= mitigated;
        log.push({ enemiesCount: wave.count, rawDamage, mitigated, hpRemaining: Math.max(0, hp) });
        if (hp <= 0) break;
    }
    return { survived: hp > 0, finalHp: Math.max(0, hp), log };
}

const ARMOR_BREAK_HIT_COUNT = 5; // GIẢ ĐỊNH: phá giáp sau 5 đòn liên tiếp
const ARMOR_BREAK_REDUCTION = 0.5; // -50% giáp khi phá giáp

/**
 * Quyết Chiến Thảm Họa (Boss SSS): cơ chế phá giáp sau N đòn + ngắt chiêu khi 1 đòn vượt ngưỡng.
 * @param {object} boss  { hp, armor, resist, castThreshold? }
 * @param {number[]} hits  damage thô (chưa trừ giáp/kháng) của từng đòn liên tiếp
 */
export function runBossFight(boss, hits) {
    let hp = boss.hp;
    let armor = boss.armor;
    let armorBroken = false;
    let interrupted = false;
    let totalDealt = 0;
    const log = [];

    hits.forEach((rawHit, i) => {
        if (i + 1 >= ARMOR_BREAK_HIT_COUNT && !armorBroken) {
            armor = armor * (1 - ARMOR_BREAK_REDUCTION);
            armorBroken = true;
        }
        const dealt = calcDamage(rawHit, armor, 0, 0, boss.resist || 0);
        hp -= dealt;
        totalDealt += dealt;
        if (!interrupted && boss.castThreshold != null && dealt >= boss.castThreshold) {
            interrupted = true;
        }
        log.push({ hitIndex: i, dealt, hpRemaining: Math.max(0, hp), armorBroken, interrupted });
        if (hp <= 0) return;
    });

    return { win: hp <= 0, finalHp: Math.max(0, hp), totalDealt, armorBroken, interrupted, log };
}
