// TAB7.3: Vòng Lặp Gameplay — Ban ngày (15 phút, Càn quét/đào quặng)
// -> Ban đêm (5 phút, Thủ thành) -> tự chuyển pha, lặp lại.

export const PHASES = {
    DAY: { id: 'DAY', name: 'Ban Ngày (Càn Quét / Đào Quặng)', durationSeconds: 15 * 60 },
    NIGHT: { id: 'NIGHT', name: 'Ban Đêm (Thủ Thành)', durationSeconds: 5 * 60 }
};

const PHASE_ORDER = ['DAY', 'NIGHT'];

/** Tạo trạng thái vòng lặp mới, bắt đầu ở Ban Ngày, cycle 1. */
export function createLoopState(now = Date.now()) {
    return {
        phaseId: 'DAY',
        phaseStartedAt: now,
        cycle: 1
    };
}

/** Giây đã trôi qua trong pha hiện tại. */
export function getElapsedInPhase(loopState, now = Date.now()) {
    return Math.max(0, (now - loopState.phaseStartedAt) / 1000);
}

/** Giây còn lại trước khi tự chuyển pha. */
export function getRemainingInPhase(loopState, now = Date.now()) {
    const duration = PHASES[loopState.phaseId].durationSeconds;
    return Math.max(0, duration - getElapsedInPhase(loopState, now));
}

/**
 * Tick vòng lặp: nếu pha hiện tại đã hết giờ, tự chuyển sang pha kế tiếp
 * (DAY -> NIGHT -> DAY, cycle+1 mỗi khi quay lại DAY). Trả về loopState mới
 * (cùng tham chiếu, mutate tại chỗ) + cờ `changed` báo có vừa chuyển pha hay không,
 * để caller biết lúc nào cần bắn event (vd. bật/tắt Wave Thú Triều).
 */
export function tickGameLoop(loopState, now = Date.now()) {
    const remaining = getRemainingInPhase(loopState, now);
    if (remaining > 0) {
        return { loopState, changed: false, previousPhase: null };
    }

    const currentIndex = PHASE_ORDER.indexOf(loopState.phaseId);
    const nextIndex = (currentIndex + 1) % PHASE_ORDER.length;
    const previousPhase = loopState.phaseId;
    loopState.phaseId = PHASE_ORDER[nextIndex];
    loopState.phaseStartedAt = now;
    if (loopState.phaseId === 'DAY') {
        loopState.cycle += 1;
    }

    return { loopState, changed: true, previousPhase };
}

/** true nếu đang ở pha Ban Đêm (Thủ Thành) — dùng để bật Đột Phá Vòng Vây/Turret. */
export function isNightPhase(loopState) {
    return loopState.phaseId === 'NIGHT';
}

/** true nếu đang ở pha Ban Ngày (Càn Quét/Đào Quặng) — dùng để bật Đánh Thường/loot. */
export function isDayPhase(loopState) {
    return loopState.phaseId === 'DAY';
}

/** % tiến độ pha hiện tại (0-1), dùng cho thanh progress trên UI. */
export function getPhaseProgress(loopState, now = Date.now()) {
    const duration = PHASES[loopState.phaseId].durationSeconds;
    return Math.min(1, getElapsedInPhase(loopState, now) / duration);
}
