import { CHARACTER_IDS } from './content/characters.js';
import { isStoryComplete } from './content/story.js';
import { createEmptyLoadout, EQUIPMENT_SLOTS } from './content/equipmentSlots.js';

// TAB12: Cơ Chế Trọng Sinh Vô Cực (Prestige System).
//
// GIẢ ĐỊNH quan trọng (GDD không định nghĩa rõ, cần bạn xác nhận):
// 1. "Đồ Tím/Vàng" (giữ lại khi Trọng Sinh) được hiểu theo cùng thang màu 4-tier
//    (Trắng/Xanh/Tím/Vàng) đã dùng cho vật liệu ở materials.js — mỗi item trang bị cần có
//    field `rarityTier` (0=Trắng..3=Vàng) để hàm resetForRebirth biết cái nào giữ/bỏ.
//    Item không có field này (undefined) bị coi là KHÔNG giữ (an toàn, tránh giữ nhầm đồ
//    thường mặc định).
// 2. "Chân Ngôn Luân Hồi Kính" là vật phẩm tiêu hao dùng 1 lần mỗi lần Trọng Sinh — không
//    nằm trong currencies.js (đó là 6 loại tiền tệ/nguyên liệu tích lũy), nên state cần có
//    field riêng `luanHoiKinhCount` (số lượng vật phẩm đang có).

export const MAX_REBIRTH_COUNT = 100;
export const BUFF_PER_REBIRTH = 0.01; // +1% mỗi lần

const KEEP_RARITY_MIN_TIER = 2; // Tím (2) trở lên mới giữ lại

/**
 * Kiểm tra đủ điều kiện Trọng Sinh chưa.
 * `state` = {
 *   charLevels: { A_TUN, BAO, HAN_LAP },
 *   luanHoiKinhCount: number
 * }
 */
export function canRebirth(state) {
    const allMaxLevel = CHARACTER_IDS.every(id => (state.charLevels[id] ?? 0) >= 100);
    if (!allMaxLevel) {
        return { ok: false, reason: 'Cần cả 3 Main đạt Lv100.' };
    }
    if (!isStoryComplete(state.charLevels)) {
        return { ok: false, reason: 'Cần hoàn thành Chương V (Quy Tụ Vô Cực).' };
    }
    if ((state.luanHoiKinhCount ?? 0) < 1) {
        return { ok: false, reason: 'Cần có Chân Ngôn Luân Hồi Kính.' };
    }
    return { ok: true };
}

/** Lọc 1 bộ trang bị (loadout theo equipmentSlots.js), chỉ giữ item Tím/Vàng trở lên. */
function filterKeptLoadout(charId, loadout) {
    const kept = createEmptyLoadout(charId);
    const slots = EQUIPMENT_SLOTS[charId];
    for (const slot of slots) {
        const item = loadout?.[slot];
        if (item && typeof item.rarityTier === 'number' && item.rarityTier >= KEEP_RARITY_MIN_TIER) {
            kept[slot] = item;
        }
    }
    return kept;
}

/**
 * Thực hiện Trọng Sinh: kiểm tra lại điều kiện, rồi trả về state MỚI (không mutate input).
 * `fullState` = {
 *   charLevels, luanHoiKinhCount,
 *   loadouts: { A_TUN, BAO, HAN_LAP },      // trang bị hiện tại từng Main
 *   reputation,                              // giữ nguyên (Danh Vọng)
 *   knownRecipeIds,                          // giữ nguyên (Công Thức)
 *   base,                                    // sẽ bị reset (Căn Cứ)
 *   rebirthCount                             // số lần đã Trọng Sinh trước đó
 * }
 */
export function performRebirth(fullState) {
    const check = canRebirth(fullState);
    if (!check.ok) return check;

    const newLoadouts = {};
    for (const charId of CHARACTER_IDS) {
        newLoadouts[charId] = filterKeptLoadout(charId, fullState.loadouts?.[charId]);
    }

    const newCharLevels = {};
    for (const charId of CHARACTER_IDS) newCharLevels[charId] = 1;

    const newRebirthCount = Math.min(MAX_REBIRTH_COUNT, (fullState.rebirthCount ?? 0) + 1);

    return {
        ok: true,
        state: {
            charLevels: newCharLevels,               // Reset Level 1
            loadouts: newLoadouts,                    // Giữ Đồ Tím/Vàng, bỏ phần còn lại
            reputation: fullState.reputation,          // Giữ nguyên Danh Vọng
            knownRecipeIds: fullState.knownRecipeIds,  // Giữ nguyên Công Thức
            base: {},                                  // Reset Căn Cứ
            luanHoiKinhCount: (fullState.luanHoiKinhCount ?? 1) - 1, // tiêu hao 1 vật phẩm
            rebirthCount: newRebirthCount
            // Tiến trình Cốt truyện không cần field riêng để reset — story.js suy ra
            // Chương hiện tại trực tiếp từ charLevels, nên charLevels về 1 tự động đưa
            // về Chương I.
        }
    };
}

/** Hệ số buff vĩnh viễn hiện tại (1.0 = chưa Trọng Sinh, 2.0 = Trọng Sinh 100 lần = +100%). */
export function getRebirthBuffMultiplier(rebirthCount = 0) {
    const clamped = Math.max(0, Math.min(MAX_REBIRTH_COUNT, rebirthCount));
    return 1 + clamped * BUFF_PER_REBIRTH;
}

/**
 * Áp hệ số buff Trọng Sinh lên 1 bộ chỉ số cho trước — theo đúng 4 mục TAB12 nêu:
 * Toàn bộ Chỉ số Gốc, Sát thương, Tốc độ rớt đồ, Độ bền Căn cứ.
 * @param {{baseStats:number, damage:number, dropRate:number, baseDurability:number}} values
 */
export function applyRebirthBuff(values, rebirthCount = 0) {
    const mult = getRebirthBuffMultiplier(rebirthCount);
    return {
        baseStats: values.baseStats * mult,
        damage: values.damage * mult,
        dropRate: values.dropRate * mult,
        baseDurability: values.baseDurability * mult
    };
}
