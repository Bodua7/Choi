// TAB9.2-9.3: Cường Hóa (+1 đến +10) & Mốc Thuộc Tính Ẩn.
// GDD chỉ neo 2 điểm: +1..+3 = 100%, +10 = 15%. Đường cong giữa là GIẢ ĐỊNH hợp lý
// (giảm dần đều đặn hơn ở giữa) — chỉnh SUCCESS_RATES nếu muốn cân bằng khác.

export const SUCCESS_RATES = {
    1: 1.00, 2: 1.00, 3: 1.00,
    4: 0.80, 5: 0.70, 6: 0.60,
    7: 0.45, 8: 0.35, 9: 0.25,
    10: 0.15
};

export const MAX_ENHANCE_LEVEL = 10;

// Mốc thuộc tính ẩn: +5 (dòng ẩn 1), +8 (dòng ẩn 2), +10 (Thần Giới -10% Cooldown)
export const HIDDEN_LINE_THRESHOLDS = [5, 8, 10];

/**
 * Thử cường hóa 1 bậc, từ currentLevel -> currentLevel+1.
 * @param {number} currentLevel        cấp cường hóa hiện tại (0-9)
 * @param {boolean} hasProtectionStone  có Đá Bảo Hộ hay không (chống vỡ đồ khi fail)
 * @param {Function} rng                nguồn random, mặc định Math.random
 * @returns {{success:boolean, newLevel:number, broken:boolean, hiddenLineUnlocked:boolean}}
 */
export function attemptEnhance(currentLevel, hasProtectionStone = false, rng = Math.random) {
    if (currentLevel >= MAX_ENHANCE_LEVEL) {
        throw new Error(`Đã đạt cấp cường hóa tối đa +${MAX_ENHANCE_LEVEL}`);
    }
    const targetLevel = currentLevel + 1;
    const rate = SUCCESS_RATES[targetLevel];
    const success = rng() < rate;

    if (success) {
        return {
            success: true,
            newLevel: targetLevel,
            broken: false,
            hiddenLineUnlocked: HIDDEN_LINE_THRESHOLDS.includes(targetLevel)
        };
    }

    // Fail: vỡ đồ (mất trắng, về level 0) trừ khi có Đá Bảo Hộ (giữ nguyên level hiện tại)
    const broken = !hasProtectionStone;
    return {
        success: false,
        newLevel: broken ? 0 : currentLevel,
        broken,
        hiddenLineUnlocked: false
    };
}
