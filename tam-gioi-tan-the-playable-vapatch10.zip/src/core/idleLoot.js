import { DROP_WEIGHTS, getMaterialName } from './content/materials.js';

// TAB4.1: Hệ Thống Thu Thập Idle / Post-Battle

// GIẢ ĐỊNH: mỗi cấp Trạm Radar tăng thêm 2 điểm trọng số cho tier Vàng (Thần Cấp), trừ đều
// tỷ lệ từ 3 tier thấp hơn — GDD không cho công thức cụ thể, cần bạn xác nhận/chỉnh lại.
const RADAR_GOLD_BOOST_PER_LEVEL = 2;

function getRadarBoostedWeights(radarLevel) {
    const boost = radarLevel * RADAR_GOLD_BOOST_PER_LEVEL;
    const [white, green, purple, gold] = DROP_WEIGHTS;
    const totalLower = white + green + purple;
    const deduction = Math.min(totalLower - 1, boost); // luôn chừa lại tối thiểu 1 cho 3 tier dưới
    const ratio = deduction / totalLower;
    return [
        white - white * ratio,
        green - green * ratio,
        purple - purple * ratio,
        gold + deduction
    ];
}

function rollWeighted(weights, rng) {
    const total = weights.reduce((a, b) => a + b, 0);
    let roll = rng() * total;
    for (let i = 0; i < weights.length; i++) {
        if (roll < weights[i]) return i;
        roll -= weights[i];
    }
    return weights.length - 1;
}

/** Rớt vật liệu có tính buff Trạm Radar Trinh Sát (tăng % rớt tier Vàng theo level). */
export function dropMaterialWithRadar(branchId, radarLevel = 0, rng = Math.random) {
    const weights = getRadarBoostedWeights(radarLevel);
    const tierIndex = rollWeighted(weights, rng);
    return { branchId, tierIndex, name: getMaterialName(branchId, tierIndex) };
}

/** % rớt tier Vàng thực tế tại 1 cấp Trạm Radar cho trước (0-1). */
export function getGoldDropChance(radarLevel = 0) {
    const weights = getRadarBoostedWeights(radarLevel);
    const total = weights.reduce((a, b) => a + b, 0);
    return weights[3] / total;
}
