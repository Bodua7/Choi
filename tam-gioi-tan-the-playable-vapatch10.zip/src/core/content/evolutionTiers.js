import { getMaterialName } from './materials.js';

// TAB1 + TAB7.2: Chuỗi Tiến Hóa 5 mốc, trải trên thang Lv1-100.
// GIẢ ĐỊNH: mỗi mốc rộng 20 level (1-20 / 21-40 / 41-60 / 61-80 / 81-100).
// Đây là điểm cần bạn xác nhận — nếu muốn chia không đều (vd mốc đầu ngắn hơn để
// onboard nhanh), chỉ cần sửa mảng LEVEL_RANGES bên dưới, phần còn lại tự khớp theo.

const LEVEL_RANGES = [
    [1, 20],
    [21, 40],
    [41, 60],
    [61, 80],
    [81, 100]
];

export const EVOLUTION_TIERS = {
    A_TUN: [
        { order: 0, name: 'Tân Thủ (Xe Đạp)' },
        { order: 1, name: 'Chiến Binh Cơ Giới (Xe Máy / Bán Tải)' },
        { order: 2, name: 'Tướng Lĩnh Bọc Thép (Pháo Đài Bọc Thép)' },
        { order: 3, name: 'Siêu Chiến Xa AI (Chiến Xa Tác Chiến Tự Động)' },
        { order: 4, name: 'Thực Thể Tối Thượng (Dung Nhập Lõi Cơ Khí)' }
    ],
    BAO: [
        { order: 0, name: 'Người Sinh Tồn' },
        { order: 1, name: 'Dị Năng Giả (Kích Hoạt Gen Biến Dị)' },
        { order: 2, name: 'Siêu Chiến Binh (Trang Bị Exo-Suit)' },
        { order: 3, name: 'Bá Chủ Pháo Đài (Liên Kết Hệ Thống Turret)' },
        { order: 4, name: 'Thần Cấp Vô Cực (Thần Thái Công Nghệ)' }
    ],
    HAN_LAP: [
        { order: 0, name: 'Luyện Khí / Trúc Cơ' },
        { order: 1, name: 'Nguyên Anh Kỳ' },
        { order: 2, name: 'Hóa Thần / Thần Thông' },
        { order: 3, name: 'Đại Thừa Kỳ' },
        { order: 4, name: 'Đạo Tổ Thời Gian' }
    ]
};

// Gắn khoảng level vào từng mốc (dùng chung LEVEL_RANGES cho cả 3 nhân vật)
for (const charId of Object.keys(EVOLUTION_TIERS)) {
    EVOLUTION_TIERS[charId].forEach((tier, i) => {
        tier.minLevel = LEVEL_RANGES[i][0];
        tier.maxLevel = LEVEL_RANGES[i][1];
    });
}

/** Trả về mốc tiến hóa hiện tại của nhân vật theo level (1-100). */
export function getTierForLevel(charId, level) {
    const tiers = EVOLUTION_TIERS[charId];
    if (!tiers) throw new Error(`Không tìm thấy chuỗi tiến hóa cho: ${charId}`);
    const clamped = Math.max(1, Math.min(100, level));
    return tiers.find(t => clamped >= t.minLevel && clamped <= t.maxLevel) || tiers[0];
}

/** Trả về mốc kế tiếp (null nếu đã ở mốc 5 / Lv100). */
export function getNextTier(charId, level) {
    const current = getTierForLevel(charId, level);
    const tiers = EVOLUTION_TIERS[charId];
    return tiers.find(t => t.order === current.order + 1) || null;
}

/** Số level còn lại để chạm mốc kế tiếp (0 nếu đã max). */
export function levelsUntilNextTier(charId, level) {
    const next = getNextTier(charId, level);
    if (!next) return 0;
    return Math.max(0, next.minLevel - level);
}

// TAB7.2: "Đạt mốc Level, nguyên liệu đột phá tương ứng và hoàn thành thử thách nhiệm vụ."
// GDD không liệt kê số lượng/loại nguyên liệu cụ thể cho từng mốc — GIẢ ĐỊNH dưới đây dùng
// đúng nhánh vật liệu của mỗi nhân vật (TAB3.1), đòi hỏi tier màu tương ứng mốc đến
// (mốc 1->Xanh, 2->Tím, 3&4->Vàng) với số lượng tăng dần, cộng thêm Tinh Thể Biến Dị ở
// mốc 4 và Lõi Đồng Hóa ở mốc cuối (mốc 5, tối thượng). Chỉnh BREAKTHROUGH_MATERIAL_BRANCH
// / QUANTS nếu muốn cân bằng khác.
export const BREAKTHROUGH_MATERIAL_BRANCH = {
    A_TUN: 'CO_KHI',
    BAO: 'CONG_NGHE',
    HAN_LAP: 'TIEN_HIEP'
};

// Với mỗi mốc đích (order 1-4), yêu cầu: tierIndex vật liệu (0=Trắng..3=Vàng), số lượng,
// tên nhiệm vụ thử thách phải hoàn thành trước, và currency phụ trợ (nếu có, từ currencies.js).
const BREAKTHROUGH_REQUIREMENTS = [
    null, // order 0 là mốc khởi đầu, không cần điều kiện đột phá
    { materialTierIndex: 1, materialQty: 20, quest: 'Thử Thách Mốc 2', extraCurrency: null },
    { materialTierIndex: 2, materialQty: 15, quest: 'Thử Thách Mốc 3', extraCurrency: null },
    { materialTierIndex: 3, materialQty: 10, quest: 'Thử Thách Mốc 4', extraCurrency: null }, // VÁ #21: bỏ 5 TINH_THE_BIEN_DI (catch-22, xem ghi chú trên)
    { materialTierIndex: 3, materialQty: 25, quest: 'Thử Thách Mốc 5 (Tối Thượng)', extraCurrency: { id: 'LOI_DONG_HOA', qty: 3 } }
];

/** Trả về điều kiện đột phá đầy đủ (level + vật liệu + nhiệm vụ) để lên 1 mốc cho trước. */
export function getBreakthroughRequirement(charId, tierOrder) {
    const tiers = EVOLUTION_TIERS[charId];
    if (!tiers) throw new Error(`Không tìm thấy chuỗi tiến hóa cho: ${charId}`);
    const tier = tiers.find(t => t.order === tierOrder);
    if (!tier) throw new Error(`Không tìm thấy mốc ${tierOrder} cho nhân vật ${charId}`);
    const req = BREAKTHROUGH_REQUIREMENTS[tierOrder];
    if (!req) return null; // mốc 0 không có điều kiện
    return {
        requiredLevel: tier.minLevel,
        materialBranch: BREAKTHROUGH_MATERIAL_BRANCH[charId],
        materialTierIndex: req.materialTierIndex,
        materialQty: req.materialQty,
        quest: req.quest,
        extraCurrency: req.extraCurrency
    };
}

/**
 * Kiểm tra nhân vật có đủ điều kiện đột phá lên mốc kế tiếp hay không.
 * `state` = { level, materials: { [materialName]: qty }, completedQuests: Set|Array, wallet: {...} }
 */
export function canBreakthrough(charId, state) {
    const next = getNextTier(charId, state.level);
    if (!next) return { ok: false, reason: 'Đã ở mốc tối đa (Lv100).' };
    const req = getBreakthroughRequirement(charId, next.order);
    if (!req) return { ok: false, reason: 'Mốc kế tiếp không có điều kiện đột phá.' };

    if (state.level < req.requiredLevel) {
        return { ok: false, reason: `Cần đạt Lv${req.requiredLevel}.` };
    }

    const completedQuests = state.completedQuests instanceof Set
        ? state.completedQuests
        : new Set(state.completedQuests || []);
    if (!completedQuests.has(req.quest)) {
        return { ok: false, reason: `Chưa hoàn thành nhiệm vụ: ${req.quest}.` };
    }

    const materialName = getMaterialName(req.materialBranch, req.materialTierIndex);
    const haveMaterial = (state.materials && state.materials[materialName]) || 0;
    if (haveMaterial < req.materialQty) {
        return { ok: false, reason: `Thiếu ${req.materialQty - haveMaterial} ${materialName}.` };
    }

    if (req.extraCurrency) {
        const have = (state.wallet && state.wallet[req.extraCurrency.id]) || 0;
        if (have < req.extraCurrency.qty) {
            return { ok: false, reason: `Thiếu ${req.extraCurrency.qty - have} ${req.extraCurrency.id}.` };
        }
    }

    return { ok: true, requirement: req, nextTier: next };
}

/**
 * Thực hiện đột phá: kiểm tra lại điều kiện, trừ vật liệu + currency phụ nếu đủ,
 * rồi trả về mốc mới. Không tự tăng level (level do combatMath/gameLoop quản lý);
 * hàm này chỉ xử lý phần "trả giá" của việc đột phá mốc.
 */
export function performBreakthrough(charId, state) {
    const check = canBreakthrough(charId, state);
    if (!check.ok) return check;

    const { requirement } = check;
    const materialName = getMaterialName(requirement.materialBranch, requirement.materialTierIndex);
    state.materials[materialName] -= requirement.materialQty;
    if (requirement.extraCurrency && state.wallet) {
        state.wallet[requirement.extraCurrency.id] -= requirement.extraCurrency.qty;
    }

    return { ok: true, tier: check.nextTier };
}
