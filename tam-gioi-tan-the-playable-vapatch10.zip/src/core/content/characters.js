// TAB1: 3 Main đại diện cho 3 Vũ Trụ. Dữ liệu tĩnh, không đổi theo level
// (chỉ số theo level nằm ở evolutionTiers.js + combatMath.js).

export const CHARACTERS = {
    A_TUN: {
        id: 'A_TUN',
        name: 'A Tun',
        branch: 'Cơ Khí Sát Độc',
        traits: [
            'Sát thương diện rộng',
            'Càn quét hỏa lực',
            'Phân rã giáp',
            'Đồng hóa kim loại'
        ],
        focusStats: ['Bán kính Sát Độc', 'Độ bền Khung xe (HP)', 'Giáp hợp kim', 'Tỷ lệ Đồng hóa'],
        // Các trường thống kê chính dùng bởi combatMath.scaleStat — khớp key với TAB10
        statKeys: ['hp', 'atk', 'def']
    },
    BAO: {
        id: 'BAO',
        name: 'Bao',
        branch: 'Dị Năng & Công Nghệ Tận Thế',
        traits: [
            'Sát thương Bạo kích đơn thể/diện rộng',
            'Hỏa lực hạt nhân',
            'Khống chế kỹ thuật'
        ],
        focusStats: ['Tỷ lệ Bạo kích (Crit Rate)', 'Sát thương Bạo kích', 'Kháng độc tố', 'Năng lượng Exo-suit'],
        statKeys: ['hp', 'atk', 'crit']
    },
    HAN_LAP: {
        id: 'HAN_LAP',
        name: 'Hàn Lập',
        branch: 'Tiên Hiệp & Pháp Tắc',
        traits: [
            'Khống chế diện rộng',
            'Độn thuật né tránh',
            'Sát thương Pháp bảo',
            'Luân Hồi & Thời Gian'
        ],
        focusStats: ['Năng lượng Pháp tắc (MP)', 'Tốc độ Né tránh (Độn thuật)', 'Kháng phép', 'Sát thương Pháp bảo'],
        statKeys: ['hp', 'mp', 'atk']
    }
};

export const CHARACTER_IDS = Object.keys(CHARACTERS);

export function getCharacter(id) {
    const c = CHARACTERS[id];
    if (!c) throw new Error(`Không tìm thấy nhân vật: ${id}`);
    return c;
}
