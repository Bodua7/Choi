// TAB11.2 + TAB11.3: Phe Phái & Danh Vọng.
// 3 phe, 4 bậc danh vọng: Bình Thường -> Thân Thiết -> Tôn Sùng -> Huyền Thoại
// (mở khóa Chợ Đen). GDD không cho ngưỡng điểm cụ thể cho từng bậc — GIẢ ĐỊNH đường cong
// dưới đây (mỗi bậc yêu cầu nhiều điểm hơn ~4x bậc trước), chỉnh REPUTATION_TIERS nếu
// muốn cân bằng khác.

export const FACTIONS = {
    LIEN_MINH_SINH_TON: {
        id: 'LIEN_MINH_SINH_TON',
        name: 'Liên Minh Sinh Tồn'
    },
    CONG_XUONG_CO_GIOI_TU_DO: {
        id: 'CONG_XUONG_CO_GIOI_TU_DO',
        name: 'Công Xưởng Cơ Giới Tự Do'
    },
    TU_TIEN_GIOI_BAN_DIA: {
        id: 'TU_TIEN_GIOI_BAN_DIA',
        name: 'Tu Tiên Giới Bản Địa'
    }
};

export const FACTION_IDS = Object.keys(FACTIONS);

export const REPUTATION_TIERS = [
    { order: 0, name: 'Bình Thường', minPoints: 0, unlocksBlackMarket: false },
    { order: 1, name: 'Thân Thiết', minPoints: 1000, unlocksBlackMarket: false },
    { order: 2, name: 'Tôn Sùng', minPoints: 5000, unlocksBlackMarket: false },
    { order: 3, name: 'Huyền Thoại', minPoints: 20000, unlocksBlackMarket: true }
];

/** Tạo bảng danh vọng khởi đầu, cả 3 phe đều 0 điểm. */
export function createReputationState() {
    const state = {};
    for (const id of FACTION_IDS) state[id] = 0;
    return state;
}

/** Cộng điểm danh vọng cho 1 phe (không âm). */
export function addReputation(state, factionId, amount) {
    if (!FACTIONS[factionId]) throw new Error(`Không tìm thấy phe phái: ${factionId}`);
    state[factionId] = Math.max(0, (state[factionId] || 0) + amount);
    return state;
}

/** Trả về bậc danh vọng hiện tại (object trong REPUTATION_TIERS) theo số điểm. */
export function getReputationTier(points) {
    let tier = REPUTATION_TIERS[0];
    for (const t of REPUTATION_TIERS) {
        if (points >= t.minPoints) tier = t;
    }
    return tier;
}

/** Bậc kế tiếp (null nếu đã Huyền Thoại) + số điểm còn thiếu. */
export function getNextReputationTier(points) {
    const current = getReputationTier(points);
    const next = REPUTATION_TIERS.find(t => t.order === current.order + 1);
    if (!next) return null;
    return { tier: next, pointsNeeded: Math.max(0, next.minPoints - points) };
}

/** true nếu phe phái đã đạt Huyền Thoại (mở khóa Chợ Đen) tại điểm số cho trước. */
export function hasBlackMarketAccess(points) {
    return getReputationTier(points).unlocksBlackMarket;
}
