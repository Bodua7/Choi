// TAB5: Sổ Tay Kẻ Thù & Thảm Họa (Codex)

export const TIER_ORDER = ['D_C', 'B_A', 'S', 'SSS'];

export const ENEMY_CODEX = {
    D_C: {
        tier: 'D-C',
        SAT_DOC_CO_KHI: 'Zombie thường, Chó dại',
        ZOMBIE_TAN_THE: 'Triều cường zombie nhỏ',
        PHAM_NHAN_TU_TIEN: 'Tu sĩ Luyện Khí, Ma thú'
    },
    B_A: {
        tier: 'B-A',
        SAT_DOC_CO_KHI: 'Zombie Biến Giáp, Độc',
        ZOMBIE_TAN_THE: 'Zombie Khổng Lồ, Axit',
        PHAM_NHAN_TU_TIEN: 'Lão quái Nguyên Anh'
    },
    S: {
        tier: 'S',
        SAT_DOC_CO_KHI: 'Băng nhóm Cơ giới địch',
        ZOMBIE_TAN_THE: 'Zombie Vương (Brain)',
        PHAM_NHAN_TU_TIEN: 'Ma Hoàng, Ma Tôn'
    },
    SSS: {
        tier: 'SSS',
        SAT_DOC_CO_KHI: 'Trùm Mã Độc Phân Rã',
        ZOMBIE_TAN_THE: 'Thảm Họa Hạt Nhân SSS',
        PHAM_NHAN_TU_TIEN: 'Cổ Hội (Thời Gian Đạo Tổ)'
    }
};

export function getEnemiesForTier(tierKey) {
    const entry = ENEMY_CODEX[tierKey];
    if (!entry) throw new Error(`Không tìm thấy tier: ${tierKey}`);
    return entry;
}
