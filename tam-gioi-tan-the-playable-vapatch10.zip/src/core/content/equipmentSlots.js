// TAB9.1: Các Vị Trí Trang Bị (Slots) — 5 slot cố định cho mỗi Main.

export const EQUIPMENT_SLOTS = {
    A_TUN: ['Khung Xe/Mạn Giáp', 'Động Cơ', 'Vũ Khí Càn Quét', 'Lõi Sát Độc', 'Rada Cảm Biến'],
    BAO: ['Giáp Exo-Suit', 'Vũ Khí Chính', 'Mod Tụ Điện', 'Thiết Bị EMP', 'Kính Định Vị'],
    HAN_LAP: ['Tráp Kiếm', 'Cổ Bảo/Trấn Bảo', 'Pháp Y/Đạo Hào', 'Linh Vật Trợ Chiến', 'Pháp Bảo Thời Gian']
};

/** Tạo bộ trang bị rỗng (mọi slot = null) cho 1 nhân vật. */
export function createEmptyLoadout(charId) {
    const slots = EQUIPMENT_SLOTS[charId];
    if (!slots) throw new Error(`Không có danh sách slot cho nhân vật: ${charId}`);
    const loadout = {};
    for (const slot of slots) loadout[slot] = null;
    return loadout;
}

/** Gắn 1 item vào đúng slot (kiểm tra tên slot hợp lệ với nhân vật). */
export function equip(charId, loadout, slotName, item) {
    if (!EQUIPMENT_SLOTS[charId]?.includes(slotName)) {
        throw new Error(`Slot '${slotName}' không tồn tại cho ${charId}`);
    }
    loadout[slotName] = item;
    return loadout;
}

/** Gỡ item khỏi 1 slot, trả về item vừa gỡ (null nếu slot đang trống). */
export function unequip(loadout, slotName) {
    const item = loadout[slotName] || null;
    loadout[slotName] = null;
    return item;
}
