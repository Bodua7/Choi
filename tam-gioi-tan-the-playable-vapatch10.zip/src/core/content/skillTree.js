import { getTierForLevel } from './evolutionTiers.js';

// TAB6: Bảng Kỹ Năng (Skill Tree) Theo Mốc Tiến Hóa.
// Mỗi mốc mở 3 kỹ năng: Active (Ulti ở mốc 5), Passive, Synergy.

export const SKILL_TREE = {
    A_TUN: [
        { order: 0, skills: [
            { type: 'active', name: 'Lưỡi Đĩa Cắt' },
            { type: 'passive', name: 'Quét Phế Liệu' },
            { type: 'synergy', name: 'Hỗ Trợ Trinh Sát' }
        ]},
        { order: 1, skills: [
            { type: 'active', name: 'Xung Kích Tốc Độ' },
            { type: 'passive', name: 'Luyện Kim Sơ Cấp' },
            { type: 'synergy', name: 'Xạ Thủ Tiền Tuyến' }
        ]},
        { order: 2, skills: [
            { type: 'active', name: 'Trường Sát Độc' },
            { type: 'passive', name: 'Giáp Hợp Kim Titanium' },
            { type: 'synergy', name: 'Trận Pháp Kim Cơ' }
        ]},
        { order: 3, skills: [
            { type: 'active', name: 'Bão Tên Lửa Mini' },
            { type: 'passive', name: 'Đồng Hóa Tức Thời' },
            { type: 'synergy', name: 'Phủ Sóng Radar' }
        ]},
        { order: 4, skills: [
            { type: 'ulti', name: 'Thần Phạt Cơ Khí' },
            { type: 'passive', name: 'Tái Cấu Trúc Vĩnh Hằng' },
            { type: 'synergy', name: 'Tam Giới Quy Tụ' }
        ]}
    ],
    BAO: [
        { order: 0, skills: [
            { type: 'active', name: 'Bắn Tỉa Điểm Yếu' },
            { type: 'passive', name: 'Cảnh Giác Tận Thế' },
            { type: 'synergy', name: 'Yểm Trợ Tầm Xa' }
        ]},
        { order: 1, skills: [
            { type: 'active', name: 'Bão Điện Cao Áp' },
            { type: 'passive', name: 'Thể Chất Cường Hóa' },
            { type: 'synergy', name: 'Lôi Lực Cộng Hưởng' }
        ]},
        { order: 2, skills: [
            { type: 'active', name: 'Bom Xung Điện Từ' },
            { type: 'passive', name: 'Tụ Điện Năng Lượng' },
            { type: 'synergy', name: 'Khóa Mục Tiêu' }
        ]},
        { order: 3, skills: [
            { type: 'active', name: 'Pháo Laser Plasma' },
            { type: 'passive', name: 'Khung Kháng Bức Xạ' },
            { type: 'synergy', name: 'Tiếp Năng Lượng Căn Cứ' }
        ]},
        { order: 4, skills: [
            { type: 'ulti', name: 'Hỏa Lực Tận Thế' },
            { type: 'passive', name: 'Gen Bá Chủ' },
            { type: 'synergy', name: 'Định Vị Hạt Nhân' }
        ]}
    ],
    HAN_LAP: [
        { order: 0, skills: [
            { type: 'active', name: 'Kiếm Khí Trảm' },
            { type: 'passive', name: 'La Sát Độn Thuật' },
            { type: 'synergy', name: 'Bù Trận Sơ Cấp' }
        ]},
        { order: 1, skills: [
            { type: 'active', name: 'Phích Lịch Tử Hỏa Pháo' },
            { type: 'passive', name: 'Đề Hồn Thú Trấn Áp' },
            { type: 'synergy', name: 'Thần Thức Định Vị' }
        ]},
        { order: 2, skills: [
            { type: 'active', name: 'Thanh Chúc Kiếm Trận' },
            { type: 'passive', name: 'Phạn Thánh Chân Ma Thể' },
            { type: 'synergy', name: 'Trận Pháp Hộ Thành' }
        ]},
        { order: 3, skills: [
            { type: 'active', name: 'Hư Thiên Đỉnh Trấn Áp' },
            { type: 'passive', name: 'Càn Lam Băng Diệm' },
            { type: 'synergy', name: 'Phong Tỏa Không Gian' }
        ]},
        { order: 4, skills: [
            { type: 'ulti', name: 'Chân Ngôn Bảo Luân' },
            { type: 'passive', name: 'Luân Hồi Trọng Sinh' },
            { type: 'synergy', name: 'Tam Giới Nghịch Chuyển' }
        ]}
    ]
};

/** Lấy toàn bộ kỹ năng đã mở khóa tính đến level hiện tại (gộp mọi mốc <= mốc hiện tại). */
export function getUnlockedSkills(charId, level) {
    const currentTier = getTierForLevel(charId, level);
    const tiers = SKILL_TREE[charId];
    return tiers
        .filter(t => t.order <= currentTier.order)
        .flatMap(t => t.skills);
}
