// TAB3.1: Danh Sách Vật Liệu Random (rớt từ trận đánh).
// 3 nhánh, mỗi nhánh 4 tier màu tăng dần độ hiếm: Trắng -> Xanh -> Tím -> Vàng.

export const TIER_COLORS = ['Trắng', 'Xanh', 'Tím', 'Vàng'];

// Tỷ lệ rớt mặc định theo tier (Trắng dễ rớt nhất, Vàng hiếm nhất).
// GIẢ ĐỊNH: GDD không ghi rõ %, đây là đường cong hợp lý cho idle/gacha game —
// chỉnh lại DROP_WEIGHTS nếu muốn cân bằng khác.
export const DROP_WEIGHTS = [70, 22, 7, 1]; // Trắng/Xanh/Tím/Vàng, cộng lại = 100

export const MATERIAL_BRANCHES = {
    CO_KHI: {
        id: 'CO_KHI',
        name: 'Nhánh Cơ Khí',
        tiers: [
            'Phế Liệu Sắt Thép',
            'Thép Hợp Kim Titan',
            'Tấm Bọc Thép Quân Dụng',
            'Lõi Cơ Khí Tối Cao'
        ]
    },
    CONG_NGHE: {
        id: 'CONG_NGHE',
        name: 'Nhánh Công Nghệ',
        tiers: [
            'Linh Kiện Điện Tử',
            'Tinh Thể Não Zombie B',
            'Tinh Thể Khổng Lồ S',
            'Mẫu Gen Zombie Vương'
        ]
    },
    TIEN_HIEP: {
        id: 'TIEN_HIEP',
        name: 'Nhánh Tiên Hiệp',
        tiers: [
            'Linh Đá Hạ Cấp / Thiết Tinh',
            'Vảy Ma Thú',
            'Yêu Đan Cấp 7',
            'Mảnh Vỡ Thời Gian Pháp Tắc / Thần Thiết Cơ Giáp'
        ]
    }
};

/** Lấy tên vật liệu theo nhánh + chỉ số tier (0=Trắng .. 3=Vàng). */
export function getMaterialName(branchId, tierIndex) {
    const branch = MATERIAL_BRANCHES[branchId];
    if (!branch) throw new Error(`Không tìm thấy nhánh vật liệu: ${branchId}`);
    return branch.tiers[tierIndex];
}
