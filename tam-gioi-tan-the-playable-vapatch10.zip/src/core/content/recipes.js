// TAB3.2: Công Thức Ghép Trang Bị Tiêu Biểu.
// LƯU Ý: một số nguyên liệu trong công thức gốc (vd "Lõi Năng Lượng", "Linh Đá Cao Cấp")
// không trùng tên với 4-tier trong materials.js — đây là vật liệu phụ riêng của công thức,
// giữ nguyên theo đúng văn bản GDD thay vì tự ý gộp vào bảng tier.

export const RECIPES = {
    A_TUN: [
        {
            id: 'A_TUN_CUA_XOAY_TITANIUM',
            name: 'Cưa Xoay Titanium Sát Độc',
            grade: 'normal',
            ingredients: { 'Phế Liệu Sắt': 50, 'Thép Titan': 10, 'Tinh Thể Zombie': 5 }
        },
        {
            id: 'A_TUN_PHAO_LASER_PHAN_RA',
            name: 'Pháo Laser Phân Rã',
            grade: 'normal',
            ingredients: { 'Lõi Năng Lượng': 5, 'Tụ Điện Cao Áp': 10, 'Linh Đá Cao Cấp': 2 }
        },
        {
            id: 'A_TUN_CHIEN_HAM_LOI_CO_KHI',
            name: 'Chiến Hạm Lõi Cơ Khí',
            grade: 'divine', // [THẦN CẤP]
            ingredients: { 'Lõi Cơ Khí Tối Cao': 1, 'Thần Thiết Cơ Giáp': 1, 'Linh Đá Cao Cấp': 50 }
        }
    ],
    BAO: [
        {
            id: 'BAO_SUNG_TIEU_LIEN_XUNG_DIEN',
            name: 'Súng Tiểu Liên Xung Điện',
            grade: 'normal',
            ingredients: { 'Linh Kiện': 30, 'Tụ Điện Cao Áp': 10, 'Yêu Đan Cấp 7': 1 }
        },
        {
            id: 'BAO_PHAO_PLASMA_HAT_NHAN',
            name: 'Pháo Plasma Hạt Nhân',
            grade: 'normal',
            ingredients: { 'Lõi Hạt Nhân Mini': 2, 'Tinh Thể Cấp S': 1, 'Lõi Năng Lượng': 10 }
        },
        {
            id: 'BAO_BO_GIAP_BA_CHU_VO_CUC',
            name: 'Bộ Giáp Bá Chủ Vô Cực',
            grade: 'divine',
            ingredients: { 'Mẫu Gen Zombie Vương': 1, 'Khung Kháng Bức Xạ': 1, 'Linh Đá Cao Cấp': 20 }
        }
    ],
    HAN_LAP: [
        {
            id: 'HAN_LAP_THANH_CHUC_KIEM',
            name: 'Thanh Chúc Kiếm (Set 72)',
            grade: 'normal',
            ingredients: { 'Quặng Thiết Tinh': 100, 'Thần Thiết Sơ Cấp': 10, 'Mộc Yếu Tố': 20 }
        },
        {
            id: 'HAN_LAP_HU_THIEN_DINH',
            name: 'Hư Thiên Đỉnh (Cổ Bảo)',
            grade: 'normal',
            ingredients: { 'Mảnh Vỡ Thông Thiên Linh Bảo': 1, 'Yêu Đan Cấp 7': 10, 'Linh Đá': 50 }
        },
        {
            id: 'HAN_LAP_CHAN_NGON_BAO_LUAN',
            name: 'Chân Ngôn Bảo Luân',
            grade: 'divine',
            ingredients: { 'Mảnh Vỡ Thời Gian Pháp Tắc': 1, 'Linh Đá Cao Cấp': 100, 'Lõi Hạt Nhân': 1 }
        }
    ]
};

export function getRecipesFor(charId) {
    const list = RECIPES[charId];
    if (!list) throw new Error(`Không có công thức cho nhân vật: ${charId}`);
    return list;
}

function findRecipe(recipeId) {
    for (const list of Object.values(RECIPES)) {
        const found = list.find(r => r.id === recipeId);
        if (found) return found;
    }
    throw new Error(`Không tìm thấy công thức: ${recipeId}`);
}

/** Kiểm tra kho nguyên liệu (object { tênVậtLiệu: sốLượng }) có đủ để ghép không. */
export function canCraft(recipeId, inventory) {
    const recipe = findRecipe(recipeId);
    return Object.entries(recipe.ingredients).every(
        ([mat, qty]) => (inventory[mat] || 0) >= qty
    );
}

/**
 * Ghép trang bị: trừ nguyên liệu khỏi inventory (mutate) nếu đủ, trả về recipe đã ghép.
 * Không đủ nguyên liệu -> trả về null, không đụng tới inventory.
 */
export function craft(recipeId, inventory) {
    const recipe = findRecipe(recipeId);
    if (!canCraft(recipeId, inventory)) return null;
    for (const [mat, qty] of Object.entries(recipe.ingredients)) {
        inventory[mat] -= qty;
    }
    return recipe;
}
