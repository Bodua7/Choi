import { CHARACTER_IDS } from './characters.js';
import { getTierForLevel } from './evolutionTiers.js';

// TAB11.1: Nhiệm Vụ, Cốt Truyện & Danh Vọng Phe Phái — Cốt Truyện 5 Chương.
// GDD chỉ đặt tên rõ Chương I và Chương V — tên Chương II-IV là GIẢ ĐỊNH, viết để nối mạch
// (3 Main tự lập -> hợp nhất lực lượng -> phát hiện Cổ Hội -> đối đầu), đổi lại nếu bạn có
// cốt truyện cụ thể hơn cho từng chương giữa.
//
// Mốc mở khóa: mỗi Chương gắn với 1 mốc tiến hóa (evolutionTiers order 0-4) — Chương N mở
// khi CẢ 3 Main đều đạt tối thiểu mốc (N-1). Đây cũng là GIẢ ĐỊNH hợp lý (GDD không nêu rõ
// điều kiện mở chương), tận dụng lại evolutionTiers.js làm nguồn chân lý duy nhất cho "độ
// mạnh hiện tại" thay vì tạo thêm 1 hệ điều kiện riêng.

export const STORY_CHAPTERS = [
    {
        order: 0,
        name: 'Chương I: Tận Thế Hội Tụ',
        summary: '3 Main thức tỉnh sức mạnh giữa buổi đầu tận thế, mỗi người một hướng sinh tồn riêng.',
        requiredTierOrder: 0
    },
    {
        order: 1,
        name: 'Chương II: Ba Ngã Rẽ Sinh Tồn',
        summary: 'A Tun, Bao, Hàn Lập củng cố sức mạnh trên con đường riêng, lần đầu chạm trán quy mô Thú Triều.',
        requiredTierOrder: 1
    },
    {
        order: 2,
        name: 'Chương III: Liên Minh Tam Giới',
        summary: '3 Main hợp nhất lực lượng, xây dựng Căn Cứ chung, phối hợp trận pháp/turret/rào chắn lần đầu.',
        requiredTierOrder: 2
    },
    {
        order: 3,
        name: 'Chương IV: Bóng Ma Cổ Hội',
        summary: 'Liên minh phát hiện dấu vết Cổ Hội (Thời Gian Đạo Tổ) đứng sau thảm họa, chuẩn bị combo Tuyệt Kỹ.',
        requiredTierOrder: 3
    },
    {
        order: 4,
        name: 'Chương V: Quy Tụ Vô Cực - Trảm Sát Cổ Hội',
        summary: '3 Main tại Mốc Tối Thượng, tung Combo Tuyệt Kỹ 4 bước quyết chiến Cổ Hội, khép lại vòng lặp đầu.',
        requiredTierOrder: 4
    }
];

/**
 * Chương cao nhất đã mở khóa, dựa trên level hiện tại của cả 3 Main.
 * @param {Object<string, number>} charLevels  { A_TUN: level, BAO: level, HAN_LAP: level }
 */
export function getUnlockedChapter(charLevels) {
    const tierOrders = CHARACTER_IDS.map(id => getTierForLevel(id, charLevels[id] ?? 1).order);
    const minTierOrder = Math.min(...tierOrders);
    let unlocked = STORY_CHAPTERS[0];
    for (const chapter of STORY_CHAPTERS) {
        if (minTierOrder >= chapter.requiredTierOrder) unlocked = chapter;
    }
    return unlocked;
}

/** Chương kế tiếp (null nếu đã ở Chương V). */
export function getNextChapter(charLevels) {
    const current = getUnlockedChapter(charLevels);
    return STORY_CHAPTERS.find(c => c.order === current.order + 1) || null;
}

/** true nếu đã hoàn thành toàn bộ cốt truyện (mở đến Chương V). */
export function isStoryComplete(charLevels) {
    return getUnlockedChapter(charLevels).order === STORY_CHAPTERS[STORY_CHAPTERS.length - 1].order;
}
