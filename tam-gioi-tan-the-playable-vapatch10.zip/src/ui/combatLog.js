// TAB8: Giao Diện Màn Hình & Mẫu Combat Log (UI/UX Text Design)
// "Hệ thống giao diện dạng ASCII Text Log realtime, cập nhật liên tục các lượt đánh,
// sát thương, hiệu ứng và lệnh tác chiến của người chơi."
//
// Module này KHÔNG vẽ DOM/canvas — chỉ tạo dữ liệu dòng log đã format (text + type),
// để bất kỳ layer UI nào (terminal ASCII, React, v.v.) tự render/tô màu theo `type`.
// Các adapter bên dưới đọc trực tiếp mảng `log` mà combat.js/ultimateCombo.js/idleLoot.js
// đã trả về (TAB2, TAB2.3, TAB4.1) — không tính toán lại số liệu, chỉ format hiển thị.

// Mỗi type ứng với 1 "màu" quy ước cho UI (TAB8 không cho bảng màu cụ thể — GIẢ ĐỊNH
// theo convention phổ biến của combat log game: dmg=đỏ, heal/loot=xanh lá, effect=vàng,
// system=xám, boss=tím, ulti=cam). Đổi LOG_COLORS nếu muốn bảng màu khác.
export const LOG_COLORS = {
    attack: '#e0e0e0',
    dmg: '#ff4d4d',
    effect: '#ffd24d',
    loot: '#4dff88',
    system: '#9e9e9e',
    boss: '#c084fc',
    ulti: '#ff9c4d',
    win: '#4dff88',
    lose: '#ff4d4d'
};

const DEFAULT_MAX_LINES = 200;

/** Tạo buffer log rỗng (FIFO, giới hạn maxLines dòng gần nhất). */
export function createLogBuffer(maxLines = DEFAULT_MAX_LINES) {
    return { lines: [], maxLines };
}

/** Thêm 1 dòng log vào buffer (tự cắt bớt dòng cũ nhất nếu vượt maxLines). */
export function pushLog(buffer, type, text, now = Date.now()) {
    if (!LOG_COLORS[type]) type = 'system';
    buffer.lines.push({ type, text, timestamp: now });
    if (buffer.lines.length > buffer.maxLines) {
        buffer.lines.splice(0, buffer.lines.length - buffer.maxLines);
    }
    return buffer;
}

/** Render buffer thành mảng { type, text, color } — dùng khi UI muốn tự tô màu từng dòng. */
export function renderAsLines(buffer) {
    return buffer.lines.map(l => ({ type: l.type, text: formatLine(l), color: LOG_COLORS[l.type] }));
}

const TYPE_PREFIX = {
    attack: '>>',
    dmg: '--',
    effect: '**',
    loot: '+',
    system: '::',
    boss: '##',
    ulti: '!!',
    win: '[THẮNG]',
    lose: '[THUA]'
};

function formatLine(entry) {
    const prefix = TYPE_PREFIX[entry.type] || '::';
    return `${prefix} ${entry.text}`;
}

// ----- Adapters: đọc kết quả từ combat.js / ultimateCombo.js / idleLoot.js -----

/** Đánh Thường (combat.normalScavenge) -> log 1 dòng kết quả. */
export function logNormalScavenge(buffer, result, now = Date.now()) {
    pushLog(buffer, 'attack', `Đánh Thường: ${result.damagePerHit.toFixed(0)} dmg/đòn, cần ${result.hitsToKill} đòn để hạ mục tiêu.`, now);
    // VÁ #18: nhánh này trước đây KHÔNG BAO GIỜ chạy được (win luôn = true trong combat.js
    // cũ), nên thông điệp cũ "kiểm tra lại chỉ số ATK" chưa từng bị phát hiện là sai — giờ
    // Càn Quét có thể thua thật vì HP người chơi cạn trước khi hạ được quái (không phải vì
    // ATK = 0, ATK không bao giờ = 0), nên đổi lại đúng nguyên nhân thật.
    if (!result.win) pushLog(buffer, 'system', 'Quái phản đòn quá mạnh — HP cạn trước khi hạ được mục tiêu.', now);
    return buffer;
}

/** Đột Phá Vòng Vây (combat.runHordeDefense) -> log từng wave + kết quả cuối. */
export function logHordeDefense(buffer, result, now = Date.now()) {
    result.log.forEach((wave, i) => {
        pushLog(buffer, 'dmg', `Wave ${i + 1}: ${wave.enemiesCount.toLocaleString('vi-VN')} quái tràn vào, Căn Cứ nhận ${wave.mitigated.toFixed(0)} dmg (HP còn ${wave.hpRemaining.toFixed(0)}).`, now);
    });
    pushLog(buffer, result.survived ? 'win' : 'lose', result.survived ? `Căn Cứ trụ vững! HP còn lại: ${result.finalHp.toFixed(0)}.` : 'Căn Cứ thất thủ!', now);
    return buffer;
}

/** Boss SSS (combat.runBossFight) -> log từng đòn + phá giáp/ngắt chiêu + kết quả. */
export function logBossFight(buffer, result, now = Date.now()) {
    let armorLogged = false;
    let interruptLogged = false;
    result.log.forEach(hit => {
        pushLog(buffer, 'boss', `Đòn #${hit.hitIndex + 1}: gây ${hit.dealt.toFixed(0)} dmg, Boss còn ${hit.hpRemaining.toFixed(0)} HP.`, now);
        if (hit.armorBroken && !armorLogged) {
            pushLog(buffer, 'effect', 'PHÁ GIÁP! Giáp Boss giảm 50%.', now);
            armorLogged = true;
        }
        if (hit.interrupted && !interruptLogged) {
            pushLog(buffer, 'effect', 'NGẮT CHIÊU! Boss bị gián đoạn chiêu thức.', now);
            interruptLogged = true;
        }
    });
    pushLog(buffer, result.win ? 'win' : 'lose', result.win ? `Hạ gục Boss! Tổng sát thương: ${result.totalDealt.toFixed(0)}.` : `Boss còn ${result.finalHp.toFixed(0)} HP — chưa hạ được.`, now);
    return buffer;
}

/** Ultimate Combo (ultimateCombo.runUltimateCombo) -> log 4 bước combo + kết quả. */
export function logUltimateCombo(buffer, result, now = Date.now()) {
    result.log.forEach(step => {
        if (step.step === 1) {
            pushLog(buffer, 'ulti', `[Bước 1] ${step.name}: ${step.effect}`, now);
        } else if (step.step === 2) {
            pushLog(buffer, 'ulti', `[Bước 2] ${step.name}: Giáp/Kháng Boss còn ${step.armorAfter.toFixed(1)}/${(step.resistAfter * 100).toFixed(0)}%`, now);
        } else {
            pushLog(buffer, 'ulti', `[Bước ${step.step}] ${step.name}: gây ${step.damageDealt.toFixed(0)} dmg, Boss còn ${step.hpRemaining.toFixed(0)} HP.`, now);
        }
    });
    pushLog(buffer, result.win ? 'win' : 'lose', result.win ? `COMBO KẾT LIỄU THÀNH CÔNG! Tổng dmg: ${result.totalDamage.toFixed(0)}.` : `Combo chưa đủ hạ Boss (còn ${result.finalHp.toFixed(0)} HP).`, now);
    return buffer;
}

/** Loot post-battle (baseSupport.autoCollectFromWave) -> log từng vật liệu thu được. */
export function logLootCollected(buffer, collected, now = Date.now()) {
    const entries = Object.entries(collected);
    if (entries.length === 0) return buffer;
    for (const [name, qty] of entries) {
        pushLog(buffer, 'loot', `Thu được: ${name} x${qty}`, now);
    }
    return buffer;
}

/** Lệnh tác chiến thủ công của người chơi (vd. bấm nút kích hoạt kỹ năng). */
export function logPlayerCommand(buffer, commandText, now = Date.now()) {
    pushLog(buffer, 'system', `Lệnh: ${commandText}`, now);
    return buffer;
}
