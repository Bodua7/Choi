# Tam Giới Tận Thế — Android WebView wrapper

Đóng gói game HTML/JS (`game.zip`) thành APK bằng WebView, build tự động qua GitHub Actions.

## Cách hoạt động

- `game.zip` (đúng file `tam-gioi-tan-the-playable-polished.zip`) nằm ở gốc repo.
- `app/src/main/assets/www/` để trống trong repo (chỉ có `.gitkeep`) — mỗi lần CI chạy,
  workflow `.github/workflows/build-apk.yml` sẽ tự **unzip `game.zip`** vào đúng thư mục này
  rồi mới build, nên không phải commit trùng 2 bản nội dung game.
- `MainActivity.kt` mở game qua `WebViewAssetLoader` (domain ảo
  `https://appassets.androidplatform.net/...`) thay vì `file://`, để `<script type="module">`
  và `fetch()` trong `main.js` chạy đúng, không bị chặn CORS như WebView hay gặp với `file://`.
- `domStorageEnabled = true` nên `localStorage` (chỗ game gọi `saveGame()`) hoạt động bình
  thường, tiến trình được lưu giữa các lần mở app.
- **Không khóa cứng orientation** — `android:screenOrientation="unspecified"` trong
  `AndroidManifest.xml`, xoay ngang/dọc tự do.

## Đẩy lên GitHub

Mình không có quyền push trực tiếp lên GitHub từ phía mình, bạn chạy các lệnh sau ở máy bạn
(giải nén file zip mình gửi ra một thư mục rồi vào đó):

```bash
git init
git add .
git commit -m "Android WebView wrapper cho Tam Giới Tận Thế"
git branch -M main
git remote add origin git@github.com:<username>/<ten-repo>.git
git push -u origin main
```

Sau khi push, vào tab **Actions** trên GitHub — workflow **Build APK** sẽ tự chạy, build xong
tải APK debug ở mục **Artifacts** của run đó (tên `tam-gioi-tan-the-debug-apk`).

## Cập nhật game sau này

Khi sửa game xong, chỉ cần thay file `game.zip` ở gốc repo bằng bản zip mới rồi:

```bash
git add game.zip
git commit -m "Cập nhật nội dung game"
git push
```

CI tự unzip bản mới và build lại APK, không cần đụng gì tới phần Android.

## Icon & tên app

- Icon launcher hiện là placeholder (`app/src/main/res/drawable/ic_launcher_foreground.xml`) —
  nên thay bằng icon thật của game trước khi phát hành chính thức.
- Tên app: sửa `app_name` trong `app/src/main/res/values/strings.xml`.
- `applicationId`: `com.atun.tamgioitanthe` trong `app/build.gradle.kts`, đổi nếu cần.
