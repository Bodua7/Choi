package com.atun.tamgioitanthe

import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Vẽ nội dung ra sau thanh status/navigation (edge-to-edge, bắt buộc từ Android 15/SDK 35)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        webView = WebView(this)
        setContentView(webView)

        // Đệm nội dung theo system bar insets thay vì bị che, để không cần khóa orientation
        // mà vẫn tránh nội dung lọt dưới status bar / navigation bar / notch.
        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // cần cho localStorage (saveGame trong main.js)
            useWideViewPort = true
            loadWithOverviewMode = true
            // KHÔNG cần allowFileAccess nữa: WebViewAssetLoader phục vụ file qua
            // https://appassets.androidplatform.net/ thay vì file://
        }

        // QUAN TRỌNG: index.html dùng <script type="module">. WebView/Chromium CHẶN CORS
        // cho ES module khi tải qua scheme file:// (kể cả file:///android_asset/), khiến
        // main.js không chạy được -> không gắn được sự kiện click -> tab/nút vào trận
        // không bấm được. WebViewAssetLoader "giả lập" origin https:// hợp lệ để module
        // script load đúng.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler(
                "/assets/",
                WebViewAssetLoader.AssetsPathHandler(this)
            )
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
