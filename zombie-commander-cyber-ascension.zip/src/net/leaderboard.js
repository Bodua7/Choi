import { getSupabase, ensureAuthUserId } from './supabaseClient.js';
import { dbGet, dbSet, migrateFromLocalStorage } from '../core/db.js';

// Danh tính người chơi trên các tính năng online: từ bản chống-giả-mạo, đây là
// auth.uid() của phiên đăng nhập ẩn danh Supabase (KHÔNG còn là UUID tự sinh trong
// localStorage — client không còn quyền tự khai player_id). Tên hiển thị vẫn là
// text người chơi tự đặt, lưu local (IndexedDB), tách khỏi save-game chính (state.js).
const DISPLAY_NAME_KEY = 'zombie-stickman-leaderboard-name';

// getDisplayName() được panels.js gọi ĐỒNG BỘ lúc dựng UI (điền vào ô input), còn
// IndexedDB là API bất đồng bộ — nên giữ 1 cache trong bộ nhớ, nạp 1 lần lúc module
// này được import (kèm di trú dữ liệu cũ từ localStorage nếu có), rồi cập nhật ngay
// cache mỗi khi setDisplayName() được gọi.
let cachedDisplayName = '';
const displayNameReady = (async () => {
    await migrateFromLocalStorage(DISPLAY_NAME_KEY);
    const stored = await dbGet(DISPLAY_NAME_KEY);
    if (typeof stored === 'string') cachedDisplayName = stored;
})();

let cachedPlayerId = null;

// Đảm bảo đã đăng nhập ẩn danh và trả về player_id thật (auth.uid()) — PHẢI await
// hàm này trước khi nộp điểm/tấn công Boss/đấu Arena, hoặc trước khi cần so sánh
// "đây có phải dòng của tôi không" trong 1 danh sách kết quả từ server.
export async function ensurePlayerId() {
    if (cachedPlayerId) return cachedPlayerId;
    cachedPlayerId = await ensureAuthUserId();
    return cachedPlayerId;
}

// Getter đồng bộ, dùng cho UI không tiện await (vd. so sánh nhanh trong vòng lặp
// render danh sách) — trả về '' nếu ensurePlayerId() chưa từng được gọi/hoàn tất.
// Luôn gọi ensurePlayerId() trước ở nơi khởi tạo panel để giá trị này sẵn sàng kịp.
export function getLocalPlayerId() {
    return cachedPlayerId || '';
}

// Đồng bộ (dùng khi dựng UI) — trả về cache trong bộ nhớ. Gần như luôn đã sẵn sàng
// vì displayNameReady được nạp ngay từ lúc module này được import (main.js import
// leaderboard.js sớm), rất lâu trước khi người chơi thật sự mở tab Bảng Xếp Hạng.
export function getDisplayName() {
    return cachedDisplayName;
}

export function setDisplayName(name) {
    cachedDisplayName = name;
    dbSet(DISPLAY_NAME_KEY, name); // ghi IndexedDB bất đồng bộ, không chặn UI
}

// Cho nơi gọi nào muốn chắc chắn cache đã nạp xong trước khi đọc (không bắt buộc).
export function ensureDisplayNameLoaded() {
    return displayNameReady;
}

// Nộp điểm hiện tại lên bảng xếp hạng (upsert theo player_id của thiết bị này —
// player_id giờ lấy từ phiên đăng nhập ẩn danh thật, RLS phía server đối chiếu
// auth.uid() = player_id nên không thể ghi đè điểm của người khác nữa)
export async function submitScore(state) {
    const supabase = getSupabase();
    if (!supabase) return { ok: false, error: 'Chưa cấu hình Supabase (kiểm tra .env)' };

    const playerId = await ensurePlayerId();
    if (!playerId) return { ok: false, error: 'Đăng nhập ẩn danh Supabase thất bại — kiểm tra đã bật Anonymous Sign-Ins chưa.' };
    const displayName = getDisplayName() || 'Người Chơi Ẩn Danh';

    const { error } = await supabase.from('leaderboard').upsert({
        player_id: playerId,
        display_name: displayName,
        combat_power: state.getTotalAttack().toString(), // numeric ở Postgres nhận string an toàn cho số lớn
        swarm_count: state.swarmCount,
        highest_cleared: state.highestCleared,
        updated_at: new Date().toISOString()
    });

    if (error) return { ok: false, error: error.message };
    return { ok: true };
}

// Lấy top N người chơi theo sát thương (combat_power), giảm dần
export async function fetchTop(limit = 20) {
    const supabase = getSupabase();
    if (!supabase) return { ok: false, error: 'Chưa cấu hình Supabase (kiểm tra .env)', rows: [] };

    const { data, error } = await supabase
        .from('leaderboard')
        .select('player_id, display_name, combat_power, swarm_count, highest_cleared')
        .order('combat_power', { ascending: false })
        .limit(limit);

    if (error) return { ok: false, error: error.message, rows: [] };
    return { ok: true, rows: data || [] };
}
