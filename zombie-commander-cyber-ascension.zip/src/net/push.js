// --- Web Push: đăng ký/hủy nhận thông báo đẩy thật (hoạt động cả khi đã đóng app) ---
// LƯU Ý QUAN TRỌNG (đọc README-push.md để biết chi tiết): phần này chỉ lo "nửa
// client" của Web Push — xin quyền, subscribe PushManager, lưu subscription lên
// Supabase. Để THỰC SỰ gửi được thông báo (vd. "Tài nguyên đã đầy, quay lại thu
// hoạch!"), cần 1 tiến trình phía server (cron / Supabase Edge Function) dùng thư
// viện web-push + VAPID_PRIVATE_KEY để bắn tới các subscription đã lưu. Sandbox
// này không có mạng nên không tự triển khai Edge Function được — xem file mẫu
// supabase/functions/send-push/index.ts để tự deploy bằng Supabase CLI.
import { getSupabase } from './supabaseClient.js';
import { ensurePlayerId } from './leaderboard.js';

const VAPID_PUBLIC_KEY = import.meta.env.VITE_VAPID_PUBLIC_KEY;

export function isPushSupported() {
    return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
}

export function getPermissionState() {
    if (!('Notification' in window)) return 'unsupported';
    return Notification.permission; // 'default' | 'granted' | 'denied'
}

// Chuyển VAPID public key (base64url) sang Uint8Array — định dạng applicationServerKey yêu cầu
function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; i++) outputArray[i] = rawData.charCodeAt(i);
    return outputArray;
}

// Xin quyền + đăng ký subscription, lưu lên Supabase (bảng push_subscriptions).
// Trả về { ok, error? }.
export async function enablePush() {
    if (!isPushSupported()) return { ok: false, error: 'Trình duyệt này không hỗ trợ Web Push.' };
    if (!VAPID_PUBLIC_KEY) return { ok: false, error: 'Chưa cấu hình VITE_VAPID_PUBLIC_KEY trong .env.' };

    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
        return { ok: false, error: permission === 'denied'
            ? 'Bạn đã chặn thông báo — cần vào cài đặt trình duyệt để bật lại.'
            : 'Chưa cấp quyền thông báo.' };
    }

    const registration = await navigator.serviceWorker.ready;
    let subscription = await registration.pushManager.getSubscription();
    if (!subscription) {
        subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true, // bắt buộc: mọi push phải hiện thông báo cho người dùng thấy
            applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
        });
    }

    const saveResult = await saveSubscription(subscription);
    if (!saveResult.ok) return saveResult;
    return { ok: true };
}

async function saveSubscription(subscription) {
    const supabase = getSupabase();
    if (!supabase) {
        // Chưa cấu hình Supabase: vẫn coi là "đã bật" cục bộ (trình duyệt đã subscribe),
        // chỉ là chưa có nơi lưu để 1 server sau này gửi push tới được.
        console.warn('Supabase chưa cấu hình — subscription chỉ tồn tại cục bộ, server sẽ không gửi được push.');
        return { ok: true };
    }
    const playerId = await ensurePlayerId();
    if (!playerId) return { ok: false, error: 'Đăng nhập ẩn danh Supabase thất bại, không lưu được subscription.' };

    const json = subscription.toJSON();
    const { error } = await supabase.from('push_subscriptions').upsert({
        player_id: playerId,
        endpoint: json.endpoint,
        p256dh: json.keys?.p256dh,
        auth: json.keys?.auth,
        updated_at: new Date().toISOString()
    }, { onConflict: 'endpoint' });

    if (error) return { ok: false, error: error.message };
    return { ok: true };
}

// Hủy subscription (trình duyệt + xóa khỏi Supabase nếu có)
export async function disablePush() {
    if (!isPushSupported()) return { ok: false, error: 'Trình duyệt này không hỗ trợ Web Push.' };
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();
    if (!subscription) return { ok: true };

    const endpoint = subscription.endpoint;
    await subscription.unsubscribe();

    const supabase = getSupabase();
    if (supabase) {
        await supabase.from('push_subscriptions').delete().eq('endpoint', endpoint);
    }
    return { ok: true };
}

// Trạng thái hiện tại: đã có subscription hoạt động trong trình duyệt hay chưa
export async function isPushEnabled() {
    if (!isPushSupported()) return false;
    try {
        const registration = await navigator.serviceWorker.ready;
        const subscription = await registration.pushManager.getSubscription();
        return !!subscription;
    } catch (e) {
        return false;
    }
}

// Thông báo CỤC BỘ (local notification) — không cần server, hoạt động ngay khi
// tab đang mở/ẩn (không hoạt động khi app đã đóng hẳn, khác với push thật ở trên).
// Dùng cho phản hồi tức thì: hồi sinh xong, Phó Bản mới mở, vé Đấu Trường đầy...
export async function showLocalNotification(title, options = {}) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        registration.showNotification(title, {
            icon: '/icon.svg',
            badge: '/icon.svg',
            ...options
        });
    } else {
        new Notification(title, options);
    }
}
