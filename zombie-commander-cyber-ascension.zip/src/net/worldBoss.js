// Boss Cốt Truyện dùng chung server (GDD mục 7.3, gap "World Boss chung server"):
// khác với Boss Phó Bản (state.js, mỗi người chơi đánh riêng), Boss ở đây có 1 thanh
// HP DUY NHẤT chia sẻ cho toàn bộ người chơi qua Supabase — mọi lượt tấn công đều
// trừ vào cùng 1 giá trị, cần hạ gục cùng nhau. Toàn bộ phép cộng trừ HP chạy qua 2
// hàm RPC nguyên tử trong supabase/worldboss.sql (deal_world_boss_damage /
// advance_world_boss_cycle) để tránh mất sát thương do nhiều client ghi đè nhau.
import { getSupabase } from './supabaseClient.js';
import { ensurePlayerId, getDisplayName } from './leaderboard.js';

// Đọc trạng thái Boss hiện tại (HP còn lại, HP tối đa, chu kỳ)
export async function fetchWorldBoss() {
    const supabase = getSupabase();
    if (!supabase) return { ok: false, error: 'Chưa cấu hình Supabase (kiểm tra .env)', boss: null };

    const { data, error } = await supabase
        .from('world_boss')
        .select('boss_name, hp_remaining, max_hp, cycle_number, started_at')
        .eq('id', 1)
        .single();

    if (error) return { ok: false, error: error.message, boss: null };
    return { ok: true, boss: data };
}

// Tung 1 đòn đánh vào Boss chung server — damage là sát thương 1 lần (thường là
// tổng công của Bầy, state.getTotalAttack()). Trả về killed=true nếu đòn này vừa
// hạ gục Boss (dùng để hiện toast + tự gọi advanceWorldBossCycle()).
// Danh tính người đánh (player_id) không còn gửi từ client — hàm SQL tự lấy từ
// auth.uid() của phiên đăng nhập ẩn danh, nên không thể "đánh hộ" dưới tên người khác.
export async function dealWorldBossDamage(damage) {
    const supabase = getSupabase();
    if (!supabase) return { ok: false, error: 'Chưa cấu hình Supabase (kiểm tra .env)' };

    const playerId = await ensurePlayerId();
    if (!playerId) return { ok: false, error: 'Đăng nhập ẩn danh Supabase thất bại — kiểm tra đã bật Anonymous Sign-Ins chưa.' };

    const { data, error } = await supabase.rpc('deal_world_boss_damage', {
        p_display_name: getDisplayName() || 'Người Chơi Ẩn Danh',
        p_damage: damage.toString() // numeric ở Postgres nhận string an toàn cho số lớn (BigInt)
    });

    if (error) return { ok: false, error: error.message };
    const row = Array.isArray(data) ? data[0] : data;
    return { ok: true, ...row };
}

// Top người đóng góp sát thương nhiều nhất trong chu kỳ hiện tại
export async function fetchWorldBossTop(cycleNumber, limit = 20) {
    const supabase = getSupabase();
    if (!supabase) return { ok: false, error: 'Chưa cấu hình Supabase (kiểm tra .env)', rows: [] };

    const { data, error } = await supabase
        .from('world_boss_damage')
        .select('player_id, display_name, total_damage')
        .eq('cycle_number', cycleNumber)
        .order('total_damage', { ascending: false })
        .limit(limit);

    if (error) return { ok: false, error: error.message, rows: [] };
    return { ok: true, rows: data || [] };
}

// Mở chu kỳ Boss kế tiếp (HP +35%) — chỉ thật sự có tác dụng nếu HP hiện tại đã về
// 0 (an toàn khi nhiều người chơi cùng gọi lúc Boss vừa chết).
export async function advanceWorldBossCycle() {
    const supabase = getSupabase();
    if (!supabase) return { ok: false, error: 'Chưa cấu hình Supabase (kiểm tra .env)' };

    const { data, error } = await supabase.rpc('advance_world_boss_cycle');
    if (error) return { ok: false, error: error.message };
    const row = Array.isArray(data) ? data[0] : data;
    return { ok: true, ...row };
}
