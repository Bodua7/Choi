// Đấu Trường PvP THẬT (bất đồng bộ) — tìm đối thủ bằng cách đọc chiến lực (combat_power)
// mà người chơi khác đã tự nộp lên bảng `leaderboard` (net/leaderboard.js), thay vì
// sinh ngẫu nhiên quanh chính chiến lực của mình như ArenaState.generateOpponent() (giờ
// chỉ còn dùng làm dự phòng khi chưa có ai gần chiến lực, xem core/arena.js). Việc ghi
// log trận đấu đi qua RPC record_arena_match() (supabase/arena.sql) để không cho client
// tự ý ghi thẳng vào bảng chung.
import { getSupabase } from './supabaseClient.js';
import { ensurePlayerId, getDisplayName } from './leaderboard.js';

// Tìm đối thủ thật gần chiến lực hiện tại nhất (cả cao hơn lẫn thấp hơn, để không
// luôn thắng hoặc luôn thua) — Supabase JS không hỗ trợ order theo |a-b| trực tiếp
// nên dùng 2 truy vấn range rồi gộp + sắp lại theo khoảng cách ở phía client.
export async function fetchArenaOpponents(myAttack, limit = 5) {
    const supabase = getSupabase();
    if (!supabase) return { ok: false, error: 'Chưa cấu hình Supabase (kiểm tra .env)', rows: [] };

    const myId = await ensurePlayerId();
    if (!myId) return { ok: false, error: 'Đăng nhập ẩn danh Supabase thất bại — kiểm tra đã bật Anonymous Sign-Ins chưa.', rows: [] };
    const myCp = Number(myAttack);

    const [higherRes, lowerRes] = await Promise.all([
        supabase.from('leaderboard')
            .select('player_id, display_name, combat_power')
            .neq('player_id', myId)
            .gte('combat_power', myCp)
            .order('combat_power', { ascending: true })
            .limit(limit),
        supabase.from('leaderboard')
            .select('player_id, display_name, combat_power')
            .neq('player_id', myId)
            .lt('combat_power', myCp)
            .order('combat_power', { ascending: false })
            .limit(limit)
    ]);

    if (higherRes.error) return { ok: false, error: higherRes.error.message, rows: [] };
    if (lowerRes.error) return { ok: false, error: lowerRes.error.message, rows: [] };

    const merged = [...(higherRes.data || []), ...(lowerRes.data || [])];
    merged.sort((a, b) => Math.abs(Number(a.combat_power) - myCp) - Math.abs(Number(b.combat_power) - myCp));

    return { ok: true, rows: merged.slice(0, limit) };
}

// Ghi log 1 trận đấu vào bảng chung (để defender thấy trong "Bạn Vừa Bị Thách Đấu Bởi")
// — danh tính attacker (mình) không còn gửi từ client, hàm SQL tự lấy từ auth.uid()
// nên không thể ghi khống trận đấu dưới tên người khác.
export async function recordArenaMatch({ defenderId, defenderName, myAttack, defenderAttack, win }) {
    const supabase = getSupabase();
    if (!supabase) return { ok: false, error: 'Chưa cấu hình Supabase (kiểm tra .env)' };

    const myId = await ensurePlayerId();
    if (!myId) return { ok: false, error: 'Đăng nhập ẩn danh Supabase thất bại — kiểm tra đã bật Anonymous Sign-Ins chưa.' };

    const { error } = await supabase.rpc('record_arena_match', {
        p_attacker_name: getDisplayName() || 'Người Chơi Ẩn Danh',
        p_defender_id: defenderId,
        p_defender_name: defenderName,
        p_attacker_cp: myAttack.toString(),
        p_defender_cp: defenderAttack.toString(),
        p_win: win
    });

    if (error) return { ok: false, error: error.message };
    return { ok: true };
}

// Nhật ký các lần bị người chơi khác thách đấu gần đây (mình là defender)
export async function fetchArenaDefenseLog(limit = 10) {
    const supabase = getSupabase();
    if (!supabase) return { ok: false, error: 'Chưa cấu hình Supabase (kiểm tra .env)', rows: [] };

    const myId = await ensurePlayerId();
    if (!myId) return { ok: false, error: 'Đăng nhập ẩn danh Supabase thất bại — kiểm tra đã bật Anonymous Sign-Ins chưa.', rows: [] };

    const { data, error } = await supabase
        .from('arena_matches')
        .select('attacker_name, attacker_cp, win, created_at')
        .eq('defender_id', myId)
        .order('created_at', { ascending: false })
        .limit(limit);

    if (error) return { ok: false, error: error.message, rows: [] };
    return { ok: true, rows: data || [] };
}
