// Client Supabase dùng chung cho các tính năng cần backend thật: hiện đã dùng cho
// Bảng Xếp Hạng (leaderboard.js). Các tính năng sau (PvP bất đồng bộ, World Boss
// chung server) có thể tái dùng cùng client này.
import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

let client = null;

// Lazy-init: không throw khi chưa cấu hình .env (để phần còn lại của game vẫn chạy
// offline-first bình thường nếu người chơi build mà chưa điền Supabase).
export function getSupabase() {
    if (client) return client;
    if (!url || !anonKey) {
        console.warn('Supabase chưa được cấu hình — kiểm tra file .env (xem .env.example).');
        return null;
    }
    client = createClient(url, anonKey);
    return client;
}

// --- Chống giả mạo player_id (xem ghi chú trong supabase/*.sql) ---
// Trước bản này, mọi tính năng online (Bảng Xếp Hạng, Boss TG, Đấu Trường) nhận
// player_id do CHÍNH CLIENT tự khai báo trong lệnh gọi — bất kỳ ai cũng có thể tự
// gọi RPC/insert với player_id của người khác để nộp điểm giả, "đánh hộ" Boss dưới
// tên người khác, hoặc ghi khống kết quả Đấu Trường. Từ bản này, danh tính người
// chơi lấy từ phiên đăng nhập ẩn danh thật của Supabase Auth (auth.uid()) — client
// không còn được quyền tự khai player_id, mọi RPC/policy phía server đều đối chiếu
// với auth.uid() của chính request đó.
let authIdPromise = null;

// Đảm bảo đã đăng nhập ẩn danh (Supabase Anonymous Sign-In), trả về uid ổn định
// cho thiết bị này. Cache lại thành 1 Promise dùng chung để nhiều lệnh gọi cùng lúc
// (vd. mở panel Bảng Xếp Hạng) không kích hoạt nhiều lần đăng nhập song song.
export function ensureAuthUserId() {
    const supabase = getSupabase();
    if (!supabase) return Promise.resolve(null);
    if (authIdPromise) return authIdPromise;

    authIdPromise = (async () => {
        try {
            const { data: sessionData } = await supabase.auth.getSession();
            if (sessionData?.session?.user?.id) return sessionData.session.user.id;

            const { data, error } = await supabase.auth.signInAnonymously();
            if (error) throw error;
            return data?.user?.id ?? null;
        } catch (err) {
            console.error('Đăng nhập ẩn danh Supabase thất bại — kiểm tra đã bật ' +
                '"Anonymous Sign-Ins" trong Supabase Dashboard > Authentication > Providers chưa:', err.message || err);
            authIdPromise = null; // cho phép thử lại ở lần gọi sau
            return null;
        }
    })();
    return authIdPromise;
}
