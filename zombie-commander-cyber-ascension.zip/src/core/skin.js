// Skin (mở khóa qua Triệu Hồi mock) đổi màu neon hiển thị trong bảng trạng thái Bầy
// Zombie (main.js), KHÔNG phải hình dáng mới — game không còn viewport 3D.
// Mở khóa qua Triệu Hồi mock (gacha.js) bằng tài nguyên trong game — không có cổng
// thanh toán thật nào ở đây.
export const SKINS = [
    { id: 'default', name: 'Mặc Định (theo Tiến Hóa/Vùng)', color: null }, // null = dùng màu evo/region như cũ
    { id: 'neon_pink', name: 'Hồng Neon', color: 0xff33cc },
    { id: 'toxic_green', name: 'Lục Độc', color: 0x33ff66 },
    { id: 'royal_gold', name: 'Kim Hoàng Gia', color: 0xffd700 },
    { id: 'void_purple', name: 'Tím Tinh Không', color: 0x9933ff },
    { id: 'blood_crimson', name: 'Đỏ Huyết Sắc', color: 0xcc0033 }
];

export function getSkinById(id) {
    return SKINS.find(s => s.id === id) || SKINS[0];
}
