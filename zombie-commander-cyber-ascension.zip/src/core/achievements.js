// Thành Tựu dài hạn: mục tiêu xuyên suốt nhiều vòng Chuyển Sinh, không reset khi
// Chuyển Sinh (đúng tinh thần "ưu tiên tính năng bền vững lâu dài" cho người chơi solo).
// check(state) đọc trực tiếp từ GameState — không lưu điều kiện trùng lặp ở nơi khác.
export const ACHIEVEMENTS = [
    { id: 'first_clear', name: 'Bước Chân Đầu Tiên', desc: 'Vượt qua Bậc Phó Bản đầu tiên.',
        check: (state) => state.highestCleared >= 1 },
    { id: 'licker', name: 'Tốc Độ Trinh Sát', desc: 'Phân Thân tiến hóa thành Licker.',
        check: (state) => state.highestCleared >= 3 },
    { id: 'tyrant', name: 'Bức Tường Thép', desc: 'Phân Thân tiến hóa thành Tyrant.',
        check: (state) => state.highestCleared >= 8 },
    { id: 'da_he', name: 'Đa Hệ Cộng Hưởng', desc: 'Phân Thân đạt trạng thái Đa Hệ Cộng Hưởng.',
        check: (state) => state.highestCleared >= 25 },
    { id: 'swarm_100', name: 'Trăm Quân Trong Tay', desc: 'Bầy Zombie Phân Thân đạt 100.',
        check: (state) => state.swarmCount >= 100 },
    { id: 'swarm_10000', name: 'Vạn Quân Áp Đảo', desc: 'Bầy Zombie Phân Thân đạt 10.000.',
        check: (state) => state.swarmCount >= 10000 },
    { id: 'first_rebirth', name: 'Vòng Lặp Đầu Tiên', desc: 'Hoàn thành lần Chuyển Sinh đầu tiên.',
        check: (state) => state.rebirthCount >= 1 },
    { id: 'rebirth_10', name: 'Bậc Thầy Vòng Lặp', desc: 'Hoàn thành 10 lần Chuyển Sinh.',
        check: (state) => state.rebirthCount >= 10 }
];

// Trả về danh sách id Thành Tựu vừa mới đạt được (chưa có trong `unlockedIds` cũ)
export function computeNewlyUnlocked(state, unlockedIds) {
    const result = [];
    for (const ach of ACHIEVEMENTS) {
        if (!unlockedIds.includes(ach.id) && ach.check(state)) result.push(ach.id);
    }
    return result;
}
