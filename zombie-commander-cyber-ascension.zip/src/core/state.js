import { GAME_SYSTEMS } from './systems.js';
import { ProgressionEngine } from './math.js';
import { MAP_REGIONS, getRegionById } from './content/mapNodes.js';
import { getEvolutionStageFor, getNextEvolutionStage } from './content/zombieEvolution.js';
import { getArcFor, getLatestBeat, getBeatUnlockedAtStage } from './content/story.js';
import { getResurrectionEventForRegion } from './content/resurrectionEvents.js';
import { MATERIAL_TIERS, getConvertCost, createMaterialInventory } from './materials.js';
import { canRebirth as checkCanRebirth, getRebirthBonusBP, REBIRTH_UNLOCK_STAGE } from './rebirth.js';
import { computeNewlyUnlocked } from './achievements.js';
import { getCharacterTitle } from './content/characterTitles.js';
import { getUnlockedAllies, getNextAlly } from './content/allies.js';
import { ArenaState } from './arena.js';
import { dbGet, dbSet, migrateFromLocalStorage } from './db.js';

const SAVE_KEY = 'zombie-stickman-save-v1';
const BP_BASE = 100000n; // 100.000 basis points = hệ số nhân x1

// Tài nguyên cơ bản: sản lượng/giây do TECH_TREE + swarmCount quyết định
const RESOURCE_KEYS = ['wood', 'stone', 'core', 'crystal'];

const BASE_CAPACITY = 50;      // sức chứa Phân Thân tối thiểu (chưa nâng cấp Hầm Trú Ẩn)
const BASE_SURVIVAL_BP = 40000n; // 40% cơ hội sống sót cơ bản khi thua Phó Bản (chưa có Thần Thụ/Đan Dược)
const MAX_SURVIVAL_BP = 95000n;  // trần 95% (không bao giờ vô hại tuyệt đối)

export class GameState {
    constructor() {
        this.resources = { wood: 0n, stone: 0n, core: 0n, crystal: 0n };

        // Mỗi hệ thống trong 12 Hệ thống Cốt lõi: { level, tier, baseStat }
        this.systems = {};
        for (const key of Object.keys(GAME_SYSTEMS)) {
            const def = GAME_SYSTEMS[key];
            this.systems[key] = {
                level: 0,
                tier: 0,
                baseStat: BigInt(def.base)
            };
        }

        // Bầy Zombie Phân Thân dưới quyền chỉ huy (dùng cho EntityCondenser + chiến đấu)
        this.swarmCount = 1;
        this.highestCleared = 0; // Phó Bản: bậc cao nhất đã vượt qua (0 = chưa vượt bậc nào)
        this.lastDungeonResult = null; // { stageIndex, win, deaths } — hiển thị kết quả gần nhất
        this.currentRegion = MAP_REGIONS[0].id; // Bản Đồ: vùng hiện tại (mở khóa theo highestCleared)
        this.lastTimestamp = Date.now();

        // Hệ 8 - Vật Liệu: kho riêng ngoài 4 tài nguyên cơ bản (materials.js)
        this.materials = createMaterialInventory();

        // Chuyển Sinh (rebirth.js): số lần đã Chuyển Sinh, cộng dồn vĩnh viễn
        this.rebirthCount = 0;

        // Thành Tựu dài hạn (achievements.js): id đã mở khóa, không reset khi Chuyển Sinh
        this.unlockedAchievements = [];

        // Đấu Trường PvP giả lập (arena.js)
        this.arena = new ArenaState();

        // Skin (skin.js) + Triệu Hồi/Vé Mùa mock (gacha.js): mặc định luôn có skin 'default'
        this.unlockedSkins = ['default'];
        this.selectedSkin = 'default';
        this.claimedBattlePassTiers = [];
    }

    // --- Hệ 4 - Nhân Vật: thân phận hiện tại theo Bậc CHARACTER ---
    getCharacterTitle() {
        return getCharacterTitle(this.systems.CHARACTER.tier);
    }

    // --- Hệ 5 - Đồng Minh: danh sách đã mở khóa / người kế tiếp theo Bậc ALLY ---
    getUnlockedAllies() {
        return getUnlockedAllies(this.systems.ALLY.tier);
    }

    getNextAlly() {
        return getNextAlly(this.systems.ALLY.tier);
    }

    // --- Bản Đồ Thế Giới & Phe Phái ---
    getCurrentRegion() {
        return getRegionById(this.currentRegion);
    }

    isRegionUnlocked(regionId) {
        const region = getRegionById(regionId);
        return this.highestCleared >= region.unlockStage;
    }

    setRegion(regionId) {
        if (!this.isRegionUnlocked(regionId)) return false;
        this.currentRegion = regionId;
        return true;
    }

    // --- Nhánh Tiến Hóa Zombie Phân Thân (GDD 3.1) ---
    getEvolutionStage() {
        return getEvolutionStageFor(this.highestCleared);
    }

    getNextEvolutionStage() {
        return getNextEvolutionStage(this.highestCleared);
    }

    // --- Cốt truyện (GDD mục 3) ---
    getCurrentStoryArc() {
        return getArcFor(this.highestCleared);
    }

    getLatestStoryBeat() {
        return getLatestBeat(this.highestCleared);
    }

    // --- Hệ số nhân tổng hợp từ các Hệ Thống Cốt Lõi + phe Đồng Minh của vùng hiện tại
    // + bậc Tiến Hóa Zombie hiện tại (BigInt-safe, tính bằng basis points). power =
    // tier*100 + level (mỗi lần Đột Phá coi như +100 "power" cộng dồn vĩnh viễn).
    getMultiplierBP(effectType) {
        let bp = BP_BASE;
        for (const key of Object.keys(GAME_SYSTEMS)) {
            const def = GAME_SYSTEMS[key];
            const rate = def.affects && def.affects[effectType];
            if (!rate) continue;
            const sys = this.systems[key];
            const power = BigInt(sys.tier * 100 + sys.level);
            bp += power * BigInt(rate);
        }
        const region = this.getCurrentRegion();
        const regionBonus = region.allyFaction.effect && region.allyFaction.effect[effectType];
        if (regionBonus) bp += BigInt(regionBonus);
        const evoBonus = this.getEvolutionStage().bonus[effectType];
        if (evoBonus) bp += BigInt(evoBonus);
        // Chuyển Sinh: bonus vĩnh viễn áp dụng cho MỌI loại hiệu ứng (yield/atk/survival),
        // đúng thiết kế "+15% CP & tốc độ tài nguyên vĩnh viễn/lần" (rebirth.js)
        if (this.rebirthCount > 0) bp += getRebirthBonusBP(this.rebirthCount);
        // Trùng Tộc Swarm Bọ Cơ Khí: mở khóa khi Cây Công Nghệ đạt Bậc 4 (SYSTEM_TIER_NAMES.TECH_TREE[3]
        // = 'Mạng Lưới Swarm Bọ Cơ Khí'), sức mạnh tỉ lệ thuận Linh Kiện đang sở hữu (materials.js),
        // áp dụng cho atk & yield, giới hạn trần +50% để không phá vỡ cân bằng số liệu gốc
        if (this.systems.TECH_TREE.tier >= 3 && (effectType === 'atk' || effectType === 'yield')) {
            const swarmBonus = this.materials.linh_kien * 10n;
            bp += swarmBonus > 50000n ? 50000n : swarmBonus;
        }
        return bp;
    }

    // --- Hệ 8 - Vật Liệu: khai thác Bậc 0 thụ động + quy đổi lên Bậc kế tiếp ---
    getMaterialYieldPerSec() {
        // Khai thác Phế Liệu tỉ lệ thuận Bầy Zombie, chậm hơn hẳn 4 tài nguyên cơ bản
        // (Vật Liệu quý hơn — đúng vai trò "nguyên liệu cấp cao" trong GDD mục 2.2)
        return BigInt(Math.max(0, Math.floor(this.swarmCount / 10)));
    }

    getMaterialConvertCost(tierIndex) {
        return getConvertCost(tierIndex);
    }

    canConvertMaterial(tierIndex) {
        if (tierIndex >= MATERIAL_TIERS.length - 1) return false; // Bậc cao nhất, không quy đổi tiếp
        const fromId = MATERIAL_TIERS[tierIndex].id;
        return this.materials[fromId] >= this.getMaterialConvertCost(tierIndex);
    }

    convertMaterial(tierIndex) {
        if (!this.canConvertMaterial(tierIndex)) return false;
        const fromId = MATERIAL_TIERS[tierIndex].id;
        const toId = MATERIAL_TIERS[tierIndex + 1].id;
        this.materials[fromId] -= this.getMaterialConvertCost(tierIndex);
        this.materials[toId] += 1n;
        return true;
    }

    // --- Chuyển Sinh (rebirth.js): endgame cho vòng lặp treo máy dài hạn ---
    canRebirth() {
        return checkCanRebirth(this.highestCleared);
    }

    doRebirth() {
        if (!this.canRebirth()) return false;
        this.resources = { wood: 0n, stone: 0n, core: 0n, crystal: 0n };
        this.materials = createMaterialInventory();
        for (const key of Object.keys(GAME_SYSTEMS)) {
            const def = GAME_SYSTEMS[key];
            this.systems[key] = { level: 0, tier: 0, baseStat: BigInt(def.base) };
        }
        this.swarmCount = 1;
        this.highestCleared = 0;
        this.currentRegion = MAP_REGIONS[0].id;
        this.lastDungeonResult = null;
        this.rebirthCount += 1;
        // Chỉ rebirthCount và unlockedAchievements giữ nguyên xuyên vòng Chuyển Sinh —
        // đây chính là "tiến trình bền vững lâu dài" (Thành Tựu không mất, bonus vĩnh
        // viễn không mất); highestCleared reset về 0 để leo lại Phó Bản, nhưng giờ leo
        // nhanh hơn hẳn nhờ +15%/lần đã cộng vào getMultiplierBP()
        return true;
    }

    // --- Thành Tựu dài hạn (achievements.js) ---
    checkAchievements() {
        const newlyUnlocked = computeNewlyUnlocked(this, this.unlockedAchievements);
        if (newlyUnlocked.length > 0) this.unlockedAchievements.push(...newlyUnlocked);
        return newlyUnlocked;
    }

    // Tỉ lệ sống sót khi thua Phó Bản (Thần Thụ + Đan Dược), trần 95%
    getSurvivalBP() {
        const bonus = this.getMultiplierBP('survival') - BP_BASE; // phần cộng thêm từ 2 hệ thống
        let bp = BASE_SURVIVAL_BP + bonus;
        if (bp > MAX_SURVIVAL_BP) bp = MAX_SURVIVAL_BP;
        return bp;
    }

    // Sức chứa Phân Thân tối đa hiện tại (Hầm Trú Ẩn / Bán Giới)
    getMaxCapacity() {
        const sys = this.systems.SHELTER;
        const def = GAME_SYSTEMS.SHELTER;
        const power = sys.tier * 100 + sys.level;
        return BASE_CAPACITY + power * def.affects.capacity;
    }

    // Sản lượng tài nguyên/giây hiện tại, suy ra từ cấp TECH_TREE (+d_yield), swarmCount
    // và hệ số nhân tổng hợp từ Kỹ Năng / Đồng Minh / Rèn Đúc / Vật Liệu / Phương Hằng
    getYieldPerSec(resourceKey) {
        const tech = this.systems.TECH_TREE;
        const techDef = GAME_SYSTEMS.TECH_TREE;
        const baseYield = ProgressionEngine.calculateStat(techDef.base, tech.level, techDef.growth) + tech.baseStat - BigInt(techDef.base);
        // Mỗi loại tài nguyên có trọng số base khác nhau để tạo cảm giác khan hiếm dần
        const weight = { wood: 4n, stone: 3n, core: 2n, crystal: 1n }[resourceKey];
        const yieldBP = this.getMultiplierBP('yield');
        return (baseYield * weight * BigInt(Math.max(1, this.swarmCount)) * yieldBP) / BP_BASE;
    }

    // Áp dụng thời gian trôi qua (offline hoặc mỗi tick) bằng công thức O(1) cấp số cộng
    applyElapsedSeconds(seconds) {
        if (seconds <= 0) return null;
        const gained = {};
        for (const key of RESOURCE_KEYS) {
            const perSec = this.getYieldPerSec(key);
            // growth theo thời gian giữ = 0 (sản lượng ổn định trong khoảng T, không cấp số cộng theo giây)
            const total = ProgressionEngine.calculateIdleYield(perSec, 0n, seconds);
            this.resources[key] += total;
            gained[key] = total;
        }
        // Hệ 8 - Vật Liệu: Phế Liệu (Bậc 0) khai thác thụ động cùng nhịp treo máy
        const scrapPerSec = this.getMaterialYieldPerSec();
        const scrapTotal = ProgressionEngine.calculateIdleYield(scrapPerSec, 0n, seconds);
        this.materials[MATERIAL_TIERS[0].id] += scrapTotal;
        gained.material = scrapTotal;
        return gained;
    }

    getUpgradeCost(systemKey) {
        const def = GAME_SYSTEMS[systemKey];
        const sys = this.systems[systemKey];
        // Dùng "core" làm tài nguyên nâng cấp chung, chi phí theo cấp số cộng
        return ProgressionEngine.calculateUpgradeCost(def.base * 10, sys.level, def.growth * 4);
    }

    canUpgrade(systemKey) {
        const sys = this.systems[systemKey];
        if (sys.level >= 100) return false;
        return this.resources.core >= this.getUpgradeCost(systemKey);
    }

    upgradeSystem(systemKey) {
        const sys = this.systems[systemKey];
        const def = GAME_SYSTEMS[systemKey];
        if (sys.level >= 100) {
            // performBreakthrough đọc entity.tierDelta -> gắn tạm từ định nghĩa hệ thống trước khi gọi
            sys.tierDelta = def.tierDelta;
            const didBreak = ProgressionEngine.performBreakthrough(sys);
            delete sys.tierDelta;
            return didBreak ? 'breakthrough' : false;
        }
        const cost = this.getUpgradeCost(systemKey);
        if (this.resources.core < cost) return false;
        this.resources.core -= cost;
        sys.level += 1;
        return 'upgrade';
    }

    // Tổng sát thương chiến đấu hiện tại của toàn bộ Bầy Zombie (dùng cho Sweep / Phó Bản)
    // Kết hợp Trang Bị (sát thương/đơn vị) với hệ số nhân từ Thần Thông / Pháp Trận / Phương Hằng
    getTotalAttack() {
        const eq = this.systems.EQUIPMENT;
        const eqDef = GAME_SYSTEMS.EQUIPMENT;
        const perUnitAtk = ProgressionEngine.calculateStat(eqDef.base, eq.level, eqDef.growth)
            + eq.baseStat - BigInt(eqDef.base);
        const atkBP = this.getMultiplierBP('atk');
        return (perUnitAtk * BigInt(Math.max(1, this.swarmCount)) * atkBP) / BP_BASE;
    }

    // --- Chiêu Mộ: tăng Bầy Zombie Phân Thân (thay vì chỉ tăng qua nút Sweep) ---
    getRecruitCost() {
        const woodCost = BigInt(20 + this.swarmCount * 5);
        const stoneCost = BigInt(10 + this.swarmCount * 3);
        // Đan Dược giảm chi phí chiêu mộ, tối đa 50%
        const discountBP = this.getMultiplierBP('recruitDiscount') - BP_BASE;
        const cappedDiscount = discountBP > 50000n ? 50000n : discountBP;
        return {
            wood: woodCost - (woodCost * cappedDiscount) / BP_BASE,
            stone: stoneCost - (stoneCost * cappedDiscount) / BP_BASE
        };
    }

    canRecruit() {
        if (this.swarmCount >= this.getMaxCapacity()) return false;
        const cost = this.getRecruitCost();
        return this.resources.wood >= cost.wood && this.resources.stone >= cost.stone;
    }

    recruit() {
        if (!this.canRecruit()) return false;
        const cost = this.getRecruitCost();
        this.resources.wood -= cost.wood;
        this.resources.stone -= cost.stone;
        this.swarmCount += 1;
        return true;
    }

    // --- Phó Bản: chiến đấu idle-tức-thì (so tổng sát thương với HP Boss) ---
    // Đúng tinh thần "1 tỷ vòng lặp không tràn số" của GDD: HP Boss tăng thuần cấp số
    // cộng theo bậc (không lũy thừa), Bậc 1 luôn thắng được ngay từ đầu game, các bậc
    // sau đòi hỏi nâng Trang Bị / Thần Thông / Pháp Trận / Phương Hằng để vượt qua.
    // Phe Đối Địch của vùng hiện tại (Bản Đồ) nhân thêm % HP Boss (bossHpBP).
    getDungeonStage(stageIndex) {
        const baseHP = 60n + BigInt(stageIndex) * 40n;
        const region = this.getCurrentRegion();
        const bossHpBP = BigInt(region.rivalFaction.bossHpBP || 100000);
        const bossHP = (baseHP * bossHpBP) / BP_BASE;
        return {
            stageIndex,
            bossHP,
            rewardCore: BigInt(5 + stageIndex * 3),
            rewardCrystal: BigInt(1 + Math.floor(stageIndex / 3))
        };
    }

    // resurrection: đối tượng ResurrectionManager để đưa các Phân Thân tử trận vào hàng chờ tái tạo
    enterDungeonStage(resurrection) {
        const stageIndex = this.highestCleared; // luôn đánh bậc kế tiếp chưa vượt qua
        const stage = this.getDungeonStage(stageIndex);
        const playerAtk = this.getTotalAttack();

        if (playerAtk >= stage.bossHP) {
            this.resources.core += stage.rewardCore;
            this.resources.crystal += stage.rewardCrystal;
            this.highestCleared += 1;
            // Mốc truyện + Tiến Hóa Zombie đúng vào Bậc vừa mở khóa (nếu có) — hiển thị
            // như phần thưởng tường thuật ngay khi thắng, không phải chỉ xem trong lore tĩnh
            const storyBeat = getBeatUnlockedAtStage(this.highestCleared);
            const evolvedTo = getEvolutionStageFor(this.highestCleared).unlockStage === this.highestCleared
                ? getEvolutionStageFor(this.highestCleared) : null;
            this.lastDungeonResult = { stageIndex, win: true, deaths: 0, storyBeat, evolvedTo };
            return this.lastDungeonResult;
        }

        // Thua: một phần Phân Thân tử trận, chuyển sang "Chờ Tái Tạo Data" thay vì bị xóa
        const survivalBP = this.getSurvivalBP();
        const lossFractionBP = BP_BASE - survivalBP; // % tổn thất, sau khi trừ tỉ lệ sống sót
        let deaths = Math.floor((this.swarmCount * Number(lossFractionBP)) / 100000 / 3); // giới hạn tổn thất mỗi trận
        if (deaths > this.swarmCount - 1) deaths = this.swarmCount - 1; // luôn giữ lại ít nhất 1 Phân Thân
        if (deaths < 0) deaths = 0;

        if (deaths > 0 && resurrection) {
            this.swarmCount -= deaths;
            const worldTree = this.systems.WORLD_TREE;
            // Thần Thụ càng mạnh, thời gian tái tạo càng ngắn
            const reviveTime = Math.max(8, 45 - (worldTree.tier * 100 + worldTree.level) * 0.3);
            // Tên Sự Kiện Hồi Sinh đúng lore theo vùng đang chiến đấu (GDD mục 3.4)
            const event = getResurrectionEventForRegion(this.currentRegion);
            for (let i = 0; i < deaths; i++) {
                resurrection.addDeadUnit({ baseReviveTime: reviveTime, level: 0, reviveGrowth: 0 }, event);
            }
        }

        this.lastDungeonResult = { stageIndex, win: false, deaths };
        return this.lastDungeonResult;
    }

    // --- Save / Load (BigInt-safe, IndexedDB) ---
    // Cả save() và load() đều bất đồng bộ vì IndexedDB là API Promise-based
    // (không chặn main thread như localStorage cũ, quan trọng vì save() được
    // gọi định kỳ mỗi 15s trong lúc game vẫn đang render 3D).
    async save() {
        this.lastTimestamp = Date.now();
        const payload = {
            resources: mapBigIntToStr(this.resources),
            systems: Object.fromEntries(Object.entries(this.systems).map(([k, v]) => [k, {
                level: v.level,
                tier: v.tier,
                baseStat: v.baseStat.toString()
            }])),
            swarmCount: this.swarmCount,
            highestCleared: this.highestCleared,
            currentRegion: this.currentRegion,
            lastTimestamp: this.lastTimestamp,
            materials: mapBigIntToStr(this.materials),
            rebirthCount: this.rebirthCount,
            unlockedAchievements: this.unlockedAchievements,
            arena: {
                tickets: this.arena.tickets,
                lastTicketTimestamp: this.arena.lastTicketTimestamp,
                winStreak: this.arena.winStreak
                // history không lưu: chỉ là log hiển thị phiên hiện tại, không cần bền vững
            },
            unlockedSkins: this.unlockedSkins,
            selectedSkin: this.selectedSkin,
            claimedBattlePassTiers: this.claimedBattlePassTiers
        };
        return dbSet(SAVE_KEY, payload);
    }

    // Trả về số giây đã trôi qua kể từ lần lưu trước (offline), hoặc null nếu chưa từng lưu
    async load() {
        // Di trú 1 lần: nếu người chơi có save cũ trong localStorage (bản trước
        // khi đổi sang IndexedDB), chuyển sang đây trước khi đọc, để không mất
        // tiến trình game.
        await migrateFromLocalStorage(SAVE_KEY);

        const data = await dbGet(SAVE_KEY);
        if (!data) return null;

        try {
            this.resources = mapStrToBigInt(data.resources);
            for (const key of Object.keys(this.systems)) {
                if (data.systems && data.systems[key]) {
                    this.systems[key].level = data.systems[key].level;
                    this.systems[key].tier = data.systems[key].tier;
                    this.systems[key].baseStat = BigInt(data.systems[key].baseStat);
                }
            }
            this.swarmCount = data.swarmCount || 1;
            this.highestCleared = data.highestCleared || 0;
            if (data.currentRegion && this.isRegionUnlocked(data.currentRegion)) {
                this.currentRegion = data.currentRegion;
            }
            // Trường thêm sau (materials/rebirth/achievements): dùng || để tương thích
            // ngược với save cũ chưa có các trường này, không lỗi khi thiếu
            if (data.materials) this.materials = mapStrToBigInt(data.materials);
            this.rebirthCount = data.rebirthCount || 0;
            this.unlockedAchievements = data.unlockedAchievements || [];
            if (data.arena) {
                this.arena.tickets = typeof data.arena.tickets === 'number' ? data.arena.tickets : this.arena.tickets;
                this.arena.lastTicketTimestamp = data.arena.lastTicketTimestamp || Date.now();
                this.arena.winStreak = data.arena.winStreak || 0;
            }
            this.unlockedSkins = data.unlockedSkins || ['default'];
            this.selectedSkin = data.selectedSkin || 'default';
            this.claimedBattlePassTiers = data.claimedBattlePassTiers || [];
            const previousTimestamp = data.lastTimestamp || Date.now();
            const elapsedSeconds = (Date.now() - previousTimestamp) / 1000;
            this.lastTimestamp = Date.now();
            return elapsedSeconds;
        } catch (e) {
            console.warn('Load failed, save có thể hỏng:', e);
            return null;
        }
    }
}

function mapBigIntToStr(obj) {
    return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, v.toString()]));
}
function mapStrToBigInt(obj) {
    return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, BigInt(v)]));
}
