// Hệ 8 - Vật Liệu (GDD mục 2.2): chuỗi 7 tier quy đổi, mỗi lần quy đổi 1 đơn vị Vật
// Liệu ở Bậc n cần 1 lượng cố định của Bậc (n-1), tăng dần theo cấp số cộng (d=5)
// đúng tinh thần "Logic Cấp Số Cộng" xuyên suốt GDD mục 1. Đây là 1 nền kinh tế phụ,
// tách khỏi 4 tài nguyên cơ bản (wood/stone/core/crystal) trong state.js — GAME_SYSTEMS.MATERIAL
// (systems.js) vẫn giữ nguyên vai trò cũ (+affects.yield qua nâng cấp Bậc/Cấp thông thường);
// module này thêm phần "Vật Liệu" như 1 tài nguyên/kho riêng đúng như bảng GDD liệt kê.
export const MATERIAL_TIERS = [
    { id: 'phe_lieu', name: 'Phế Liệu Cơ Khí' },
    { id: 'linh_kien', name: 'Linh Kiện' },
    { id: 'loi_du_lieu', name: 'Lõi Dữ Liệu' },
    { id: 'tinh_huyet', name: 'Tinh Huyết Huyết Tộc' },
    { id: 'tinh_thach_linh_hon', name: 'Tinh Thạch Linh Hồn' },
    { id: 'manh_vo_quy_tac', name: 'Mảnh Vỡ Quy Tắc' },
    { id: 'vat_chat_tinh_khong', name: 'Vật Chất Tinh Không' }
];

const BASE_CONVERT_COST = 10; // Bậc 0->1 cần 10 đơn vị Bậc dưới
const CONVERT_COST_STEP = 5;  // d=5: mỗi Bậc kế tiếp cần thêm 5 đơn vị

// Chi phí (số lượng Vật Liệu Bậc `fromTier`) để quy đổi ra 1 đơn vị Bậc `fromTier + 1`
export function getConvertCost(fromTier) {
    return BigInt(BASE_CONVERT_COST + fromTier * CONVERT_COST_STEP);
}

// Tạo kho Vật Liệu ban đầu: mỗi Bậc là 1 số lượng BigInt riêng, bắt đầu từ 0 (trừ
// Bậc 0 - Phế Liệu, khai thác thụ động cùng nhịp treo máy như tài nguyên cơ bản)
export function createMaterialInventory() {
    const inv = {};
    for (const tier of MATERIAL_TIERS) inv[tier.id] = 0n;
    return inv;
}

// Bậc Vật Liệu cao nhất hiện đang sở hữu ít nhất 1 đơn vị (dùng hiển thị UI)
export function getHighestOwnedTier(inventory) {
    let highest = 0;
    for (let i = MATERIAL_TIERS.length - 1; i >= 0; i--) {
        if (inventory[MATERIAL_TIERS[i].id] > 0n) { highest = i; break; }
    }
    return highest;
}
