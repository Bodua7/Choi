// Chuyển Sinh (Rebirth): vòng lặp endgame cho người chơi solo, xử lý gap "chưa có nội
// dung cuối game xuyên nhiều vòng" đã ghi nhận trước đó. Mở khóa từ Bậc Phó Bản 25 trở
// đi (đúng lúc Phân Thân đạt Đa Hệ Cộng Hưởng — mốc truyện cao nhất hiện có trong story.js).
// Reset: swarmCount về 1, resources về 0, 12 Hệ Thống Cốt Lõi + Vật Liệu về 0 (baseStat/tier/level).
// Giữ lại vĩnh viễn: rebirthCount, achievements đã mở, highestCleared (Bản Đồ/Cốt truyện không lùi lại).
export const REBIRTH_UNLOCK_STAGE = 25;
export const REBIRTH_BONUS_BP_PER_RUN = 15000n; // +15% sản lượng & sát thương vĩnh viễn/lần, cộng dồn

export function canRebirth(highestCleared) {
    return highestCleared >= REBIRTH_UNLOCK_STAGE;
}

// Hệ số nhân vĩnh viễn tích lũy qua các lần Chuyển Sinh, dạng basis points cộng thêm
// (dùng chung công thức basis-point với GameState.getMultiplierBP)
export function getRebirthBonusBP(rebirthCount) {
    return BigInt(rebirthCount) * REBIRTH_BONUS_BP_PER_RUN;
}
