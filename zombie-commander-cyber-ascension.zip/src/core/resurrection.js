export class ResurrectionManager {
    constructor() {
        this.pendingQueue = [];
    }

    // Chuyển đơn vị tử trận sang trạng thái "Chờ Tái Tạo Data". `event` là 1 trong
    // RESURRECTION_EVENTS (resurrectionEvents.js) — xác định tên/lore sự kiện hồi sinh
    // đang xử lý đơn vị này, tùy vùng Bản Đồ nơi tử trận (GDD mục 3.4).
    addDeadUnit(unit, event = null) {
        const reviveTime = unit.baseReviveTime + (unit.level * unit.reviveGrowth);
        this.pendingQueue.push({
            unitData: unit,
            event,
            respawnTimestamp: Date.now() + (reviveTime * 1000)
        });
    }

    // Tự động hồi phục khi hết thời gian mà không xóa / gán mới object liên tục
    processQueue(onRespawnCallback) {
        const now = Date.now();
        this.pendingQueue = this.pendingQueue.filter(item => {
            if (now >= item.respawnTimestamp) {
                onRespawnCallback(item.unitData);
                return false; // Loại khỏi hàng chờ
            }
            return true;
        });
    }
}
