// GDD Shop mục "monetization mock": Triệu Hồi (Gacha) + Vé Mùa (Battle Pass) — cả
// hai đều là MOCK, quy đổi bằng tài nguyên sẵn có trong game (Tinh Thạch / tiến
// trình Phó Bản), KHÔNG kết nối cổng thanh toán thật nào. Mục đích: minh họa vòng
// lặp thiết kế, không phải sản phẩm thương mại.
import { SKINS } from './skin.js';
import { MATERIAL_TIERS } from './materials.js';

export const GACHA_COST_CRYSTAL = 5n;

// Trọng số phần thưởng: đa số ra tài nguyên nhỏ, hiếm khi ra Skin mới
const GACHA_POOL = [
    { type: 'core', amount: 30n, weight: 35 },
    { type: 'crystal', amount: 2n, weight: 20 },
    { type: 'material', tier: 1, amount: 5n, weight: 25 }, // linh_kien
    { type: 'skin', weight: 20 }
];

function weightedPick(pool) {
    const total = pool.reduce((s, p) => s + p.weight, 0);
    let roll = Math.random() * total;
    for (const p of pool) {
        if (roll < p.weight) return p;
        roll -= p.weight;
    }
    return pool[pool.length - 1];
}

// state: GameState — trừ Tinh Thạch, trả kết quả roll (đã tự áp dụng phần thưởng
// vào state, caller chỉ cần gọi callbacks.onStateChanged() sau đó)
export function rollGacha(state) {
    if (state.resources.crystal < GACHA_COST_CRYSTAL) return null;
    state.resources.crystal -= GACHA_COST_CRYSTAL;

    const picked = weightedPick(GACHA_POOL);
    if (picked.type === 'skin') {
        const locked = SKINS.filter(s => !state.unlockedSkins.includes(s.id));
        if (locked.length === 0) {
            // Đã mở hết Skin -> quy đổi bù bằng Lõi để không "trắng tay"
            state.resources.core += 50n;
            return { type: 'core', amount: 50n, note: 'Đã sở hữu hết Skin, quy đổi bù' };
        }
        const skin = locked[Math.floor(Math.random() * locked.length)];
        state.unlockedSkins.push(skin.id);
        return { type: 'skin', skin };
    }
    if (picked.type === 'material') {
        const tierId = MATERIAL_TIERS[picked.tier].id;
        state.materials[tierId] += picked.amount;
        return { type: 'material', name: MATERIAL_TIERS[picked.tier].name, amount: picked.amount };
    }
    state.resources[picked.type] += picked.amount;
    return { type: picked.type, amount: picked.amount };
}

// --- Vé Mùa (Battle Pass) mock: mốc thưởng theo Bậc Phó Bản đã vượt (highestCleared),
// chỉ có track Miễn Phí — không có track trả phí thật nào được cài đặt.
export const BATTLE_PASS_TIERS = [
    { stage: 2, rewardCore: 20n, rewardCrystal: 0n },
    { stage: 5, rewardCore: 40n, rewardCrystal: 1n },
    { stage: 10, rewardCore: 80n, rewardCrystal: 2n },
    { stage: 15, rewardCore: 150n, rewardCrystal: 3n },
    { stage: 20, rewardCore: 250n, rewardCrystal: 5n },
    { stage: 25, rewardCore: 500n, rewardCrystal: 10n }
];

export function getClaimableBattlePassTiers(state) {
    return BATTLE_PASS_TIERS
        .map((tier, index) => ({ ...tier, index }))
        .filter(tier => state.highestCleared >= tier.stage && !state.claimedBattlePassTiers.includes(tier.index));
}

export function claimBattlePassTier(state, index) {
    const tier = BATTLE_PASS_TIERS[index];
    if (!tier) return false;
    if (state.highestCleared < tier.stage) return false;
    if (state.claimedBattlePassTiers.includes(index)) return false;
    state.resources.core += tier.rewardCore;
    state.resources.crystal += tier.rewardCrystal;
    state.claimedBattlePassTiers.push(index);
    return true;
}
