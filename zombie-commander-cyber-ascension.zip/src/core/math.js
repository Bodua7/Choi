// Dynamic BigInt & Linear Progression Math Engine
export class ProgressionEngine {
    // Tính chỉ số tại cấp n: S_n = S_0 + n * d
    static calculateStat(base, level, growth) {
        return BigInt(base) + BigInt(level) * BigInt(growth);
    }

    // Tính chi phí nâng cấp từ n lên n+1: C_n = C_0 + n * d_cost
    static calculateUpgradeCost(baseCost, level, costGrowth) {
        return BigInt(baseCost) + BigInt(level) * BigInt(costGrowth);
    }

    // Đột phá phẩm chất (+100 -> reset level về 0, tăng base): S_0^(T+1) = S_0^(T) + Delta_Tier
    static performBreakthrough(entity) {
        if (entity.level >= 100) {
            entity.tier += 1;
            entity.level = 0;
            entity.baseStat = BigInt(entity.baseStat) + BigInt(entity.tierDelta);
            return true;
        }
        return false;
    }

    // Thuật toán 1 tỷ vòng lặp O(1) tính tài nguyên Treo Máy theo tổng Cấp Số Cộng
    // Formula: Total = Time * [S_0 + ((Time - 1) * d) / 2]
    static calculateIdleYield(baseYieldPerSec, yieldGrowthPerSec, timeInSeconds) {
        const T = BigInt(Math.floor(timeInSeconds));
        if (T <= 0n) return 0n;
        
        const S0 = BigInt(baseYieldPerSec);
        const d = BigInt(yieldGrowthPerSec);
        
        // Tổng Sn = T * S0 + (T * (T - 1) / 2) * d
        const baseSum = T * S0;
        const growthSum = (T * (T - 1n) / 2n) * d;
        
        return baseSum + growthSum;
    }
}
