// Đấu Trường (Arena) — PvP BẤT ĐỒNG BỘ THẬT: đối thủ là snapshot chiến lực (combat_power)
// mà người chơi khác đã tự nộp lên Bảng Xếp Hạng (net/leaderboard.js), tìm qua
// net/arenaPvp.js (fetchArenaOpponents — chạy ở panels.js vì cần network, class này giữ
// nguyên đồng bộ). generateOpponent() dưới đây giờ CHỈ còn là dự phòng khi chưa có
// người chơi thật nào gần chiến lực (ví dụ leaderboard rỗng) — không còn là hành vi
// mặc định như trước.
export const TICKET_MAX = 5;
const TICKET_REGEN_MS = 20 * 60 * 1000; // 1 vé / 20 phút

const OPPONENT_NAME_POOL = [
    'Chỉ Huy Ma Phổ', 'Lữ Đoàn Server 12', 'Tộc Trưởng Huyết Nguyệt', 'Đội Trưởng Tử Linh',
    'Chiến Binh Tinh Không', 'Bầy Zombie Nổi Loạn', 'Sát Thủ Đơn Độc', 'Liên Minh Đông Khu'
];

export class ArenaState {
    constructor() {
        this.tickets = TICKET_MAX;
        this.lastTicketTimestamp = Date.now();
        this.winStreak = 0;
        this.history = []; // { opponentName, opponentAtk, playerAtk, win, timestamp }, giữ tối đa 10
    }

    // Hoàn vé theo thời gian trôi qua (gọi mỗi tick, giống applyElapsedSeconds của resource)
    regenTickets(now = Date.now()) {
        if (this.tickets >= TICKET_MAX) { this.lastTicketTimestamp = now; return; }
        const elapsed = now - this.lastTicketTimestamp;
        const gained = Math.floor(elapsed / TICKET_REGEN_MS);
        if (gained > 0) {
            this.tickets = Math.min(TICKET_MAX, this.tickets + gained);
            this.lastTicketTimestamp += gained * TICKET_REGEN_MS;
        }
    }

    msUntilNextTicket() {
        if (this.tickets >= TICKET_MAX) return 0;
        return TICKET_REGEN_MS - (Date.now() - this.lastTicketTimestamp);
    }

    // Dự phòng: sinh 1 đối thủ mô phỏng quanh chiến lực người chơi (biên độ 0.7x-1.4x) —
    // chỉ dùng khi fetchArenaOpponents() không tìm được người chơi thật nào (chưa cấu
    // hình Supabase, mất mạng, hoặc leaderboard chưa có ai gần chiến lực).
    generateOpponent(playerAtk) {
        const factor = 0.7 + Math.random() * 0.7;
        const opponentAtk = BigInt(Math.floor(Number(playerAtk) * factor)) || 1n;
        const name = OPPONENT_NAME_POOL[Math.floor(Math.random() * OPPONENT_NAME_POOL.length)];
        return { name, atk: opponentAtk };
    }

    canFight() {
        return this.tickets > 0;
    }

    // Tiêu 1 vé + phân giải kết quả với 1 đối thủ ĐÃ CÓ SẴN (opponent = {name, atk[, id]},
    // lấy từ fetchArenaOpponents() thật hoặc generateOpponent() dự phòng). Tách khỏi việc
    // tìm đối thủ (cần network — xử lý ở panels.js) để class này giữ nguyên đồng bộ.
    resolveFight(playerAtk, opponent) {
        if (!this.canFight()) return null;
        this.tickets -= 1;
        const win = playerAtk >= opponent.atk;
        this.winStreak = win ? this.winStreak + 1 : 0;
        // Thưởng tăng theo chuỗi thắng, nhưng luôn có tối thiểu để không "trắng tay"
        const streakBonus = Math.min(this.winStreak, 10);
        const rewardCore = win ? BigInt(10 + streakBonus * 4) : BigInt(2);
        const rewardCrystal = win ? BigInt(1 + Math.floor(streakBonus / 3)) : 0n;

        const entry = { opponentName: opponent.name, opponentAtk: opponent.atk, playerAtk, win, timestamp: Date.now() };
        this.history.unshift(entry);
        if (this.history.length > 10) this.history.length = 10;

        return { win, opponent, rewardCore, rewardCrystal };
    }
}
