// 12 Hệ Thống Cốt Lõi (GDD mục 2.2). Mỗi hệ có:
//  - base/growth/tierDelta: dùng cho ProgressionEngine (cấp số cộng, +100 đột phá)
//  - affects: các hiệu ứng thực sự mà hệ thống này cộng dồn vào gameplay, tính theo
//    "basis points" (100000 = +100%) trên mỗi điểm sức mạnh (power = tier*100 + level).
//    Đây là phần khớp hệ thống với công thức trong tài liệu thiết kế vào lối chơi thật,
//    thay vì chỉ là các con số hiển thị không có tác dụng.
export const GAME_SYSTEMS = {
    EQUIPMENT:  { id: 1,  name: "Trang Bị",              base: 100,  growth: 15,  tierDelta: 2000,
                  affects: {} }, // dùng trực tiếp làm sát thương/đơn vị trong getTotalAttack()
    SKILL:      { id: 2,  name: "Kỹ Năng",                base: 50,   growth: 5,   tierDelta: 1000,
                  affects: { yield: 80 } }, // Thuật Toán Phân Giải Mã Độc: +sản lượng tài nguyên
    TALENT:     { id: 3,  name: "Thần Thông",             base: 200,  growth: 30,  tierDelta: 5000,
                  affects: { atk: 60 } }, // buff diện rộng: +sát thương tổng
    CHARACTER:  { id: 4,  name: "Phương Hằng",            base: 500,  growth: 50,  tierDelta: 10000,
                  affects: { yield: 40, atk: 40 } }, // thăng cấp thân phận: buff toàn diện
    ALLY:       { id: 5,  name: "Đồng Minh",              base: 80,   growth: 10,  tierDelta: 1500,
                  affects: { yield: 100 } }, // Mạc Gia Vỹ (kinh tế) & cộng sự: +sản lượng
    FORGE:      { id: 6,  name: "Rèn Đúc",                base: 10,   growth: 2,   tierDelta: 200,
                  affects: { yield: 120 } }, // tốc độ rèn nhanh hơn -> quy đổi ra sản lượng Lõi/Tinh Thạch
    WORLD_TREE: { id: 7,  name: "Thần Thụ An Tề Sa",       base: 1000, growth: 100, tierDelta: 25000,
                  affects: { survival: 90 } }, // +HP/Giáp toàn Phân Thân -> giảm tổn thất khi thua Phó Bản
    MATERIAL:   { id: 8,  name: "Vật Liệu",               base: 1,    growth: 1,   tierDelta: 50,
                  affects: { yield: 150 } }, // hiệu suất quy đổi vật liệu cấp số cộng -> +sản lượng
    SHELTER:    { id: 9,  name: "Hầm Trú Ẩn / Bán Giới",   base: 300,  growth: 40,  tierDelta: 8000,
                  affects: { capacity: 6 } }, // +sức chứa Phân Thân tối đa
    FORMATION:  { id: 10, name: "Pháp Trận",               base: 150,  growth: 20,  tierDelta: 3000,
                  affects: { atk: 70 } }, // ma pháp/giây diện rộng -> +sát thương tổng
    PILL:       { id: 11, name: "Đan Dược",                base: 25,   growth: 5,   tierDelta: 500,
                  affects: { survival: 60, recruitDiscount: 50 } }, // hồi phục + giảm chi phí chiêu mộ
    TECH_TREE:  { id: 12, name: "Cây Công Nghệ",           base: 5,    growth: 1,   tierDelta: 100,
                  affects: {} } // dùng trực tiếp làm sản lượng cơ sở/giây trong getYieldPerSec()
};
