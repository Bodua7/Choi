// --- IndexedDB wrapper (thay localStorage cho toàn bộ dữ liệu bền của game) ---
// Lý do đổi: localStorage đồng bộ (chặn main thread), giới hạn ~5MB, và không
// đáng tin cậy trong 1 số trình duyệt mobile khi hạn mức bộ nhớ thấp (dễ bị xóa
// âm thầm). IndexedDB bất đồng bộ, hạn mức lớn hơn nhiều, và là chuẩn khuyến nghị
// cho PWA offline-first. API ở đây gói lại thành get/set/remove dạng Promise đơn
// giản, dùng chung 1 object store key-value để phần còn lại của game không cần
// biết chi tiết IndexedDB.

const DB_NAME = 'zombie-stickman-db';
const DB_VERSION = 1;
const STORE_NAME = 'kv';

let dbPromise = null;

function openDatabase() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
        if (!('indexedDB' in window)) {
            reject(new Error('IndexedDB không khả dụng trên trình duyệt này'));
            return;
        }
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
            const db = req.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME);
            }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
    return dbPromise;
}

export async function dbGet(key) {
    try {
        const db = await openDatabase();
        return await new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const req = tx.objectStore(STORE_NAME).get(key);
            req.onsuccess = () => resolve(req.result === undefined ? null : req.result);
            req.onerror = () => reject(req.error);
        });
    } catch (e) {
        console.warn('dbGet lỗi, coi như không có dữ liệu:', e);
        return null;
    }
}

export async function dbSet(key, value) {
    try {
        const db = await openDatabase();
        await new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            tx.objectStore(STORE_NAME).put(value, key);
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
        });
        return true;
    } catch (e) {
        console.warn('dbSet lỗi, dữ liệu không được lưu:', e);
        return false;
    }
}

export async function dbRemove(key) {
    try {
        const db = await openDatabase();
        await new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            tx.objectStore(STORE_NAME).delete(key);
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
        });
        return true;
    } catch (e) {
        console.warn('dbRemove lỗi:', e);
        return false;
    }
}

// Di trú 1 lần: nếu còn save cũ trong localStorage (từ bản trước khi đổi sang
// IndexedDB) và IndexedDB chưa có key này, copy sang rồi xóa bản localStorage.
// An toàn khi gọi nhiều lần (chỉ chạy thật sự 1 lần đầu tiên).
export async function migrateFromLocalStorage(key) {
    let legacyRaw = null;
    try {
        legacyRaw = localStorage.getItem(key);
    } catch (e) {
        return; // không truy cập được localStorage (chế độ riêng tư nghiêm ngặt...), bỏ qua
    }
    if (legacyRaw === null) return;

    const existing = await dbGet(key);
    if (existing === null) {
        try {
            const parsed = JSON.parse(legacyRaw);
            await dbSet(key, parsed);
            console.info(`Đã di trú dữ liệu "${key}" từ localStorage sang IndexedDB.`);
        } catch (e) {
            console.warn('Di trú dữ liệu cũ thất bại, bỏ qua:', e);
            return;
        }
    }
    try {
        localStorage.removeItem(key);
    } catch (e) {
        // bỏ qua
    }
}
