// Credit cho asset bên thứ 3 dùng trong game (âm thanh, texture...).
// Data-driven: thêm 1 entry ở đây khi cần ghi công — UI (tab Cài Đặt > Credits)
// tự hiển thị, không cần sửa panels.js.
//
// Ghi rõ url gốc: đa số license "Royalty Free" yêu cầu ghi công dẫn về đúng
// profile/tác phẩm của tác giả, không chỉ ghi tên suông.
//
// (Đang trống — game là text/số liệu thuần, không dùng bất kỳ ảnh/model nào.)
export const ASSET_CREDITS = [];
