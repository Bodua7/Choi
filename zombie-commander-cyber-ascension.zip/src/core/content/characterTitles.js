// Hệ 4 - Nhân Vật (Phương Hằng): thăng cấp thân phận theo GDD mục 2.2. Khác các hệ
// khác (không có +100/Đột Phá lặp lại vô hạn) — chỉ có đúng 6 mốc cố định, mở khóa
// theo Bậc (tier) của CHARACTER trong GAME_SYSTEMS. Từ mốc 6 trở đi, mỗi Đột Phá vẫn
// cộng dồn sức mạnh (qua getMultiplierBP) nhưng giữ nguyên danh hiệu cao nhất.
export const CHARACTER_TITLES = [
    'Người Chơi',
    'Giới Chủ Server 8',
    'Quân Vương Huyết Tộc',
    'Đại Đạo Sư Tử Linh',
    'Bá Chủ Đại Thế Giới',
    'Chủ Nhân Quy Tắc'
];

export function getCharacterTitle(tier) {
    if (tier < CHARACTER_TITLES.length) return CHARACTER_TITLES[tier];
    return CHARACTER_TITLES[CHARACTER_TITLES.length - 1];
}
