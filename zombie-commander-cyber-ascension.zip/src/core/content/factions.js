// Danh sách Chủng Tộc & Thế Lực (GDD mục 3.2). Dùng cho hiển thị lore ở tab Bản Đồ
// và để tô màu neon trong bảng trạng thái Bầy Zombie theo phe (mục 4.1).
export const STANCE = {
    ALLY: 'ally',       // đồng minh — hỗ trợ người chơi
    RIVAL: 'rival',     // đối địch trong khu vực — làm Boss khó hơn
    VILLAIN: 'villain', // phản diện cốt truyện chính
    NEUTRAL: 'neutral'
};

export const FACTIONS = {
    DONG_KHU: { id: 'DONG_KHU', name: 'Liên Bang Đông Khu', stance: STANCE.ALLY, color: '#00ffcc',
        description: 'Phe đồng minh chính của người chơi tại Server 8.' },
    MA_PHO: { id: 'MA_PHO', name: 'Tập Đoàn Ma Phổ', stance: STANCE.VILLAIN, color: '#555555',
        description: 'Trùm phản diện giai đoạn đầu, kiểm soát Server 8 trước khi sụp đổ.' },
    HUYET_TOC: { id: 'HUYET_TOC', name: 'Huyết Tộc (Vampire)', stance: STANCE.RIVAL, color: '#ff0055',
        description: 'Chủng tộc Huyết Tộc thống trị vùng lãnh địa thứ hai.' },
    TU_LINH: { id: 'TU_LINH', name: 'Tử Linh (Necromancer)', stance: STANCE.RIVAL, color: '#7b2ff7',
        description: 'Pháp sư Tử Linh điều khiển quân đoàn Undead.' },
    THANH_DIEN: { id: 'THANH_DIEN', name: 'Thánh Điện (Holy Church)', stance: STANCE.ALLY, color: '#fff2cc',
        description: 'Giáo Hội Thánh Điện — đồng minh chống lại Tử Linh và Thâm Uyên.' },
    THAM_UYEN: { id: 'THAM_UYEN', name: 'Thâm Uyên (Abyss)', stance: STANCE.VILLAIN, color: '#3a0033',
        description: 'Thế lực hắc ám cổ xưa, nguồn gốc của Ma Trận Ô Nhiễm Thâm Uyên.' },
    LINH_TOC: { id: 'LINH_TOC', name: 'Linh Tộc (Elves)', stance: STANCE.ALLY, color: '#66ff99',
        description: 'Chủng tộc canh giữ Thần Thụ An Tề Sa.' },
    TAY_KHU: { id: 'TAY_KHU', name: 'Liên Bang Tây Khu', stance: STANCE.RIVAL, color: '#ff6600',
        description: 'Phe đối địch tranh giành tài nguyên quanh khu vực Thần Thụ.' },
    TRUNG_TOC: { id: 'TRUNG_TOC', name: 'Trùng Tộc (Zerg)', stance: STANCE.NEUTRAL, color: '#d4af37',
        description: 'Bầy Bọ Cơ Khí xâm nhập và phân hủy quái vật khổng lồ từ bên trong.' },
    TINH_KHONG_DI_TOC: { id: 'TINH_KHONG_DI_TOC', name: 'Tinh Không Dị Tộc', stance: STANCE.VILLAIN, color: '#00aaff',
        description: 'Dị tộc từ ngoài quy tắc không gian, xuất hiện ở giai đoạn cuối.' },
    TA_THAN: { id: 'TA_THAN', name: 'Tà Thần Cổ Đại', stance: STANCE.VILLAIN, color: '#8b0000',
        description: 'Thế lực phản diện tối thượng của toàn bộ cốt truyện.' }
};
