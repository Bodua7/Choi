// Tên gọi cụ thể cho từng Bậc (tier) của 12 Hệ Thống Cốt Lõi, lấy trực tiếp từ nội
// dung liệt kê trong GDD mục 2.2. Trước đây mỗi hệ chỉ hiển thị "Bậc N" chung chung
// trong panels.js; file này gắn tên thật + mô tả ngắn cho từng Bậc đã biết. Các Bậc
// vượt quá danh sách (đột phá nhiều lần) tự động rơi về "Bậc N (Vượt Giới Hạn Tri Thức)"
// — game không lỗi/crash, chỉ là chưa có lore đặt tên xa hơn Chương 3922.

export const SYSTEM_TIER_NAMES = {
    EQUIPMENT: [
        'Súng Gatling',
        'Pháo Rocket',
        'Pháp Trượng Tử Linh',
        'Thánh Khí Huyết Tộc',
        'Vũ Khí Phù Văn',
        'Vũ Khí Quy Tắc Tinh Không'
    ],
    SKILL: [
        'Zombie Phân Thân',
        'Thuật Toán Phân Giải Mã Độc',
        'Ma Pháp Huyết Tộc',
        'Triệu Hồi Undead',
        'Thánh Ánh Khiên',
        'Ô Nhiễm Thâm Uyên'
    ],
    TALENT: [
        'Quy Tắc Lĩnh Vực',
        'Thao Túng Linh Hồn',
        'Huyết Tộc Chân Thần Thể',
        'Vạn Vật Phân Giải',
        'Tinh Không Áp Chế'
    ],
    FORGE: [
        'Lò Rèn Cơ Khí',
        'Tế Đàn Huyết Tộc',
        'Xưởng Chế Tạo Tử Linh',
        'Trạm Hợp Thành Quy Tắc'
    ],
    WORLD_TREE: [
        'Mầm An Tề Sa',
        'Rễ An Tề Sa Bén Sâu',
        'Tán Lá An Tề Sa Che Phủ Bán Giới',
        'An Tề Sa Giác Ngộ'
    ],
    FORMATION: [
        'Thần Thánh Thanh Tẩy Trận',
        'Vạn Hồn Triệu Hồi Trận',
        'Tụ Linh Trận',
        'Ma Trận Ô Nhiễm Thâm Uyên',
        'Quy Tắc Phong Ấn Trận'
    ],
    PILL: [
        'Huyết Long Đan',
        'Trí Huệ Tinh Luyện Đan',
        'Cốt Tủy Phân Giải Đan',
        'Quy Tắc Tinh Thần Đan'
    ],
    TECH_TREE: [
        'Nhánh Cơ Khí Tự Động Hóa',
        'Dây Chuyền Sản Xuất Zombie',
        'Thuật Toán Mã Độc Diệt Virus',
        'Mạng Lưới Swarm Bọ Cơ Khí'
    ],
    SHELTER: [
        'Căn Cứ Nhà Tù',
        'Pháo Đài Thép',
        'Trạm Không Gian Bán Giới',
        'Đa Vũ Trụ Lãnh Địa'
    ]
    // CHARACTER dùng characterTitles.js riêng (thân phận gắn liền cốt truyện, không
    // lặp lại mỗi lần đột phá — xem getCharacterTitle()). ALLY dùng allies.js riêng
    // (8 Đồng Minh có tên/vai trò cố định, không phải chuỗi Bậc như các hệ khác).
};

// Trả về tên hiển thị cho 1 Bậc cụ thể của 1 hệ thống. index Bậc bắt đầu từ 0.
export function getTierName(systemKey, tier) {
    const names = SYSTEM_TIER_NAMES[systemKey];
    if (!names) return null; // hệ không dùng chuỗi tên Bậc (CHARACTER/ALLY) -> panels tự xử lý riêng
    if (tier < names.length) return names[tier];
    return `${names[names.length - 1]} (Vượt Giới Hạn Tri Thức, Bậc ${tier + 1})`;
}
