// GDD mục 3.4: "Bảo lưu Toàn bộ Sự kiện Hồi Sinh" — 3 sự kiện cụ thể trong cốt truyện,
// trước đây ResurrectionManager chỉ có 1 hàng chờ chung chung không phân biệt tên. File
// này chọn đúng tên sự kiện theo vùng Bản Đồ (region) nơi Phân Thân tử trận, để hiển thị
// đúng lore thay vì chỉ nói "Chờ Tái Tạo Data".
export const RESURRECTION_EVENTS = {
    ZOMBIE_GATE: { id: 'ZOMBIE_GATE', name: 'Cổng Tái Tạo Zombie', desc: 'Cổng dữ liệu gốc của Bầy Phân Thân — mặc định ở Server 8 và các vùng chưa có nghi thức riêng.' },
    VAMPIRE_CYCLE: { id: 'VAMPIRE_CYCLE', name: 'Chu Kỳ Tái Sinh Huyết Tộc', desc: 'Nghi thức tái sinh của Huyết Tộc, hoạt động tại Lãnh Địa Huyết Tộc & Tử Linh.' },
    NECRO_ALTAR: { id: 'NECRO_ALTAR', name: 'Tế Đàn Hồi Sinh Tử Linh', desc: 'Tế Đàn của Tử Linh, triệu hồi lại Phân Thân từ tro tàn ở vùng Đại Chiến Linh Tộc & Thần Thụ trở đi.' }
};

// Vùng nào dùng sự kiện hồi sinh nào (theo id vùng trong mapNodes.js)
const REGION_EVENT_MAP = {
    server8: RESURRECTION_EVENTS.ZOMBIE_GATE,
    vampire_necro: RESURRECTION_EVENTS.VAMPIRE_CYCLE,
    elf_worldtree: RESURRECTION_EVENTS.NECRO_ALTAR,
    zerg_void: RESURRECTION_EVENTS.NECRO_ALTAR
};

export function getResurrectionEventForRegion(regionId) {
    return REGION_EVENT_MAP[regionId] || RESURRECTION_EVENTS.ZOMBIE_GATE;
}
