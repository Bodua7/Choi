// Hệ 5 - Đồng Minh (GDD mục 2.2): 8 nhân vật cố định, mỗi người mở khóa khi hệ ALLY
// (GAME_SYSTEMS.ALLY) đạt đúng Bậc tương ứng (order = tier cần đạt). Sức mạnh cộng
// dồn thật vẫn tính chung qua GameState.getMultiplierBP('yield') như trước (ALLY.affects.yield),
// file này chỉ gắn danh tính + vai trò cho từng nấc mở khóa để không còn là 1 con số trừu tượng.
export const ALLIES = [
    { id: 'mac_gia_vy', order: 0, name: 'Mạc Gia Vỹ', role: 'Kinh tế', desc: 'Quản lý dòng tài nguyên của Bán Giới, tối ưu từng đơn vị Gỗ/Đá thu về.' },
    { id: 'tran_khoa', order: 1, name: 'Trần Khoa', role: 'Cơ khí', desc: 'Kỹ sư trưởng chế tạo Bầy Bọ Cơ Khí và nâng cấp dây chuyền Rèn Đúc.' },
    { id: 'lo_vu', order: 2, name: 'Lô Vũ', role: 'Tình báo', desc: 'Trinh sát các vùng chưa mở khóa, báo trước sức mạnh phe Đối Địch.' },
    { id: 'son_de', order: 3, name: 'Sơn Đế', role: 'Khảo cổ', desc: 'Khai quật di tích Trùng Tộc cổ đại, thu thập Lõi Năng Lượng Dữ Liệu.' },
    { id: 'vi_dat', order: 4, name: 'Vi Đặc', role: 'Thương nhân', desc: 'Mở thêm tỉ giá đổi tài nguyên có lợi hơn tại Shop.' },
    { id: 'boi_la_me', order: 5, name: 'Bối La Mễ', role: 'Huyết tộc', desc: 'Chân Thần Thể Huyết Tộc quy thuận, tăng sát thương toàn Bầy.' },
    { id: 'dich_khac', order: 6, name: 'Địch Khắc', role: 'Tử linh', desc: 'Pháp sư Tử Linh phản chiến, hỗ trợ Triệu Hồi Undead.' },
    { id: 'giao_su_phu_lam', order: 7, name: 'Giáo sư Phú Lâm', role: 'Ngoại giao', desc: 'Đàm phán với các Chủng Tộc, mở khóa quan hệ đồng minh mới ở Bản Đồ.' }
];

// Danh sách đã mở khóa theo Bậc hiện tại của hệ ALLY (tier = số lần Đột Phá đã đạt)
export function getUnlockedAllies(allyTier) {
    return ALLIES.filter(a => a.order <= allyTier);
}

export function getNextAlly(allyTier) {
    return ALLIES.find(a => a.order > allyTier) || null;
}
