// Cốt truyện Chương 1 - 3922 (GDD mục 3, sơ đồ 4 vùng): thay vì chỉ mô tả lore rời
// rạc, mỗi mốc dưới đây gắn trực tiếp vào 1 ngưỡng `highestCleared` (Bậc Phó Bản đã
// vượt) — đúng ngưỡng đó, GameState trả về đoạn truyện tương ứng để hiển thị làm
// phần thưởng tường thuật khi thắng Phó Bản (renderDungeonPanel).
// STORY_ARCS dùng chung unlockStage với MAP_REGIONS để 2 hệ thống luôn đồng bộ.
export const STORY_ARCS = [
    { id: 'server8', unlockStage: 0, chapterRange: [1, 400], title: 'Server 8: Zombie Tận Thế' },
    { id: 'vampire_necro', unlockStage: 5, chapterRange: [401, 1400], title: 'Lãnh Địa Huyết Tộc & Tử Linh' },
    { id: 'elf_worldtree', unlockStage: 12, chapterRange: [1401, 2600], title: 'Đại Chiến Linh Tộc & Thần Thụ' },
    { id: 'zerg_void', unlockStage: 22, chapterRange: [2601, 3922], title: 'Trùng Tộc & Tinh Không Quy Tắc' }
];

// Mốc truyện cụ thể (đủ dày để luôn có beat mới khi thắng vài Bậc liên tiếp ở early-game,
// thưa dần về sau — đúng nhịp treo máy: chương đầu đọc nhiều, chương sau lướt nhanh).
export const STORY_BEATS = [
    // --- Arc 1: Server 8: Zombie Tận Thế (Bậc 0-5) ---
    { stage: 0, chapter: 1, text: 'Tập Đoàn Ma Phổ phong tỏa Server 8. Zombie đầu tiên trỗi dậy — bạn chỉ huy Phân Thân đầu tiên của mình.' },
    { stage: 1, chapter: 12, text: 'Liên Bang Đông Khu liên lạc, đề nghị liên minh chống lại Ma Phổ.' },
    { stage: 2, chapter: 24, text: 'Sơn Đế phát hiện dấu vết lạ khắc dưới nền móng Server 8, nhưng chưa ai tin lời cảnh báo của lão khảo cổ.' },
    { stage: 3, chapter: 34, text: 'Phân Thân đầu tiên tiến hóa thành Licker — tốc độ trinh sát vượt trội.' },
    { stage: 4, chapter: 58, text: 'Licker phát hiện phòng thí nghiệm bí mật của Ma Phổ dưới lòng đất.' },
    { stage: 5, chapter: 103, text: 'Cánh cổng dẫn vào Lãnh Địa Huyết Tộc mở ra. Đại Đạo Sư Tử Linh xuất hiện lần đầu.' },

    // --- Arc 2: Lãnh Địa Huyết Tộc & Tử Linh (Bậc 5-12) ---
    { stage: 6, chapter: 140, text: 'Huyết Tộc cử sứ giả đề nghị đình chiến — đổi lại, họ muốn quyền tiếp cận vùng khai thác Lõi Năng Lượng của Bầy.' },
    { stage: 7, chapter: 175, text: 'Đại Đạo Sư Tử Linh tiết lộ bí mật: Ma Phổ từng là đồng minh cũ của Huyết Tộc trước khi phản bội cả hai phe.' },
    { stage: 8, chapter: 210, text: 'Phân Thân tiến hóa thành Tyrant, đủ sức đỡ đòn cho toàn Bầy trong các trận lớn.' },
    { stage: 9, chapter: 245, text: 'Bối La Mễ, Chân Thần Thể của Huyết Tộc, âm thầm theo dõi Bầy suốt nhiều trận — hắn bắt đầu nghi ngờ lòng trung thành với chủ cũ.' },
    { stage: 10, chapter: 280, text: 'Địch Khắc phản chiến, mang theo bí thuật Triệu Hồi Undead của phe Tử Linh sang hàng ngũ Bầy.' },
    { stage: 11, chapter: 310, text: 'Lãnh Địa Huyết Tộc rung chuyển — một thế lực còn cổ xưa hơn cả Huyết Tộc và Tử Linh bắt đầu cựa mình dưới lòng đất: Thâm Uyên.' },
    { stage: 12, chapter: 340, text: 'Bước chân vào Đại Chiến Linh Tộc & Thần Thụ — Linh Tộc mời bạn đến canh giữ An Tề Sa.' },

    // --- Arc 3: Đại Chiến Linh Tộc & Thần Thụ (Bậc 12-22) ---
    { stage: 13, chapter: 390, text: 'Thần Thụ An Tề Sa cảm nhận được Bầy đang đến gần — những chiếc lá đầu tiên đổi màu tím thay vì xanh.' },
    { stage: 14, chapter: 430, text: 'Linh Tộc chia phe: một nhóm muốn liên minh với Bầy, nhóm còn lại cho rằng zombie là ô uế không thể dung thứ trong đất thánh.' },
    { stage: 15, chapter: 480, text: 'Fusion Tyrant thành hình, trang bị Súng Gatling và Pháo Rocket thu được từ Ma Phổ.' },
    { stage: 17, chapter: 560, text: 'Giáo sư Phú Lâm đứng ra làm trung gian, thuyết phục trưởng lão Linh Tộc mở cửa An Tề Sa cho Bầy đóng quân tạm thời.' },
    { stage: 19, chapter: 650, text: 'Trận đánh đầu tiên trong rừng Thần Thụ: Fusion Tyrant húc đổ 3 gốc cây cổ đại bị Ma Phổ cấy vũ khí sinh học vào bên trong.' },
    { stage: 22, chapter: 900, text: 'Trùng Tộc lộ diện — Bầy Bọ Cơ Khí bắt đầu khai quật di tích cổ đại quanh Tinh Không.' },

    // --- Arc 4: Trùng Tộc & Tinh Không Quy Tắc (Bậc 22-60) ---
    { stage: 23, chapter: 980, text: 'Sơn Đế xác nhận: các di tích Trùng Tộc khai quật được đều khắc cùng một loại ký tự — về sau trùng khớp với Mảnh Vỡ Quy Tắc.' },
    { stage: 24, chapter: 1050, text: 'Trùng Tộc cử Bầy Bọ Cơ Khí đầu tiên tấn công trực diện — Trần Khoa nhận ra công nghệ của chúng vượt xa mọi thứ Ma Phổ từng có.' },
    { stage: 25, chapter: 1200, text: 'Phân Thân đạt trạng thái Đa Hệ Cộng Hưởng: Huyết Tộc, Tử Linh, Thánh Điện, Thâm Uyên, Quy Tắc hòa làm một.' },
    { stage: 26, chapter: 1260, text: 'Vi Đặc mở tuyến buôn bán bí mật với Liên Bang Tây Khu — đổi Lõi Năng Lượng lấy tin tức nội bộ của Trùng Tộc.' },
    { stage: 27, chapter: 1330, text: 'Đông Khu cảnh báo: Liên Bang Tây Khu đang bí mật tích trữ vũ khí, có dấu hiệu chuẩn bị trở mặt.' },
    { stage: 28, chapter: 1450, text: 'Liên Bang Tây Khu trở mặt, liên thủ với Trùng Tộc để độc chiếm tài nguyên quanh Thần Thụ An Tề Sa.' },
    { stage: 29, chapter: 1520, text: 'Thánh Điện cử một đội trinh sát nhỏ đến An Tề Sa, chính thức xác nhận Ma Trận Ô Nhiễm Thâm Uyên đang lan rộng.' },
    { stage: 31, chapter: 1700, text: 'Thánh Điện phát hiện Ma Trận Ô Nhiễm Thâm Uyên đang rò rỉ ngược từ dưới nền móng An Tề Sa.' },
    { stage: 32, chapter: 1780, text: 'Lô Vũ báo về: Tây Khu và Trùng Tộc đã ký một hiệp ước ngầm, chia đôi tài nguyên quanh Thần Thụ nếu chiếm được An Tề Sa.' },
    { stage: 34, chapter: 1950, text: 'Linh Tộc mở nghi lễ cổ, mượn sức Thần Thụ để phong ấn tạm thời cửa ngõ Thâm Uyên — cái giá là một phần rễ cây hóa đá vĩnh viễn.' },
    { stage: 35, chapter: 2020, text: 'Cái giá của nghi lễ phong ấn khiến một nửa khu rừng An Tề Sa hóa đá vĩnh viễn — Linh Tộc chia rẽ sâu sắc hơn bao giờ hết.' },
    { stage: 37, chapter: 2200, text: 'Trùng Tộc đồng loạt trỗi dậy trên diện rộng — hóa ra Bầy Bọ Cơ Khí chỉ là tiền trạm cho một sinh thể mẹ đang ngủ dưới lòng Tinh Không.' },
    { stage: 38, chapter: 2280, text: 'Sinh thể mẹ của Trùng Tộc lộ diện lần đầu qua camera trinh sát của Lô Vũ — kích thước ước tính lớn hơn cả một thành phố.' },
    { stage: 40, chapter: 2450, text: 'Đại Chiến Linh Tộc & Thần Thụ khép lại: An Tề Sa được cứu, nhưng cánh cổng dẫn tới Tinh Không Quy Tắc bị Trùng Tộc phá vỡ trong lúc hỗn loạn.' },
    { stage: 41, chapter: 2520, text: 'Cánh cổng dẫn tới Tinh Không Quy Tắc, dù đã vỡ, vẫn rò rỉ thứ ánh sáng khiến mọi thiết bị đo lường của Trần Khoa mất tác dụng.' },
    { stage: 43, chapter: 2700, text: 'Bước chân đầu tiên vào Tinh Không — trọng lực, thời gian và cấp số cộng quen thuộc của Phân Thân bắt đầu vỡ vụn thành quy tắc lạ.' },
    { stage: 44, chapter: 2780, text: 'Trọng lực đảo chiều trong thoáng chốc — Phân Thân nhận ra thời gian ở Tinh Không không trôi cùng tốc độ với Server 8.' },
    { stage: 46, chapter: 2950, text: 'Tinh Không Dị Tộc lộ diện: chúng không xâm lược bằng vũ lực mà bằng cách viết lại quy tắc tồn tại của cả Server 8.' },
    { stage: 47, chapter: 3020, text: 'Tinh Không Dị Tộc gửi "thông điệp" đầu tiên: không phải lời nói, mà là một đoạn ký ức giả về một Server 8 chưa từng có Bầy Zombie.' },
    { stage: 49, chapter: 3150, text: 'Mảnh Vỡ Quy Tắc đầu tiên được thu thập — Phân Thân thoáng thấy một thực tại nơi Ma Phổ, Huyết Tộc, Tử Linh chưa từng tồn tại.' },
    { stage: 50, chapter: 3220, text: 'Giáo sư Phú Lâm cảnh báo: càng thu thập nhiều Mảnh Vỡ Quy Tắc, ranh giới giữa Phân Thân thật và thực tại giả càng mờ đi.' },
    { stage: 52, chapter: 3350, text: 'Tà Thần Cổ Đại thức giấc sau lớp phong ấn của Thánh Điện — mọi phe phái buộc phải đình chiến trong im lặng.' },
    { stage: 53, chapter: 3420, text: 'Mọi phe phái — kể cả Ma Phổ — cùng gửi tín hiệu đình chiến khẩn cấp lần đầu tiên kể từ ngày tận thế bắt đầu.' },
    { stage: 55, chapter: 3550, text: 'Liên minh cuối cùng thành hình: Đông Khu, Thánh Điện, Linh Tộc cùng Phân Thân hành quân về trung tâm Tinh Không Quy Tắc.' },
    { stage: 56, chapter: 3620, text: 'Bối La Mễ dẫn tàn quân Huyết Tộc trung thành cuối cùng gia nhập liên minh — lời thề trung thành với Bầy được tuyên bố công khai.' },
    { stage: 58, chapter: 3750, text: 'Vật Chất Tinh Không kết tinh quanh Phân Thân — cơ thể giờ không còn thuần zombie, cũng chưa hẳn là thứ gì con người từng đặt tên.' },
    { stage: 59, chapter: 3840, text: 'Toàn bộ Server 8 tạm ngừng chiến sự trong 1 giờ đồng hồ — mọi phe phái cùng dõi theo trận chiến cuối cùng qua camera vệ tinh còn sót lại.' },
    { stage: 60, chapter: 3922, text: 'Tà Thần Cổ Đại sụp đổ dưới sức nặng của toàn bộ Bầy đã hợp nhất. Server 8 im lặng lần đầu tiên kể từ ngày đầu tận thế — không phải vì bị bỏ hoang, mà vì cuối cùng đã an toàn.' }
];

export function getArcFor(highestCleared) {
    let current = STORY_ARCS[0];
    for (const arc of STORY_ARCS) {
        if (highestCleared >= arc.unlockStage) current = arc;
    }
    return current;
}

// Mốc truyện gần nhất đã đạt (dùng để hiển thị nhật ký/truyện tích lũy)
export function getLatestBeat(highestCleared) {
    let latest = null;
    for (const beat of STORY_BEATS) {
        if (highestCleared >= beat.stage) latest = beat;
    }
    return latest;
}

// Mốc truyện vừa đạt được NGAY tại bậc này (dùng để hiện toast lúc thắng Phó Bản) —
// trả về null nếu Bậc vừa vượt qua không trùng đúng 1 mốc truyện.
export function getBeatUnlockedAtStage(stage) {
    return STORY_BEATS.find(b => b.stage === stage) || null;
}
