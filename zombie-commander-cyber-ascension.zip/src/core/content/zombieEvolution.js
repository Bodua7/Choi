// Nhánh Tiến Hóa Zombie Phân Thân (GDD 3.1): Thường -> Licker -> Tyrant ->
// Fusion Tyrant -> Zombie Đa Hệ Cộng Hưởng. Mở khóa theo `highestCleared` (Bậc Phó
// Bản đã vượt qua — dùng chung ngưỡng với MAP_REGIONS.unlockStage để đồng bộ nhịp
// mở khóa nội dung). Mỗi bậc cộng thêm basis points thật vào atk/yield/survival
// (không chỉ là danh hiệu) qua GameState.getMultiplierBP('evolution').
export const ZOMBIE_EVOLUTION = [
    {
        id: 'THUONG',
        order: 0,
        unlockStage: 0,
        name: 'Zombie Thường',
        role: 'Chuyên chặt gỗ, đào đá, nhổ lông — lao động cơ bản của Bầy',
        colorHex: 0x66ff66,
        bonus: { yield: 0, atk: 0, survival: 0 } // mốc gốc, chưa cộng gì thêm
    },
    {
        id: 'LICKER',
        order: 1,
        unlockStage: 3,
        name: 'Licker',
        role: 'Trinh sát tốc độ cao, mở khóa lợi thế PvP/thám hiểm',
        colorHex: 0xff66cc,
        bonus: { yield: 3000, atk: 1000, survival: 0 } // +3% sản lượng, +1% sát thương
    },
    {
        id: 'TYRANT',
        order: 2,
        unlockStage: 8,
        name: 'Tyrant',
        role: 'Đỡ đòn, thu hút sát thương — Bầy sống sót Phó Bản tốt hơn hẳn',
        colorHex: 0xff3333,
        bonus: { yield: 3000, atk: 3000, survival: 8000 } // +8% sống sót là điểm nhấn của bậc này
    },
    {
        id: 'FUSION_TYRANT',
        order: 3,
        unlockStage: 15,
        name: 'Fusion Tyrant',
        role: 'Trang bị Súng Gatling / Pháo Rocket — hỏa lực áp đảo',
        colorHex: 0xffaa00,
        bonus: { yield: 4000, atk: 9000, survival: 10000 }
    },
    {
        id: 'DA_HE',
        order: 4,
        unlockStage: 25,
        name: 'Zombie Đa Hệ Cộng Hưởng',
        role: 'Cộng hưởng Huyết Tộc/Tử Linh/Thánh Điện/Thâm Uyên/Quy Tắc cùng lúc',
        colorHex: 0x00eeff,
        bonus: { yield: 8000, atk: 15000, survival: 12000 }
    }
];

// Bậc tiến hóa hiện tại theo highestCleared (Bậc cao nhất mà unlockStage <= highestCleared)
export function getEvolutionStageFor(highestCleared) {
    let current = ZOMBIE_EVOLUTION[0];
    for (const stage of ZOMBIE_EVOLUTION) {
        if (highestCleared >= stage.unlockStage) current = stage;
    }
    return current;
}

export function getNextEvolutionStage(highestCleared) {
    return ZOMBIE_EVOLUTION.find(s => s.unlockStage > highestCleared) || null;
}
