// Bản Đồ Thế Giới (GDD mục 3, sơ đồ 4 vùng chính theo mạch truyện).
// Mỗi vùng có 1 phe Đồng Minh (cộng buff thật, dùng chung cơ chế basis-point với
// GAME_SYSTEMS.affects) và 1 phe Đối Địch (làm Boss trong vùng khó hơn qua bossHpBP).
// unlockStage: mở khóa khi state.highestCleared (Phó Bản) đạt tới ngưỡng này.
import { FACTIONS } from './factions.js';

export const MAP_REGIONS = [
    {
        id: 'server8',
        order: 0,
        unlockStage: 0,
        name: 'Server 8: Zombie Tận Thế',
        description: 'Điểm khởi đầu — Tập Đoàn Ma Phổ kiểm soát Server 8, Đông Khu là đồng minh đầu tiên.',
        allyFaction: { ...FACTIONS.DONG_KHU, effect: { yield: 3000 } },   // +3% sản lượng
        rivalFaction: { ...FACTIONS.MA_PHO, bossHpBP: 100000 }            // baseline, không cộng thêm
    },
    {
        id: 'vampire_necro',
        order: 1,
        unlockStage: 5,
        name: 'Lãnh Địa Huyết Tộc & Tử Linh',
        description: 'Huyết Tộc và Tử Linh tranh giành lãnh địa; Thánh Điện hỗ trợ người chơi chống Undead.',
        allyFaction: { ...FACTIONS.THANH_DIEN, effect: { atk: 4000 } },   // +4% sát thương
        rivalFaction: { ...FACTIONS.TU_LINH, bossHpBP: 130000 }           // Boss +30% HP
    },
    {
        id: 'elf_worldtree',
        order: 2,
        unlockStage: 12,
        name: 'Đại Chiến Linh Tộc & Thần Thụ',
        description: 'Linh Tộc canh giữ Thần Thụ An Tề Sa; Liên Bang Tây Khu tranh giành tài nguyên khu vực.',
        allyFaction: { ...FACTIONS.LINH_TOC, effect: { survival: 5000 } }, // +5% sống sót
        rivalFaction: { ...FACTIONS.TAY_KHU, bossHpBP: 170000 }           // Boss +70% HP
    },
    {
        id: 'zerg_void',
        order: 3,
        unlockStage: 22,
        name: 'Trùng Tộc & Tinh Không Quy Tắc',
        description: 'Vùng cuối: Trùng Tộc trung lập khai quật di tích cổ, Tinh Không Dị Tộc và Tà Thần Cổ Đại là mối đe dọa tối thượng.',
        allyFaction: { ...FACTIONS.TRUNG_TOC, effect: { yield: 6000 } },   // +6% sản lượng
        rivalFaction: { ...FACTIONS.TINH_KHONG_DI_TOC, bossHpBP: 220000 } // Boss +120% HP
    }
];

export function getRegionById(id) {
    return MAP_REGIONS.find(r => r.id === id) || MAP_REGIONS[0];
}
