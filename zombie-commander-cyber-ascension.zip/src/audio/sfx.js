// Âm thanh tổng hợp (procedural) bằng Web Audio API — dự án chưa có (và người dùng
// chưa cung cấp) file nhạc/SFX thật nào trong public/, nên thay vì bỏ trống hoàn
// toàn, module này phát các tiếng "bíp" ngắn tổng hợp trực tiếp bằng oscillator,
// không cần tải file, không tốn dung lượng. Có thể thay bằng file .mp3/.ogg thật
// sau này nếu có asset — chỉ cần đổi cách gọi trong main.js.
let audioCtx = null;

function getCtx() {
    if (!audioCtx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        audioCtx = new AC();
    }
    if (audioCtx.state === 'suspended') audioCtx.resume();
    return audioCtx;
}

function beep({ freq = 440, duration = 0.08, type = 'sine', volume = 0.15, slideTo = null } = {}) {
    const ctx = getCtx();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, ctx.currentTime + duration);
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
}

export const SFX = {
    upgrade: () => beep({ freq: 520, duration: 0.09, type: 'square', slideTo: 780 }),
    recruit: () => beep({ freq: 300, duration: 0.06, type: 'triangle', slideTo: 420 }),
    dungeonWin: () => { beep({ freq: 660, duration: 0.12, type: 'sine', slideTo: 990 }); setTimeout(() => beep({ freq: 990, duration: 0.14, type: 'sine' }), 100); },
    dungeonLose: () => beep({ freq: 220, duration: 0.25, type: 'sawtooth', slideTo: 110, volume: 0.12 }),
    achievement: () => { beep({ freq: 523, duration: 0.1, type: 'sine' }); setTimeout(() => beep({ freq: 659, duration: 0.1, type: 'sine' }), 90); setTimeout(() => beep({ freq: 784, duration: 0.16, type: 'sine' }), 180); },
    arenaWin: () => beep({ freq: 440, duration: 0.1, type: 'square', slideTo: 660 }),
    arenaLose: () => beep({ freq: 260, duration: 0.15, type: 'sawtooth', slideTo: 160 })
};

export function playSfx(name, enabled) {
    if (!enabled) return;
    const fn = SFX[name];
    if (fn) fn();
}
