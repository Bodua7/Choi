export function formatBigNumber(value) {
    const str = value.toString();
    const len = str.length;

    if (len <= 3) return str;
    
    const units = ["", "K", "M", "B", "T", "aa", "ab", "ac", "ad", "ae"];
    const unitIndex = Math.floor((len - 1) / 3);

    if (unitIndex < units.length) {
        const mainDigits = str.slice(0, len - unitIndex * 3);
        const decimalDigits = str.slice(len - unitIndex * 3, len - unitIndex * 3 + 2);
        return `${mainDigits}.${decimalDigits}${units[unitIndex]}`;
    }

    // Định dạng an toàn cho số cực lớn dạng scientific/array BigInt Safe
    return `${str[0]}.${str.slice(1, 3)}e+${len - 1}`;
}
