import { GAME_SYSTEMS } from '../core/systems.js';
import { MAP_REGIONS } from '../core/content/mapNodes.js';
import { getTierName } from '../core/content/systemLore.js';
import { MATERIAL_TIERS } from '../core/materials.js';
import { ACHIEVEMENTS } from '../core/achievements.js';
import { REBIRTH_UNLOCK_STAGE } from '../core/rebirth.js';
import { rollGacha, GACHA_COST_CRYSTAL, getClaimableBattlePassTiers, claimBattlePassTier, BATTLE_PASS_TIERS } from '../core/gacha.js';
import { SKINS, getSkinById } from '../core/skin.js';
import { ASSET_CREDITS } from '../core/content/credits.js';
import { formatBigNumber } from './formatter.js';

// Phân bổ 12 Hệ thống Cốt lõi vào các Tab điều hướng theo sơ đồ layout mục 4.4 GDD
// (mở rộng thêm 'progress' và 'settings' — 2 gap đã xác định: endgame Chuyển Sinh/
// Thành Tựu và Cài Đặt/backup save, chưa có trong layout gốc chỉ 5 tab)
// Gộp 9 tab gốc còn lại 6 cho gọn thanh điều hướng di động: "social" gộp BXH/Đấu
// Trường/Boss TG (đều là tính năng nhiều-người-chơi qua Supabase); "other" gộp Tiến
// Trình/Cài Đặt (đều là màn hình phụ, không phải vòng lặp chơi chính). Biến module-level
// dưới đây giữ sub-tab đang mở vì renderTabContent() xóa sạch container mỗi lần gọi lại.
let activeSocialSubTab = 'leaderboard'; // 'leaderboard' | 'arena' | 'worldboss'
let activeOtherSubTab = 'progress'; // 'progress' | 'settings'

export const TAB_SYSTEM_MAP = {
    base: ['CHARACTER', 'ALLY', 'SHELTER', 'WORLD_TREE'],
    skill: ['SKILL', 'TALENT', 'FORMATION'],
    forge: ['EQUIPMENT', 'FORGE', 'MATERIAL', 'TECH_TREE'],
    dungeon: [], // Phó Bản: không nâng cấp hệ thống, hiển thị chiến lực + hàng chờ hồi sinh
    shop: [], // Shop: đổi tài nguyên + nâng cấp Đan Dược
    social: [], // Nhiều Người: BXH + Đấu Trường + Boss TG (sub-tab, đều qua Supabase)
    other: [] // Khác: Tiến Trình (Chuyển Sinh/Thành Tựu) + Cài Đặt (sub-tab)
};

export function renderTabContent(tabKey, state, container, callbacks) {
    container.innerHTML = '';

    if (tabKey === 'dungeon') {
        renderDungeonPanel(state, container, callbacks);
        return;
    }
    if (tabKey === 'shop') {
        renderShopPanel(state, container, callbacks);
        return;
    }
    if (tabKey === 'social') {
        renderSocialPanel(state, container, callbacks);
        return;
    }
    if (tabKey === 'other') {
        renderOtherPanel(state, container, callbacks);
        return;
    }

    if (tabKey === 'base') {
        container.appendChild(renderMapSection(state, callbacks));
        container.appendChild(renderRecruitPanel(state, callbacks));
        container.appendChild(renderStatsSummary(state));
    }

    const systemKeys = TAB_SYSTEM_MAP[tabKey] || [];
    for (const key of systemKeys) {
        if (key === 'ALLY') { container.appendChild(renderAlliesPanel(state, callbacks)); continue; }
        container.appendChild(renderSystemRow(key, state, callbacks));
    }

    // Hệ 8 - Vật Liệu: kho + quy đổi riêng, hiển thị thêm dưới dòng nâng cấp MATERIAL
    // thông thường (tab forge — xem TAB_SYSTEM_MAP)
    if (tabKey === 'forge') {
        container.appendChild(renderMaterialsPanel(state, callbacks));
    }
}

// Bản Đồ Thế Giới & Phe Phái: chọn vùng (mở khóa theo Bậc Phó Bản đã vượt qua),
// mỗi vùng có 1 phe Đồng Minh (buff thật) và 1 phe Đối Địch (Boss vùng đó khó hơn).
function renderMapSection(state, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'map-section';

    const current = state.getCurrentRegion();
    const header = document.createElement('div');
    header.className = 'map-header';
    header.innerHTML = `<span>Bản Đồ Thế Giới</span><b>${current.name}</b>`;
    wrap.appendChild(header);

    const list = document.createElement('div');
    list.className = 'map-region-list';

    for (const region of MAP_REGIONS) {
        const unlocked = state.isRegionUnlocked(region.id);
        const isCurrent = region.id === state.currentRegion;

        const card = document.createElement('div');
        card.className = 'map-region-card' + (isCurrent ? ' active' : '') + (unlocked ? '' : ' locked');

        const bossDiff = region.rivalFaction.bossHpBP === 100000 ? '' :
            ` (Boss +${Math.round(region.rivalFaction.bossHpBP / 1000 - 100)}% HP)`;

        card.innerHTML = `
            <div class="map-region-name">${region.name}</div>
            <div class="map-region-desc">${region.description}</div>
            <div class="map-region-factions">
                <span class="faction-ally">⚔ Đồng Minh: ${region.allyFaction.name}</span>
                <span class="faction-rival">☠ Đối Địch: ${region.rivalFaction.name}${bossDiff}</span>
            </div>
        `;

        const btn = document.createElement('button');
        btn.className = 'map-select-btn';
        if (!unlocked) {
            btn.textContent = `Mở ở Bậc ${region.unlockStage + 1}`;
            btn.disabled = true;
        } else if (isCurrent) {
            btn.textContent = 'Đang ở vùng này';
            btn.disabled = true;
        } else {
            btn.textContent = 'Di chuyển đến vùng này';
            btn.addEventListener('click', () => callbacks.onSelectRegion(region.id));
        }
        card.appendChild(btn);
        list.appendChild(card);
    }

    wrap.appendChild(list);
    return wrap;
}

// Một dòng Hệ Thống Cốt Lõi (Trang Bị, Kỹ Năng, ...): hiển thị Bậc/Cấp hiện tại +
// nút Nâng cấp (hoặc Đột Phá khi đạt +100/100), dùng chung cho các tab base/skill/forge
function renderSystemRow(systemKey, state, callbacks) {
    const def = GAME_SYSTEMS[systemKey];
    const sys = state.systems[systemKey];
    // Tên Bậc cụ thể theo lore (systemLore.js) khi có; CHARACTER dùng thân phận riêng
    // (characterTitles.js, đọc qua state.getCharacterTitle() ở renderStatsSummary),
    // các hệ chưa có bảng lore (SHELTER có, còn lại đã phủ đủ 9/9 hệ dùng chuỗi Bậc)
    // fallback về "Bậc N" như cũ.
    const tierLabel = systemKey === 'CHARACTER'
        ? state.getCharacterTitle()
        : (getTierName(systemKey, sys.tier) || `Bậc ${sys.tier}`);

    const row = document.createElement('div');
    row.className = 'system-row';

    const info = document.createElement('div');
    info.className = 'system-info';
    info.innerHTML = `
        <div class="system-name">${def.name} <span class="system-tier">${tierLabel}</span></div>
        <div class="system-level">+${sys.level}/100</div>
    `;
    row.appendChild(info);

    const btn = document.createElement('button');
    btn.className = 'system-upgrade-btn';
    if (sys.level >= 100) {
        btn.textContent = 'ĐỘT PHÁ';
        btn.classList.add('breakthrough');
    } else {
        const cost = state.getUpgradeCost(systemKey);
        btn.textContent = `Nâng cấp (${formatBigNumber(cost)} Lõi)`;
        if (!state.canUpgrade(systemKey)) btn.disabled = true;
    }
    btn.addEventListener('click', () => {
        const result = state.upgradeSystem(systemKey);
        if (result) { callbacks.playSfx('upgrade'); callbacks.onStateChanged(); }
    });
    row.appendChild(btn);

    return row;
}

// Chiêu Mộ: cách chính để tăng Bầy Zombie Phân Thân, dùng Gỗ + Đá, giới hạn bởi Hầm Trú Ẩn
function renderRecruitPanel(state, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'recruit-panel';

    const cost = state.getRecruitCost();
    const capacity = state.getMaxCapacity();
    const atCapacity = state.swarmCount >= capacity;

    wrap.innerHTML = `
        <div class="recruit-header">
            <span>Bầy Zombie Phân Thân</span>
            <b>${formatBigNumber(BigInt(state.swarmCount))} / ${formatBigNumber(BigInt(capacity))}</b>
        </div>
    `;

    const btn = document.createElement('button');
    btn.className = 'recruit-btn';
    btn.textContent = atCapacity
        ? 'Đã đầy Hầm Trú Ẩn (nâng cấp để mở rộng)'
        : `Chiêu Mộ (${formatBigNumber(cost.wood)} Gỗ, ${formatBigNumber(cost.stone)} Đá)`;
    if (atCapacity || !state.canRecruit()) btn.disabled = true;
    btn.addEventListener('click', () => {
        if (state.recruit()) { callbacks.playSfx('recruit'); callbacks.onStateChanged(); }
    });
    wrap.appendChild(btn);

    return wrap;
}

// Tổng quan chỉ số: cho người chơi thấy các Hệ Thống Cốt Lõi đang thật sự cộng dồn hiệu ứng gì
function renderStatsSummary(state) {
    const wrap = document.createElement('div');
    wrap.className = 'stats-summary';

    const yieldBP = state.getMultiplierBP('yield');
    const atkBP = state.getMultiplierBP('atk');
    const survivalBP = state.getSurvivalBP();

    const yieldPct = (Number(yieldBP - 100000n) / 1000).toFixed(1);
    const atkPct = (Number(atkBP - 100000n) / 1000).toFixed(1);
    const survivalPct = (Number(survivalBP) / 1000).toFixed(1);

    wrap.innerHTML = `
        <div class="stat-line">Sản lượng: <b>+${yieldPct}%</b> <span class="stat-hint">(Kỹ Năng, Đồng Minh, Rèn Đúc, Vật Liệu, Phương Hằng, Tiến Hóa, Bản Đồ)</span></div>
        <div class="stat-line">Sát thương: <b>+${atkPct}%</b> <span class="stat-hint">(Thần Thông, Pháp Trận, Phương Hằng, Tiến Hóa)</span></div>
        <div class="stat-line">Tỉ lệ sống sót Phó Bản: <b>${survivalPct}%</b> <span class="stat-hint">(Thần Thụ, Đan Dược, Tiến Hóa)</span></div>
        <div class="stat-line">Tổng sát thương hiện tại: <b>${formatBigNumber(state.getTotalAttack())}</b></div>
    `;
    return wrap;
}

function renderDungeonPanel(state, container, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'dungeon-panel';

    const stage = state.getDungeonStage(state.highestCleared);
    const playerAtk = state.getTotalAttack();
    const winnable = playerAtk >= stage.bossHP;

    // Nhánh Tiến Hóa Zombie + Cốt truyện (GDD 3.1 & mục 3): gắn liền tiến trình Phó Bản
    const evo = state.getEvolutionStage();
    const nextEvo = state.getNextEvolutionStage();
    const arc = state.getCurrentStoryArc();
    const beat = state.getLatestStoryBeat();

    const evoBox = document.createElement('div');
    evoBox.className = 'evolution-box';
    evoBox.innerHTML = `
        <div class="evolution-current">
            <span class="evolution-dot" style="background:#${evo.colorHex.toString(16).padStart(6, '0')}"></span>
            <b>${evo.name}</b> <span class="evolution-role">— ${evo.role}</span>
        </div>
        ${nextEvo ? `<div class="evolution-next">Tiến hóa kế tiếp: ${nextEvo.name} tại Bậc ${nextEvo.unlockStage + 1}</div>` : `<div class="evolution-next">Đã đạt bậc tiến hóa cao nhất hiện có.</div>`}
    `;
    wrap.appendChild(evoBox);

    const storyBox = document.createElement('div');
    storyBox.className = 'story-box';
    storyBox.innerHTML = `
        <div class="story-arc">${arc.title} <span class="story-chapter">(Ch. ${arc.chapterRange[0]}-${arc.chapterRange[1]})</span></div>
        ${beat ? `<div class="story-beat">Ch.${beat.chapter}: ${beat.text}</div>` : ''}
    `;
    wrap.appendChild(storyBox);

    const stats = document.createElement('div');
    stats.className = 'dungeon-stats';
    stats.innerHTML = `
        <div>Bậc hiện tại: <b>${stage.stageIndex + 1}</b></div>
        <div>Boss HP: <b>${formatBigNumber(stage.bossHP)}</b></div>
        <div>Sát thương của bạn: <b class="${winnable ? 'stat-ok' : 'stat-bad'}">${formatBigNumber(playerAtk)}</b></div>
        <div>Đơn vị chờ tái tạo: <b id="revive-queue-count">${callbacks.getReviveQueueLength()}</b></div>
    `;
    wrap.appendChild(stats);

    if (state.lastDungeonResult) {
        const r = state.lastDungeonResult;
        const resultEl = document.createElement('div');
        resultEl.className = r.win ? 'dungeon-result win' : 'dungeon-result lose';
        let text = r.win
            ? `Đã vượt Bậc ${r.stageIndex + 1}! Nhận thưởng Lõi + Tinh Thạch.`
            : `Thua ở Bậc ${r.stageIndex + 1}. Mất ${r.deaths} Phân Thân (đang chờ tái tạo).`;
        if (r.win && r.evolvedTo) text += ` Phân Thân tiến hóa thành ${r.evolvedTo.name}!`;
        if (r.win && r.storyBeat) text += ` Ch.${r.storyBeat.chapter}: ${r.storyBeat.text}`;
        resultEl.textContent = text;
        wrap.appendChild(resultEl);
    }

    const btn = document.createElement('button');
    btn.className = 'dungeon-enter-btn';
    btn.textContent = winnable ? 'Vào Phó Bản (Chắc thắng)' : 'Vào Phó Bản (Rủi ro thua)';
    btn.addEventListener('click', () => callbacks.onEnterDungeon());
    wrap.appendChild(btn);

    return container.appendChild(wrap);
}

// Shop: đổi tài nguyên theo tỉ giá cố định + honest placeholder cho phần cần thanh toán thật
function renderShopPanel(state, container, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'shop-panel';

    // Đổi tài nguyên: 20 Gỗ+Đá -> 1 Lõi, 30 Lõi -> 1 Tinh Thạch (tỉ giá cố định, không cần backend)
    const exchanges = [
        { id: 'wood_to_core', label: 'Đổi 50 Gỗ ➜ 5 Lõi', from: 'wood', fromAmt: 50n, to: 'core', toAmt: 5n },
        { id: 'stone_to_core', label: 'Đổi 40 Đá ➜ 5 Lõi', from: 'stone', fromAmt: 40n, to: 'core', toAmt: 5n },
        { id: 'core_to_crystal', label: 'Đổi 30 Lõi ➜ 1 Tinh Thạch', from: 'core', fromAmt: 30n, to: 'crystal', toAmt: 1n }
    ];

    for (const ex of exchanges) {
        const row = document.createElement('div');
        row.className = 'shop-row';
        const canAfford = state.resources[ex.from] >= ex.fromAmt;
        row.innerHTML = `<div class="shop-label">${ex.label}</div>`;
        const btn = document.createElement('button');
        btn.className = 'shop-btn';
        btn.textContent = 'Đổi';
        if (!canAfford) btn.disabled = true;
        btn.addEventListener('click', () => {
            if (state.resources[ex.from] < ex.fromAmt) return;
            state.resources[ex.from] -= ex.fromAmt;
            state.resources[ex.to] += ex.toAmt;
            callbacks.onStateChanged();
        });
        row.appendChild(btn);
        wrap.appendChild(row);
    }

    // Đan Dược: hệ thống duy nhất còn lại, nâng cấp bằng Tinh Thạch thay vì Lõi (khan hiếm hơn)
    wrap.appendChild(renderPillRow(state, callbacks));

    wrap.appendChild(renderGachaSection(state, callbacks));
    wrap.appendChild(renderBattlePassSection(state, callbacks));
    wrap.appendChild(renderSkinSection(state, callbacks));

    container.appendChild(wrap);
}

// Triệu Hồi (Gacha) MOCK — dùng Tinh Thạch trong game, không có cổng thanh toán thật.
function renderGachaSection(state, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'gacha-section';

    const header = document.createElement('div');
    header.className = 'shop-section-header';
    header.textContent = 'Triệu Hồi';
    wrap.appendChild(header);

    const note = document.createElement('div');
    note.className = 'shop-mock-note';
    note.textContent = 'Mock demo — quy đổi bằng Tinh Thạch trong game, không phải cổng thanh toán thật.';
    wrap.appendChild(note);

    const btn = document.createElement('button');
    btn.className = 'gacha-roll-btn';
    btn.textContent = `Triệu Hồi (${formatBigNumber(GACHA_COST_CRYSTAL)} Tinh Thạch)`;
    if (state.resources.crystal < GACHA_COST_CRYSTAL) btn.disabled = true;
    const resultEl = document.createElement('div');
    resultEl.className = 'gacha-result';
    btn.addEventListener('click', () => {
        const result = rollGacha(state);
        if (!result) return;
        if (result.type === 'skin') {
            resultEl.textContent = `Nhận Skin mới: ${result.skin.name}!`;
        } else if (result.type === 'material') {
            resultEl.textContent = `Nhận ${formatBigNumber(result.amount)} ${result.name}`;
        } else {
            resultEl.textContent = `Nhận ${formatBigNumber(result.amount)} ${result.type === 'core' ? 'Lõi' : 'Tinh Thạch'}${result.note ? ' — ' + result.note : ''}`;
        }
        callbacks.playSfx('recruit');
        callbacks.onStateChanged();
    });
    wrap.appendChild(btn);
    wrap.appendChild(resultEl);

    return wrap;
}

// Vé Mùa (Battle Pass) MOCK — mốc thưởng miễn phí theo Bậc Phó Bản, không có track trả phí.
function renderBattlePassSection(state, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'battlepass-section';

    const header = document.createElement('div');
    header.className = 'shop-section-header';
    header.textContent = 'Vé Mùa (Miễn Phí)';
    wrap.appendChild(header);

    const claimable = getClaimableBattlePassTiers(state);

    BATTLE_PASS_TIERS.forEach((tier, index) => {
        const row = document.createElement('div');
        row.className = 'battlepass-row';
        const claimed = state.claimedBattlePassTiers.includes(index);
        const unlocked = state.highestCleared >= tier.stage;
        row.innerHTML = `<span>Bậc Phó Bản ${tier.stage}: ${formatBigNumber(tier.rewardCore)} Lõi, ${formatBigNumber(tier.rewardCrystal)} Tinh Thạch</span>`;
        const btn = document.createElement('button');
        btn.className = 'battlepass-claim-btn';
        if (claimed) { btn.textContent = 'Đã Nhận'; btn.disabled = true; }
        else if (!unlocked) { btn.textContent = 'Chưa Mở Khóa'; btn.disabled = true; }
        else { btn.textContent = 'Nhận Thưởng'; }
        btn.addEventListener('click', () => {
            if (claimBattlePassTier(state, index)) callbacks.onStateChanged();
        });
        row.appendChild(btn);
        wrap.appendChild(row);
    });

    return wrap;
}

// Skin: chọn màu neon hiển thị cho Bầy Zombie trong số Skin đã mở khóa qua Triệu Hồi.
function renderSkinSection(state, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'skin-section';

    const header = document.createElement('div');
    header.className = 'shop-section-header';
    header.textContent = 'Skin';
    wrap.appendChild(header);

    const list = document.createElement('div');
    list.className = 'skin-list';
    for (const skin of SKINS) {
        const unlocked = state.unlockedSkins.includes(skin.id);
        const btn = document.createElement('button');
        btn.className = 'skin-btn' + (state.selectedSkin === skin.id ? ' active' : '');
        btn.textContent = unlocked ? skin.name : `??? (Triệu Hồi để mở)`;
        if (!unlocked) btn.disabled = true;
        else btn.addEventListener('click', () => {
            state.selectedSkin = skin.id;
            callbacks.onStateChanged();
        });
        list.appendChild(btn);
    }
    wrap.appendChild(list);

    return wrap;
}

function renderPillRow(state, callbacks) {
    const def = GAME_SYSTEMS.PILL;
    const sys = state.systems.PILL;
    const row = document.createElement('div');
    row.className = 'system-row';

    const info = document.createElement('div');
    info.className = 'system-info';
    info.innerHTML = `
        <div class="system-name">${def.name} <span class="system-tier">Bậc ${sys.tier}</span></div>
        <div class="system-level">+${sys.level}/100</div>
    `;
    row.appendChild(info);

    const btn = document.createElement('button');
    btn.className = 'system-upgrade-btn';
    if (sys.level >= 100) {
        btn.textContent = 'ĐỘT PHÁ';
        btn.classList.add('breakthrough');
    } else {
        const cost = BigInt(3 + sys.level);
        btn.textContent = `Luyện (${formatBigNumber(cost)} Tinh Thạch)`;
        if (state.resources.crystal < cost) btn.disabled = true;
        btn.addEventListener('click', () => {
            if (state.resources.crystal < cost) return;
            state.resources.crystal -= cost;
            sys.level += 1;
            callbacks.onStateChanged();
        });
        row.appendChild(btn);
        return row;
    }
    btn.addEventListener('click', () => {
        const result = state.upgradeSystem('PILL');
        if (result) callbacks.onStateChanged();
    });
    row.appendChild(btn);
    return row;
}

// Bảng Xếp Hạng: đọc top người chơi theo Sát Thương (combat_power) từ Supabase +
// cho phép nộp điểm của chính mình. Không có tài khoản thật (MVP) — danh tính chỉ
// là 1 UUID + tên tự đặt lưu trong localStorage của thiết bị (xem src/net/leaderboard.js).
// Tab "Nhiều Người": gộp BXH + Đấu Trường + Boss TG dưới 1 sub-nav (xem
// activeSocialSubTab ở đầu file) — cả 3 đều là tính năng online qua Supabase.
function renderSocialPanel(state, container, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'subtab-wrap';

    const nav = document.createElement('div');
    nav.className = 'subtab-nav';
    const subtabs = [
        { key: 'leaderboard', label: 'BXH' },
        { key: 'arena', label: 'Đấu Trường' },
        { key: 'worldboss', label: 'Boss TG' }
    ];
    subtabs.forEach(st => {
        const btn = document.createElement('button');
        btn.className = 'subtab-btn' + (activeSocialSubTab === st.key ? ' active' : '');
        btn.textContent = st.label;
        btn.addEventListener('click', () => {
            activeSocialSubTab = st.key;
            renderSocialPanel(state, container, callbacks);
        });
        nav.appendChild(btn);
    });
    wrap.appendChild(nav);

    const body = document.createElement('div');
    body.className = 'subtab-body';
    wrap.appendChild(body);

    container.appendChild(wrap);

    if (activeSocialSubTab === 'leaderboard') renderLeaderboardPanel(state, body, callbacks);
    else if (activeSocialSubTab === 'arena') renderArenaPanel(state, body, callbacks);
    else if (activeSocialSubTab === 'worldboss') renderWorldBossPanel(state, body, callbacks);
}

// Tab "Khác": gộp Tiến Trình (Chuyển Sinh/Thành Tựu) + Cài Đặt dưới 1 sub-nav — cả
// 2 đều là màn hình phụ, không thuộc vòng lặp chơi chính (base/skill/forge/dungeon/shop).
function renderOtherPanel(state, container, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'subtab-wrap';

    const nav = document.createElement('div');
    nav.className = 'subtab-nav';
    const subtabs = [
        { key: 'progress', label: 'Tiến Trình' },
        { key: 'settings', label: 'Cài Đặt' }
    ];
    subtabs.forEach(st => {
        const btn = document.createElement('button');
        btn.className = 'subtab-btn' + (activeOtherSubTab === st.key ? ' active' : '');
        btn.textContent = st.label;
        btn.addEventListener('click', () => {
            activeOtherSubTab = st.key;
            renderOtherPanel(state, container, callbacks);
        });
        nav.appendChild(btn);
    });
    wrap.appendChild(nav);

    const body = document.createElement('div');
    body.className = 'subtab-body';
    wrap.appendChild(body);

    container.appendChild(wrap);

    if (activeOtherSubTab === 'progress') renderProgressPanel(state, body, callbacks);
    else renderSettingsPanel(state, body, callbacks);
}

function renderLeaderboardPanel(state, container, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'leaderboard-panel';

    const nameRow = document.createElement('div');
    nameRow.className = 'leaderboard-name-row';
    const input = document.createElement('input');
    input.type = 'text';
    input.maxLength = 16;
    input.placeholder = 'Tên hiển thị của bạn';
    input.value = callbacks.getDisplayName();
    input.className = 'leaderboard-name-input';
    nameRow.appendChild(input);
    wrap.appendChild(nameRow);

    const submitBtn = document.createElement('button');
    submitBtn.className = 'leaderboard-submit-btn';
    submitBtn.textContent = 'Nộp Điểm Lên Bảng Xếp Hạng';
    wrap.appendChild(submitBtn);

    const statusEl = document.createElement('div');
    statusEl.className = 'leaderboard-status';
    wrap.appendChild(statusEl);

    const listEl = document.createElement('div');
    listEl.className = 'leaderboard-list';
    listEl.textContent = 'Đang tải bảng xếp hạng...';
    wrap.appendChild(listEl);

    async function refreshList() {
        const result = await callbacks.fetchLeaderboard();
        if (!result.ok) {
            listEl.textContent = `Không tải được bảng xếp hạng (${result.error}). ` +
                `Kiểm tra đã chạy supabase/leaderboard.sql trên Supabase chưa.`;
            return;
        }
        if (result.rows.length === 0) {
            listEl.textContent = 'Chưa có ai nộp điểm. Hãy là người đầu tiên!';
            return;
        }
        listEl.innerHTML = '';
        const myId = await callbacks.getLocalPlayerId();
        result.rows.forEach((row, i) => {
            const item = document.createElement('div');
            item.className = 'leaderboard-row' + (row.player_id === myId ? ' me' : '');
            item.innerHTML = `
                <span class="lb-rank">#${i + 1}</span>
                <span class="lb-name">${escapeHtml(row.display_name)}</span>
                <span class="lb-cp">${formatBigNumber(BigInt(row.combat_power))}</span>
            `;
            listEl.appendChild(item);
        });
    }

    submitBtn.addEventListener('click', async () => {
        callbacks.setDisplayName(input.value.trim() || 'Người Chơi Ẩn Danh');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Đang nộp...';
        const result = await callbacks.submitLeaderboardScore();
        submitBtn.disabled = false;
        submitBtn.textContent = 'Nộp Điểm Lên Bảng Xếp Hạng';
        statusEl.textContent = result.ok ? 'Đã nộp điểm thành công!' : `Lỗi: ${result.error}`;
        statusEl.className = 'leaderboard-status ' + (result.ok ? 'ok' : 'bad');
        if (result.ok) refreshList();
    });

    refreshList();
    container.appendChild(wrap);
}

// Boss Cốt Truyện chung server (GDD 7.3): 1 thanh HP DUY NHẤT chia sẻ cho toàn bộ
// người chơi qua Supabase (src/net/worldBoss.js) — khác Boss Phó Bản trong tab
// "Phó Bản" vốn mỗi người đánh riêng. Đòn đánh dùng luôn tổng công hiện tại
// (state.getTotalAttack()), không tiêu hao tài nguyên/vé.
function renderWorldBossPanel(state, container, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'worldboss-panel';

    const header = document.createElement('div');
    header.className = 'worldboss-header';
    header.textContent = 'Boss Cốt Truyện (Chung Server)';
    wrap.appendChild(header);

    const bodyEl = document.createElement('div');
    bodyEl.className = 'worldboss-body';
    bodyEl.textContent = 'Đang tải trạng thái Boss...';
    wrap.appendChild(bodyEl);

    const attackBtn = document.createElement('button');
    attackBtn.className = 'worldboss-attack-btn';
    attackBtn.textContent = `Tấn Công (${formatBigNumber(state.getTotalAttack())} sát thương)`;
    attackBtn.disabled = true;
    wrap.appendChild(attackBtn);

    const statusEl = document.createElement('div');
    statusEl.className = 'worldboss-status';
    wrap.appendChild(statusEl);

    const topHeader = document.createElement('div');
    topHeader.className = 'worldboss-top-header';
    topHeader.textContent = 'Đóng Góp Sát Thương Chu Kỳ Này';
    wrap.appendChild(topHeader);

    const topListEl = document.createElement('div');
    topListEl.className = 'worldboss-top-list';
    wrap.appendChild(topListEl);

    let currentCycle = null;

    async function refreshTop() {
        if (currentCycle === null) return;
        const result = await callbacks.fetchWorldBossTop(currentCycle);
        if (!result.ok) {
            topListEl.textContent = `Không tải được (${result.error}).`;
            return;
        }
        if (result.rows.length === 0) {
            topListEl.textContent = 'Chưa ai ra đòn trong chu kỳ này. Hãy là người đầu tiên!';
            return;
        }
        topListEl.innerHTML = '';
        const myId = await callbacks.getLocalPlayerId();
        result.rows.forEach((row, i) => {
            const item = document.createElement('div');
            item.className = 'worldboss-top-row' + (row.player_id === myId ? ' me' : '');
            item.innerHTML = `
                <span class="lb-rank">#${i + 1}</span>
                <span class="lb-name">${escapeHtml(row.display_name)}</span>
                <span class="lb-cp">${formatBigNumber(BigInt(Math.round(Number(row.total_damage))))}</span>
            `;
            topListEl.appendChild(item);
        });
    }

    async function refreshBoss() {
        const result = await callbacks.fetchWorldBoss();
        if (!result.ok) {
            bodyEl.textContent = `Không tải được Boss (${result.error}). ` +
                `Kiểm tra đã chạy supabase/worldboss.sql trên Supabase chưa.`;
            attackBtn.disabled = true;
            return;
        }
        const boss = result.boss;
        currentCycle = boss.cycle_number;
        const hp = Number(boss.hp_remaining);
        const max = Number(boss.max_hp);
        const pct = max > 0 ? Math.max(0, Math.min(100, (hp / max) * 100)) : 0;
        bodyEl.innerHTML = `
            <div class="worldboss-name">${escapeHtml(boss.boss_name)} — Chu Kỳ #${boss.cycle_number}</div>
            <div class="worldboss-hp-bar"><div class="worldboss-hp-fill" style="width:${pct}%"></div></div>
            <div class="worldboss-hp-text">${formatBigNumber(BigInt(Math.round(hp)))} / ${formatBigNumber(BigInt(Math.round(max)))} HP</div>
        `;
        attackBtn.disabled = hp <= 0;
        attackBtn.textContent = hp <= 0
            ? 'Boss đã gục — đang mở chu kỳ mới...'
            : `Tấn Công (${formatBigNumber(state.getTotalAttack())} sát thương)`;
        refreshTop();

        if (hp <= 0) {
            const adv = await callbacks.advanceWorldBoss();
            if (adv.ok) refreshBoss();
        }
    }

    attackBtn.addEventListener('click', async () => {
        attackBtn.disabled = true;
        const dmg = state.getTotalAttack();
        const result = await callbacks.attackWorldBoss(dmg);
        if (!result.ok) {
            statusEl.textContent = `Lỗi: ${result.error}`;
            statusEl.className = 'worldboss-status bad';
            attackBtn.disabled = false;
            return;
        }
        statusEl.textContent = result.killed
            ? 'ĐÒN QUYẾT ĐỊNH! Boss đã gục, chu kỳ mới sắp mở ra.'
            : 'Đã ra đòn! Sát thương đã được cộng vào thanh HP chung.';
        statusEl.className = 'worldboss-status ok';
        callbacks.playSfx(result.killed ? 'achievement' : 'upgrade');
        refreshBoss();
    });

    refreshBoss();
    container.appendChild(wrap);
}

// Hệ 5 - Đồng Minh: 8 nhân vật cố định (allies.js), mở khóa tuần tự theo Bậc ALLY.
// Sức mạnh thật vẫn cộng qua renderSystemRow('ALLY') như trước — panel này chỉ thêm
// danh tính/vai trò, rồi nút nâng cấp chung của hệ ALLY vẫn hiển thị ngay sau đó.
function renderAlliesPanel(state, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'allies-panel';

    const header = document.createElement('div');
    header.className = 'allies-header';
    header.textContent = 'Đồng Minh';
    wrap.appendChild(header);

    const unlocked = state.getUnlockedAllies();
    const next = state.getNextAlly();

    const list = document.createElement('div');
    list.className = 'allies-list';
    for (const ally of unlocked) {
        const card = document.createElement('div');
        card.className = 'ally-card';
        card.innerHTML = `<b>${ally.name}</b> <span class="ally-role">(${ally.role})</span><div class="ally-desc">${ally.desc}</div>`;
        list.appendChild(card);
    }
    if (next) {
        const lockedCard = document.createElement('div');
        lockedCard.className = 'ally-card locked';
        lockedCard.innerHTML = `<b>???</b> <span class="ally-role">(${next.role})</span><div class="ally-desc">Mở khóa khi Đồng Minh đạt Bậc ${next.order}</div>`;
        list.appendChild(lockedCard);
    }
    wrap.appendChild(list);

    // Nút nâng cấp/Đột Phá hệ ALLY vẫn giữ nguyên (cộng dồn affects.yield như cũ +
    // mỗi lần Đột Phá mở khóa 1 Đồng Minh mới trong danh sách phía trên)
    wrap.appendChild(renderSystemRow('ALLY', state, callbacks));

    return wrap;
}

// Hệ 8 - Vật Liệu: kho 7 tier + nút quy đổi lên tier kế tiếp (materials.js)
function renderMaterialsPanel(state, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'materials-panel';

    const header = document.createElement('div');
    header.className = 'materials-header';
    header.textContent = 'Vật Liệu';
    wrap.appendChild(header);

    MATERIAL_TIERS.forEach((tierDef, i) => {
        const row = document.createElement('div');
        row.className = 'material-row';

        const amount = state.materials[tierDef.id];
        const info = document.createElement('div');
        info.className = 'material-info';
        info.innerHTML = `<span class="material-name">${tierDef.name}</span> <b>${formatBigNumber(amount)}</b>`;
        row.appendChild(info);

        if (i < MATERIAL_TIERS.length - 1) {
            const cost = state.getMaterialConvertCost(i);
            const btn = document.createElement('button');
            btn.className = 'material-convert-btn';
            btn.textContent = `Quy Đổi (${formatBigNumber(cost)} ➜ 1 ${MATERIAL_TIERS[i + 1].name})`;
            if (!state.canConvertMaterial(i)) btn.disabled = true;
            btn.addEventListener('click', () => {
                if (state.convertMaterial(i)) callbacks.onStateChanged();
            });
            row.appendChild(btn);
        }
        wrap.appendChild(row);
    });

    return wrap;
}

// Tiến Trình: Chuyển Sinh (endgame) + Thành Tựu dài hạn — 2 hệ chưa có trong bản gốc
function renderProgressPanel(state, container, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'progress-panel';

    const rebirthBox = document.createElement('div');
    rebirthBox.className = 'rebirth-box';
    rebirthBox.innerHTML = `
        <div class="rebirth-header">Chuyển Sinh</div>
        <div class="rebirth-count">Đã Chuyển Sinh: <b>${state.rebirthCount}</b> lần (mỗi lần +15% sản lượng &amp; sát thương vĩnh viễn)</div>
    `;
    const rebirthBtn = document.createElement('button');
    rebirthBtn.className = 'rebirth-btn';
    if (state.canRebirth()) {
        rebirthBtn.textContent = 'Chuyển Sinh Ngay (reset tiến trình Phó Bản, giữ Thành Tựu + bonus)';
        rebirthBtn.addEventListener('click', () => {
            if (state.doRebirth()) {
                callbacks.onStateChanged();
            }
        });
    } else {
        rebirthBtn.textContent = `Mở khóa ở Bậc Phó Bản ${REBIRTH_UNLOCK_STAGE + 1} (hiện tại: Bậc ${state.highestCleared + 1})`;
        rebirthBtn.disabled = true;
    }
    rebirthBox.appendChild(rebirthBtn);
    wrap.appendChild(rebirthBox);

    const achHeader = document.createElement('div');
    achHeader.className = 'achievements-header';
    achHeader.textContent = `Thành Tựu (${state.unlockedAchievements.length}/${ACHIEVEMENTS.length})`;
    wrap.appendChild(achHeader);

    const achList = document.createElement('div');
    achList.className = 'achievements-list';
    for (const ach of ACHIEVEMENTS) {
        const done = state.unlockedAchievements.includes(ach.id);
        const item = document.createElement('div');
        item.className = 'achievement-item' + (done ? ' done' : ' locked');
        item.innerHTML = `<b>${done ? '✓' : '•'} ${ach.name}</b><div class="achievement-desc">${ach.desc}</div>`;
        achList.appendChild(item);
    }
    wrap.appendChild(achList);

    container.appendChild(wrap);
}

// Cài Đặt: âm thanh (placeholder — chưa có audio thật trong dự án), backup save
// thủ công (xuất/nhập .json), reset toàn bộ tiến độ (2 lớp xác nhận)
function renderSettingsPanel(state, container, callbacks) {
    const wrap = document.createElement('div');
    wrap.className = 'settings-panel';

    const soundRow = document.createElement('div');
    soundRow.className = 'settings-row';
    soundRow.innerHTML = `<span>Âm thanh</span>`;
    const soundBtn = document.createElement('button');
    soundBtn.className = 'settings-btn';
    soundBtn.textContent = callbacks.isSoundOn() ? 'Bật' : 'Tắt';
    soundBtn.addEventListener('click', () => {
        callbacks.toggleSound();
        soundBtn.textContent = callbacks.isSoundOn() ? 'Bật' : 'Tắt';
    });
    soundRow.appendChild(soundBtn);
    wrap.appendChild(soundRow);

    const soundNote = document.createElement('div');
    soundNote.className = 'settings-note';
    soundNote.textContent = 'Dự án hiện chưa có file âm thanh thật — cài đặt này chỉ lưu lựa chọn của bạn, sẽ phát huy tác dụng khi bổ sung audio.';
    wrap.appendChild(soundNote);

    // --- Thông báo (Web Push) ---
    const notifRow = document.createElement('div');
    notifRow.className = 'settings-row';
    notifRow.innerHTML = `<span>Thông báo</span>`;
    const notifBtn = document.createElement('button');
    notifBtn.className = 'settings-btn';
    notifBtn.textContent = '...';
    notifBtn.disabled = true;
    notifRow.appendChild(notifBtn);
    wrap.appendChild(notifRow);

    const notifNote = document.createElement('div');
    notifNote.className = 'settings-note';
    wrap.appendChild(notifNote);

    async function refreshNotifButton() {
        if (!callbacks.isPushSupported()) {
            notifBtn.textContent = 'Không hỗ trợ';
            notifBtn.disabled = true;
            notifNote.textContent = 'Trình duyệt này không hỗ trợ Web Push.';
            return;
        }
        const permission = callbacks.getPushPermission();
        if (permission === 'denied') {
            notifBtn.textContent = 'Đã bị chặn';
            notifBtn.disabled = true;
            notifNote.textContent = 'Bạn đã chặn thông báo cho trang này — cần vào cài đặt trình duyệt để bật lại.';
            return;
        }
        const enabled = await callbacks.isPushEnabled();
        notifBtn.disabled = false;
        notifBtn.textContent = enabled ? 'Tắt thông báo' : 'Bật thông báo';
        notifNote.textContent = enabled
            ? 'Sẽ báo khi Phó Bản mới mở, Phân Thân hồi sinh xong, vé Đấu Trường đầy... (kể cả khi đã đóng app, nếu server gửi push đã được thiết lập — xem README-push.md).'
            : 'Bật để nhận thông báo khi có sự kiện đáng chú ý trong lúc bạn không mở app.';
    }
    refreshNotifButton();

    notifBtn.addEventListener('click', async () => {
        notifBtn.disabled = true;
        const wasEnabled = notifBtn.textContent === 'Tắt thông báo';
        const result = wasEnabled ? await callbacks.disablePush() : await callbacks.enablePush();
        if (!result.ok) {
            notifNote.textContent = result.error || 'Có lỗi xảy ra, thử lại sau.';
        }
        await refreshNotifButton();
    });

    const exportRow = document.createElement('div');
    exportRow.className = 'settings-row';
    const exportBtn = document.createElement('button');
    exportBtn.className = 'settings-btn';
    exportBtn.textContent = 'Xuất Save (.json)';
    exportBtn.addEventListener('click', () => callbacks.exportSave());
    exportRow.appendChild(exportBtn);
    wrap.appendChild(exportRow);

    const importRow = document.createElement('div');
    importRow.className = 'settings-row';
    const importInput = document.createElement('input');
    importInput.type = 'file';
    importInput.accept = 'application/json';
    importInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) callbacks.importSave(file);
    });
    importRow.appendChild(importInput);
    wrap.appendChild(importRow);

    // --- Credits: ghi công tác giả asset bên thứ 3 (bắt buộc theo license, xem credits.js) ---
    if (ASSET_CREDITS.length > 0) {
        const creditsHeader = document.createElement('div');
        creditsHeader.className = 'settings-note';
        creditsHeader.style.marginTop = '4px';
        creditsHeader.textContent = 'Credits';
        wrap.appendChild(creditsHeader);

        for (const credit of ASSET_CREDITS) {
            const row = document.createElement('div');
            row.className = 'settings-row';
            row.style.flexDirection = 'column';
            row.style.alignItems = 'flex-start';
            row.style.gap = '4px';

            const nameEl = document.createElement('div');
            nameEl.textContent = credit.assetName;
            row.appendChild(nameEl);

            const link = document.createElement('a');
            link.href = credit.authorUrl;
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
            link.textContent = `by ${credit.author}`;
            link.style.color = '#00ffcc';
            row.appendChild(link);

            const usedForEl = document.createElement('div');
            usedForEl.className = 'settings-note';
            usedForEl.style.marginTop = '0';
            usedForEl.textContent = `${credit.usedFor} — ${credit.license}`;
            row.appendChild(usedForEl);

            wrap.appendChild(row);
        }
    }

    const resetBtn = document.createElement('button');
    resetBtn.className = 'settings-btn danger';
    resetBtn.textContent = 'Đặt Lại Toàn Bộ Tiến Độ';
    resetBtn.addEventListener('click', () => {
        if (confirm('Xóa toàn bộ tiến độ? Hành động này KHÔNG thể hoàn tác.')) {
            if (confirm('Xác nhận lần 2: bạn chắc chắn muốn xóa hết?')) {
                callbacks.resetProgress();
            }
        }
    });
    wrap.appendChild(resetBtn);

    container.appendChild(wrap);
}

// Đấu Trường: PvP GIẢ LẬP (arena.js) — đối thủ mô phỏng quanh chiến lực người chơi,
// không phải kết nối thời gian thực. Ghi rõ trong UI để không gây hiểu lầm.
function renderArenaPanel(state, container, callbacks) {
    container.innerHTML = '';
    const wrap = document.createElement('div');
    wrap.className = 'arena-panel';

    const note = document.createElement('div');
    note.className = 'arena-note';
    note.textContent = 'PvP bất đồng bộ thật: đối đầu snapshot chiến lực người chơi khác đã nộp lên BXH. Chưa có ai gần chiến lực của bạn thì tạm dùng đối thủ mô phỏng.';
    wrap.appendChild(note);

    const ticketRow = document.createElement('div');
    ticketRow.className = 'arena-tickets';
    const nextMs = state.arena.msUntilNextTicket();
    const nextMin = Math.ceil(nextMs / 60000);
    ticketRow.innerHTML = `Vé: <b>${state.arena.tickets}/5</b>` + (state.arena.tickets < 5 ? ` <span class="arena-timer">(vé kế tiếp sau ~${nextMin} phút)</span>` : '');
    wrap.appendChild(ticketRow);

    const streakRow = document.createElement('div');
    streakRow.className = 'arena-streak';
    streakRow.textContent = `Chuỗi thắng hiện tại: ${state.arena.winStreak}`;
    wrap.appendChild(streakRow);

    const fightBtn = document.createElement('button');
    fightBtn.className = 'arena-fight-btn';
    fightBtn.textContent = 'Thách Đấu (-1 Vé)';
    if (!state.arena.canFight()) fightBtn.disabled = true;
    wrap.appendChild(fightBtn);

    const statusEl = document.createElement('div');
    statusEl.className = 'arena-status';
    wrap.appendChild(statusEl);

    fightBtn.addEventListener('click', async () => {
        if (!state.arena.canFight()) return;
        fightBtn.disabled = true;
        fightBtn.textContent = 'Đang tìm đối thủ...';
        statusEl.textContent = '';
        statusEl.className = 'arena-status';

        // Cập nhật snapshot chiến lực của mình trước khi tìm đối thủ, để người khác
        // luôn thách đấu đúng sức mạnh mới nhất của mình (không bắt buộc thành công).
        await callbacks.submitLeaderboardScore();

        const myAtk = state.getTotalAttack();
        const oppResult = await callbacks.fetchArenaOpponents(myAtk);

        let opponent;
        let isReal = false;
        if (oppResult.ok && oppResult.rows.length > 0) {
            const pick = oppResult.rows[Math.floor(Math.random() * oppResult.rows.length)];
            opponent = {
                id: pick.player_id,
                name: pick.display_name,
                atk: BigInt(Math.max(1, Math.round(Number(pick.combat_power))))
            };
            isReal = true;
        } else {
            opponent = state.arena.generateOpponent(myAtk);
        }

        const result = state.arena.resolveFight(myAtk, opponent);
        if (!result) { callbacks.onStateChanged(); return; }

        if (isReal) {
            callbacks.recordArenaMatch({
                defenderId: opponent.id,
                defenderName: opponent.name,
                myAttack: myAtk,
                defenderAttack: opponent.atk,
                win: result.win
            });
        }

        state.resources.core += result.rewardCore;
        state.resources.crystal += result.rewardCrystal;
        callbacks.playSfx(result.win ? 'arenaWin' : 'arenaLose');
        callbacks.onStateChanged();
    });

    const historyHeader = document.createElement('div');
    historyHeader.className = 'arena-history-header';
    historyHeader.textContent = 'Lịch Sử Gần Đây';
    wrap.appendChild(historyHeader);

    const historyList = document.createElement('div');
    historyList.className = 'arena-history-list';
    if (state.arena.history.length === 0) {
        historyList.textContent = 'Chưa có trận đấu nào.';
    }
    for (const h of state.arena.history) {
        const row = document.createElement('div');
        row.className = 'arena-history-row' + (h.win ? ' win' : ' lose');
        row.innerHTML = `<span>${h.win ? 'THẮNG' : 'THUA'}</span> vs ${escapeHtml(h.opponentName)} <span class="arena-atk">(${formatBigNumber(h.opponentAtk)} sát thương)</span>`;
        historyList.appendChild(row);
    }
    wrap.appendChild(historyList);

    const defenseHeader = document.createElement('div');
    defenseHeader.className = 'arena-history-header';
    defenseHeader.textContent = 'Bạn Vừa Bị Thách Đấu Bởi';
    wrap.appendChild(defenseHeader);

    const defenseList = document.createElement('div');
    defenseList.className = 'arena-history-list';
    defenseList.textContent = 'Đang tải...';
    wrap.appendChild(defenseList);

    container.appendChild(wrap);

    callbacks.fetchArenaDefenseLog().then(result => {
        if (!result.ok) { defenseList.textContent = `Không tải được (${result.error}).`; return; }
        if (result.rows.length === 0) { defenseList.textContent = 'Chưa ai thách đấu bạn.'; return; }
        defenseList.innerHTML = '';
        result.rows.forEach(row => {
            const iWon = !row.win; // win trong bảng ghi theo góc nhìn attacker
            const item = document.createElement('div');
            item.className = 'arena-history-row' + (iWon ? ' win' : ' lose');
            item.innerHTML = `<span>${iWon ? 'BẠN THẮNG' : 'BẠN THUA'}</span> vs ${escapeHtml(row.attacker_name)} <span class="arena-atk">(${formatBigNumber(BigInt(Math.max(1, Math.round(Number(row.attacker_cp)))))} sát thương)</span>`;
            defenseList.appendChild(item);
        });
    });
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}
