-- Boss Cốt Truyện chung server (World Boss) — chạy toàn bộ file này trong
-- Supabase Dashboard > SQL Editor > New query > dán vào > Run.
-- Yêu cầu đã chạy leaderboard.sql trước đó (dùng chung ý tưởng player_id ẩn danh
-- từ localStorage, xem src/net/leaderboard.js).

-- Trạng thái Boss hiện tại: chỉ 1 dòng duy nhất (id = 1) cho toàn server.
create table if not exists world_boss (
  id            integer primary key default 1,
  cycle_number  integer not null default 1,
  boss_name     text not null default 'Tà Thần Cổ Đại',
  max_hp        numeric not null default 1000000,
  hp_remaining  numeric not null default 1000000,
  started_at    timestamptz not null default now()
);

insert into world_boss (id, cycle_number, boss_name, max_hp, hp_remaining)
values (1, 1, 'Tà Thần Cổ Đại', 1000000, 1000000)
on conflict (id) do nothing;

-- Đóng góp sát thương theo từng người chơi, theo từng chu kỳ Boss (cycle_number) —
-- dùng để hiển thị bảng xếp hạng đóng góp và (sau này) chia thưởng theo tỉ lệ.
create table if not exists world_boss_damage (
  player_id      uuid not null,
  cycle_number   integer not null,
  display_name   text not null default 'Người Chơi Ẩn Danh',
  total_damage   numeric not null default 0,
  updated_at     timestamptz not null default now(),
  primary key (player_id, cycle_number)
);

create index if not exists world_boss_damage_cycle_idx
  on world_boss_damage (cycle_number, total_damage desc);

alter table world_boss enable row level security;
alter table world_boss_damage enable row level security;

-- Ai cũng đọc được trạng thái Boss + bảng đóng góp (công khai)
drop policy if exists world_boss_read_all on world_boss;
create policy world_boss_read_all on world_boss for select using (true);

drop policy if exists world_boss_damage_read_all on world_boss_damage;
create policy world_boss_damage_read_all on world_boss_damage for select using (true);

-- KHÔNG cấp policy insert/update trực tiếp cho client trên 2 bảng trên (khác với
-- leaderboard.sql chấp nhận ghi mở cho đơn giản) — vì world_boss là 1 dòng dùng
-- chung cho tất cả người chơi, ghi trực tiếp từ nhiều client cùng lúc sẽ mất sát
-- thương do race condition (client A đọc hp=100, client B đọc hp=100, cả 2 cùng
-- trừ và ghi đè nhau). Mọi thay đổi phải đi qua 2 hàm SECURITY DEFINER dưới đây,
-- chạy nguyên tử (atomic) trong 1 câu UPDATE duy nhất phía Postgres.

-- Chống giả mạo: hàm KHÔNG còn nhận p_player_id do client tự khai — người đánh
-- (player_id ghi vào world_boss_damage) lấy thẳng từ auth.uid() của phiên đăng
-- nhập ẩn danh Supabase Auth thật đang gọi RPC này, nên không ai "đánh hộ" Boss
-- dưới tên người khác được nữa. Yêu cầu đã bật Anonymous Sign-Ins (xem leaderboard.sql).
drop function if exists deal_world_boss_damage(uuid, text, numeric);

create or replace function deal_world_boss_damage(
  p_display_name text,
  p_damage numeric
) returns table(hp_remaining numeric, max_hp numeric, cycle_number integer, killed boolean)
language plpgsql
security definer
as $$
declare
  v_hp numeric;
  v_max numeric;
  v_cycle integer;
  v_player_id uuid := auth.uid();
begin
  if v_player_id is null then
    raise exception 'auth required: chưa đăng nhập ẩn danh Supabase';
  end if;

  if p_damage is null or p_damage <= 0 then
    raise exception 'invalid damage amount';
  end if;

  update world_boss
    set hp_remaining = greatest(0, hp_remaining - p_damage)
    where id = 1
    returning world_boss.hp_remaining, world_boss.max_hp, world_boss.cycle_number
    into v_hp, v_max, v_cycle;

  insert into world_boss_damage (player_id, cycle_number, display_name, total_damage, updated_at)
  values (v_player_id, v_cycle, coalesce(nullif(p_display_name, ''), 'Người Chơi Ẩn Danh'), p_damage, now())
  on conflict (player_id, cycle_number)
  do update set total_damage = world_boss_damage.total_damage + excluded.total_damage,
                display_name = excluded.display_name,
                updated_at = now();

  return query select v_hp, v_max, v_cycle, (v_hp <= 0);
end;
$$;

-- Bắt đầu chu kỳ Boss mới (HP + 35% mỗi chu kỳ) — chỉ có tác dụng khi HP hiện tại
-- đã về 0, nên nhiều client gọi cùng lúc vẫn an toàn (chỉ dòng đầu tiên khớp WHERE
-- mới thực sự advance, các lần gọi sau đó là no-op).
create or replace function advance_world_boss_cycle()
returns table(cycle_number integer, max_hp numeric, hp_remaining numeric)
language plpgsql
security definer
as $$
declare
  v_cycle integer;
  v_max numeric;
  v_hp numeric;
begin
  update world_boss
    set cycle_number = cycle_number + 1,
        max_hp = round(max_hp * 1.35),
        hp_remaining = round(max_hp * 1.35),
        started_at = now()
    where id = 1 and hp_remaining <= 0
    returning world_boss.cycle_number, world_boss.max_hp, world_boss.hp_remaining
    into v_cycle, v_max, v_hp;

  if v_cycle is null then
    select world_boss.cycle_number, world_boss.max_hp, world_boss.hp_remaining
      into v_cycle, v_max, v_hp
      from world_boss where id = 1;
  end if;

  return query select v_cycle, v_max, v_hp;
end;
$$;

-- Chỉ cấp cho 'authenticated' (bao gồm cả phiên đăng nhập ẩn danh, vì Supabase gán
-- role 'authenticated' cho session đó) — không cấp cho 'anon' thuần vì auth.uid()
-- luôn null với request chưa đăng nhập, hàm sẽ tự raise exception nhưng thu hẹp
-- quyền ngay từ đầu vẫn tốt hơn.
grant execute on function deal_world_boss_damage(text, numeric) to authenticated;
grant execute on function advance_world_boss_cycle() to anon, authenticated;
