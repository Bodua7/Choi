-- Đấu Trường PvP THẬT (bất đồng bộ) — chạy sau khi đã chạy leaderboard.sql, vì đối
-- thủ được tìm bằng cách truy vấn bảng `leaderboard` có sẵn (chiến lực người chơi
-- khác tự nộp). Chạy toàn bộ file này trong Supabase Dashboard > SQL Editor > Run.
--
-- Thiết kế: đây KHÔNG phải PvP thời gian thực đồng bộ (2 người chơi cùng online đấu
-- trực tiếp) — dự án không có server game giữ kết nối 2 chiều. Thay vào đó là PvP
-- bất đồng bộ kiểu "đấu bóng ma" (ghost battle) rất phổ biến ở game idle: tấn công
-- SNAPSHOT chiến lực thật mà người chơi khác đã nộp lên `leaderboard`, không phải
-- random. Đây là hình thức PvP thật đúng nghĩa duy nhất khả thi với kiến trúc
-- serverless (Supabase) + gameplay treo máy (không đòi hỏi 2 người chơi phải mở app
-- cùng lúc).

create table if not exists arena_matches (
  id              bigserial primary key,
  attacker_id     uuid not null,
  attacker_name   text not null default 'Người Chơi Ẩn Danh',
  defender_id     uuid not null,
  defender_name   text not null default 'Người Chơi Ẩn Danh',
  attacker_cp     numeric not null,
  defender_cp     numeric not null,
  win             boolean not null, -- true = attacker thắng (defender bị đánh bại)
  created_at      timestamptz not null default now()
);

create index if not exists arena_matches_defender_idx on arena_matches (defender_id, created_at desc);
create index if not exists arena_matches_attacker_idx on arena_matches (attacker_id, created_at desc);

alter table arena_matches enable row level security;

-- Ai cũng đọc được (để mỗi người chơi thấy nhật ký "vừa bị ai thách đấu")
drop policy if exists arena_matches_read_all on arena_matches;
create policy arena_matches_read_all on arena_matches for select using (true);

-- KHÔNG cấp insert trực tiếp từ client (giống world_boss) — ghi log trận đấu phải đi
-- qua hàm record_arena_match(). Chống giả mạo: hàm KHÔNG còn nhận p_attacker_id do
-- client tự khai — attacker_id (chính mình) lấy thẳng từ auth.uid() của phiên đăng
-- nhập ẩn danh Supabase Auth thật đang gọi RPC này, nên không ai ghi khống trận đấu
-- dưới tên người khác (là attacker) được nữa. defender_id vẫn do client cung cấp vì
-- đó chỉ là đối thủ được CHỌN để tấn công (đọc từ leaderboard công khai), không phải
-- danh tính cần xác thực. Yêu cầu đã bật Anonymous Sign-Ins (xem leaderboard.sql).
drop function if exists record_arena_match(uuid, text, uuid, text, numeric, numeric, boolean);

create or replace function record_arena_match(
  p_attacker_name text,
  p_defender_id uuid,
  p_defender_name text,
  p_attacker_cp numeric,
  p_defender_cp numeric,
  p_win boolean
) returns void
language plpgsql
security definer
as $$
declare
  v_attacker_id uuid := auth.uid();
begin
  if v_attacker_id is null then
    raise exception 'auth required: chưa đăng nhập ẩn danh Supabase';
  end if;

  insert into arena_matches (
    attacker_id, attacker_name, defender_id, defender_name, attacker_cp, defender_cp, win
  ) values (
    v_attacker_id,
    coalesce(nullif(p_attacker_name, ''), 'Người Chơi Ẩn Danh'),
    p_defender_id,
    coalesce(nullif(p_defender_name, ''), 'Người Chơi Ẩn Danh'),
    p_attacker_cp,
    p_defender_cp,
    p_win
  );
end;
$$;

grant execute on function record_arena_match(text, uuid, text, numeric, numeric, boolean) to authenticated;
