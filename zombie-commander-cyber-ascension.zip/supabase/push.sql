-- Web Push subscriptions — chạy toàn bộ file này trong Supabase Dashboard
-- > SQL Editor > New query > dán vào > Run.
--
-- Bảng này CHỈ để lưu subscription (client ghi). Việc thực sự BẮN push cần 1
-- tiến trình server riêng (cron / Supabase Edge Function) dùng thư viện web-push
-- + VAPID_PRIVATE_KEY để đọc bảng này và gửi — xem
-- supabase/functions/send-push/index.ts (file mẫu, chưa deploy).

create table if not exists push_subscriptions (
  player_id  uuid not null,
  endpoint   text primary key,        -- 1 endpoint = 1 thiết bị/trình duyệt đã subscribe
  p256dh     text not null,
  auth       text not null,
  updated_at timestamptz not null default now()
);

create index if not exists push_subscriptions_player_id_idx
  on push_subscriptions (player_id);

alter table push_subscriptions enable row level security;

-- Không cho đọc công khai (đây là dữ liệu định danh thiết bị, không phải điểm số
-- công khai như leaderboard) — chỉ service role (server gửi push) mới đọc được,
-- service role tự động bỏ qua RLS nên không cần policy select riêng ở đây.

-- Người chơi chỉ được ghi/xóa subscription của CHÍNH mình (player_id phải khớp
-- auth.uid() của phiên đăng nhập ẩn danh, giống cơ chế chống giả mạo ở leaderboard.sql).
drop policy if exists push_subscriptions_insert_auth on push_subscriptions;
create policy push_subscriptions_insert_auth on push_subscriptions
  for insert with check (auth.uid() = player_id);

drop policy if exists push_subscriptions_update_auth on push_subscriptions;
create policy push_subscriptions_update_auth on push_subscriptions
  for update using (auth.uid() = player_id) with check (auth.uid() = player_id);

drop policy if exists push_subscriptions_delete_auth on push_subscriptions;
create policy push_subscriptions_delete_auth on push_subscriptions
  for delete using (auth.uid() = player_id);
