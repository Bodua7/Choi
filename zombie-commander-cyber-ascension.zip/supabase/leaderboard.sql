-- Bảng Xếp Hạng (Leaderboard) — chạy toàn bộ file này trong Supabase Dashboard
-- > SQL Editor > New query > dán vào > Run.

create table if not exists leaderboard (
  player_id      uuid primary key,
  display_name   text not null default 'Người Chơi Ẩn Danh',
  combat_power   numeric not null default 0,   -- state.getTotalAttack(), lưu numeric để chịu được BigInt lớn
  swarm_count    integer not null default 0,
  highest_cleared integer not null default 0,
  updated_at     timestamptz not null default now()
);

create index if not exists leaderboard_combat_power_idx
  on leaderboard (combat_power desc);

alter table leaderboard enable row level security;

-- Ai cũng đọc được bảng xếp hạng (công khai)
drop policy if exists leaderboard_read_all on leaderboard;
create policy leaderboard_read_all on leaderboard
  for select using (true);

-- Chống giả mạo: player_id giờ PHẢI khớp auth.uid() của phiên đăng nhập ẩn danh
-- Supabase Auth thật (client bật Anonymous Sign-Ins, xem src/net/supabaseClient.js).
-- Không còn nhận insert/update mở như bản MVP trước — người chơi chỉ có thể
-- ghi/nộp điểm cho đúng player_id của chính phiên mình, không thể ghi đè điểm
-- của người khác dù có đoán được player_id của họ.
--
-- YÊU CẦU TRƯỚC KHI CHẠY FILE NÀY: vào Supabase Dashboard > Authentication >
-- Providers > bật "Anonymous Sign-Ins". Nếu đã có dữ liệu leaderboard cũ ghi bằng
-- UUID tự sinh (bản MVP trước), các dòng đó sẽ không còn cập nhật được nữa vì
-- không ai có auth.uid() trùng — coi như dữ liệu cũ, có thể xoá thủ công nếu muốn.
drop policy if exists leaderboard_upsert_open on leaderboard;
drop policy if exists leaderboard_upsert_auth on leaderboard;
create policy leaderboard_upsert_auth on leaderboard
  for insert with check (auth.uid() = player_id);

drop policy if exists leaderboard_update_open on leaderboard;
drop policy if exists leaderboard_update_auth on leaderboard;
create policy leaderboard_update_auth on leaderboard
  for update using (auth.uid() = player_id) with check (auth.uid() = player_id);
