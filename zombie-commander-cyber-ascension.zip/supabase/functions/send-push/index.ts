// FILE MẪU — CHƯA ĐƯỢC DEPLOY. Sandbox code này không có mạng nên không thể tự
// `supabase functions deploy` giúp bạn. Đây là ví dụ đầy đủ để bạn tự deploy nếu
// muốn Web Push thật sự gửi được khi app đã đóng (không chỉ khi đang mở tab).
//
// Cách dùng:
//   1. cài Supabase CLI, `supabase login`, `supabase link` vào project của bạn
//   2. supabase secrets set VAPID_PUBLIC_KEY=... VAPID_PRIVATE_KEY=... VAPID_SUBJECT=mailto:you@example.com
//      (2 khóa này lấy từ .env — VITE_VAPID_PUBLIC_KEY là public key,
//      VAPID_PRIVATE_KEY là private key, TUYỆT ĐỐI không đưa private key vào
//      client/VITE_* vì nó sẽ lộ ra bundle JS công khai)
//   3. supabase functions deploy send-push
//   4. Gọi function này bằng cron (Supabase Dashboard > Edge Functions > Cron),
//      hoặc gọi thủ công qua HTTP POST với body { title, body, playerIds? }
//      (bỏ trống playerIds để gửi cho TẤT CẢ subscription trong bảng)
//
// Deno + npm:web-push (Supabase Edge Functions chạy Deno, hỗ trợ import npm:).
import { createClient } from 'npm:@supabase/supabase-js@2';
import webpush from 'npm:web-push@3';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!; // tự có sẵn trong môi trường Edge Function
const vapidPublicKey = Deno.env.get('VAPID_PUBLIC_KEY')!;
const vapidPrivateKey = Deno.env.get('VAPID_PRIVATE_KEY')!;
const vapidSubject = Deno.env.get('VAPID_SUBJECT') || 'mailto:example@example.com';

webpush.setVapidDetails(vapidSubject, vapidPublicKey, vapidPrivateKey);

Deno.serve(async (req) => {
    const { title, body, url, playerIds } = await req.json().catch(() => ({}));
    if (!title || !body) {
        return new Response(JSON.stringify({ error: 'Thiếu title/body' }), { status: 400 });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey);
    let query = supabase.from('push_subscriptions').select('endpoint, p256dh, auth, player_id');
    if (Array.isArray(playerIds) && playerIds.length > 0) {
        query = query.in('player_id', playerIds);
    }
    const { data: subs, error } = await query;
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });

    const payload = JSON.stringify({ title, body, url });
    const results = await Promise.allSettled((subs || []).map((sub) =>
        webpush.sendNotification(
            { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
            payload
        ).catch(async (err) => {
            // 410 Gone / 404 = subscription hết hạn hoặc người dùng đã hủy -> dọn khỏi bảng
            if (err.statusCode === 410 || err.statusCode === 404) {
                await supabase.from('push_subscriptions').delete().eq('endpoint', sub.endpoint);
            }
            throw err;
        })
    ));

    const sent = results.filter((r) => r.status === 'fulfilled').length;
    return new Response(JSON.stringify({ sent, total: results.length }), {
        headers: { 'Content-Type': 'application/json' }
    });
});
