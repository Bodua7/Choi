// main.js — GHÉP NỐI toàn bộ module logic (src/core/*, src/ui/combatLog.js) thành 1 game
// chơi được trong trình duyệt. File này KHÔNG chứa luật chơi mới — chỉ điều phối các hàm
// thuần (pure function) đã có sẵn trong 20 module gốc.
//
// GHI CHÚ QUAN TRỌNG — các chỗ GIẢ ĐỊNH THÊM (vì các module gốc chưa có, cần bạn xác nhận):
//   1. Không có hệ EXP/lên cấp — dùng tạm "số quái đã hạ" (killCount), cần level*10 con để
//      lên 1 cấp. Đổi hằng số EXP_PER_LEVEL bên dưới nếu muốn tốc độ khác.
//   2. Không có chỉ số HP/DEF của quái theo tier — sinh tạm bằng generateEnemyStats() dựa
//      trên level người chơi + hệ số nhân theo tier D-C/B-A/S/SSS.
//   3. [ĐÃ VÁ — xem VÁ #24 cuối file] Không có hệ Nhiệm Vụ thật (evolutionTiers.js chỉ có
//      TÊN nhiệm vụ dạng chuỗi, không mô tả nội dung). TRƯỚC ĐÂY: completedQuests coi là
//      "đã xong" ngay khi đủ level, khiến nhiệm vụ chỉ là hư danh. GIỜ: phải hạ đủ 10 trận
//      (Càn Quét/Boss/Ulti) kể từ lúc đủ level mới được tính hoàn thành — vẫn là GIẢ ĐỊNH
//      (số 10 tự chọn, GDD không cho cụ thể) nhưng đòi hỏi cày thật thay vì tự động.
//   4. "Vũ Khí" dùng để demo nút Cường Hóa là 1 vật phẩm tượng trưng, TÁCH RIÊNG khỏi
//      Trang Bị 5-slot thật (mục 5) — vì enhancement.js thao tác trên 1 cấp độ đơn lẻ,
//      không biết về item cụ thể nào.
//   5. Trang Bị/Chế Tạo: recipes.js dùng TÊN nguyên liệu riêng (vd "Lõi Năng Lượng") không
//      trùng với tên vật liệu materials.js rớt ra từ combat (đã ghi chú ngay trong
//      recipes.js gốc — đây là khoảng trống thật của thiết kế, không phải lỗi của tôi).
//      Để chế tạo THỰC SỰ chơi được, khi thắng trận có thêm 1 tỉ lệ nhỏ rớt nguyên liệu
//      công thức (lấy đúng tên trong RECIPES của nhân vật đó, chỉ công thức 'normal',
//      không rớt nguyên liệu công thức 'divine' để giữ độ hiếm). Mỗi công thức cũng được
//      gán tạm 1 slot trang bị + 1 rarityTier (normal=1 Xanh, divine=3 Vàng) qua
//      RECIPE_SLOT_MAP/RECIPE_RARITY bên dưới — equipmentSlots.js/recipes.js gốc không tự
//      định nghĩa 2 việc này.
//   6. Lưu game: dùng localStorage (không có trong module gốc) — tự động lưu mỗi 15s +
//      khi rời trang, tự tải lại khi mở app.
//   7. Danh Vọng: chưa có hàm nào trong factionsReputation.js tự cộng điểm khi chiến đấu —
//      gán tạm CHARACTER_FACTION_MAP (mỗi Main gắn 1 phe theo đúng chủ đề branch của họ:
//      A Tun/Cơ Khí -> Công Xưởng Cơ Giới, Bao/Công Nghệ -> Liên Minh Sinh Tồn, Hàn Lập/Tiên
//      Hiệp -> Tu Tiên Giới Bản Địa) rồi cộng điểm mỗi khi thắng trận.
//   8. Trọng Sinh: "Chân Ngôn Luân Hồi Kính" (vật phẩm tiêu hao) không có nguồn rớt nào —
//      tự cấp 1 cái miễn phí ngay khi isStoryComplete() lần đầu true (hoàn thành Chương V),
//      log rõ ràng để bạn biết đây là glue, không phải cơ chế GDD gốc.
//      (Đã kiểm tra: điều kiện này được TÍNH LẠI mỗi lần lên cấp, không phải cờ 1-lần —
//      nên sau khi Trọng Sinh, đi lại hết Chương V lần nữa vẫn tự cấp thêm 1 cái. Không cần
//      vá thêm, chỉ hơi cày lại toàn bộ mỗi lần.)
//
// GHI CHÚ CHỐT (đề xuất mục 3 — vòng kiểm sâu sau VÁ #23): các GIẢ ĐỊNH glue rải rác trong
// file này (Chợ Đen #13, công thức Tốc Độ Rớt Đồ #14b, tốc độ EXP #1/#18, chi phí Căn Cứ #11,
// chi phí Ulti #15b, v.v.) được xem là ĐÃ CHỐT ở giá trị hiện tại — không phải vì đã xác nhận
// đúng GDD gốc, mà vì không có thêm tài liệu GDD chi tiết hơn để đối chiếu, và toàn bộ đã được
// kiểm chứng qua 50 vòng kiểm sâu (deep-check.mjs) là chơi được trọn vẹn end-to-end (lên
// Lv100 → Đột phá đủ 5 mốc → Boss/Ulti → Trọng Sinh) không khóa cứng. Nếu về sau có bản GDD
// đầy đủ hơn cho các phần này, chỉ cần sửa đúng hằng số/bảng liên quan — không cần đổi kiến
// trúc.
//
// GHI CHÚ VÁ (lượt sau, sau khi rà lại code cùng bạn):
//   9. BUG THẬT: nguyên liệu của MỌI công thức 'divine' (vd "Linh Đá Cao Cấp", "Thần Thiết
//      Cơ Giáp", "Lõi Hạt Nhân"...) không trùng tên với bất kỳ nguồn rớt nào — kể cả glue
//      #5 (chỉ áp cho recipe 'normal'). Nghĩa là 3 trang bị divine + cả 3 nguyên liệu combo
//      Tuyệt Kỹ (Chân Ngôn Bảo Luân, Chiến Hạm Phân Rã, Pháo Plasma Hạt Nhân) KHÔNG THỂ chế
//      tạo được trong toàn bản build gốc. ĐÃ VÁ: doBossFight() thắng có 50% rớt 1 nguyên
//      liệu divine ngẫu nhiên của nhân vật đang chơi; doUltimateCombo() thắng đảm bảo rớt
//      thêm 1 (kèm 3 Tinh Thể Biến Dị + 100 danh vọng, trước đây Ultimate Combo thắng không
//      có phần thưởng gì cả).
//   10. Đã kiểm tra RECIPE_RARITY: KHÔNG phải lỗ hổng — đã được gán vào item.rarityTier lúc
//      craft (dòng ~307), dùng đúng bởi rebirthPrestige.js để quyết định giữ đồ Trọng Sinh.
//   11. BUG THẬT: module baseExpansion.js (TAB4.2 — Căn Cứ: Trận Pháp Hộ Thành/Tháp Súng
//      Canh Gác/Xưởng Phân Rã) KHÔNG được import ở đâu cả trong build gốc. "Căn Cứ" chỉ là
//      state.base = {} rỗng vĩnh viễn, trận pháp đêm hardcode cấp 3, turret không tồn tại,
//      không thể tái chế đồ. ĐÃ VÁ: thêm state.baseLevels (3 công trình, cấp 0-10, nâng
//      bằng Phế Liệu Sắt qua doUpgradeBase() + panel "Căn Cứ" mới trong index.html) —
//      autoNightDefense() giờ đọc cấp Trận Pháp Hộ Thành thật (mitigation + giáp ảo cộng
//      dồn), Tháp Súng Canh Gác giảm số quái mỗi wave theo getTurretShotsFired(), và
//      doRecycleSlot() dùng Xưởng Phân Rã để hoàn 70% nguyên liệu khi gỡ đồ. baseLevels
//      được lưu/tải cùng save game và reset về 0 khi Trọng Sinh (khớp với log cũ vốn đã
//      tuyên bố "Căn Cứ đã reset" dù trước đó chẳng có gì để reset thật).
//   12. Tên quái (ENEMY_CODEX/getEnemiesForTier) chưa từng được gọi — log chiến đấu chỉ in
//      số dmg suông, không nói đang đánh con gì. ĐÃ VÁ: thêm CHARACTER_ENEMY_BRANCH_MAP +
//      getEnemyName(), log tên quái thật khi Càn Quét/Boss/Ultimate Combo.
//   13. BUG THẬT NGHIÊM TRỌNG: "Lõi Đồng Hóa" — currency bắt buộc 3 đơn vị để đột phá Mốc 5
//      Tối Thượng (evolutionTiers.js BREAKTHROUGH_REQUIREMENTS[4]) — KHÔNG có bất kỳ nguồn
//      rớt nào trong toàn build gốc. Vì Ultimate Combo + isStoryComplete() + Trọng Sinh đều
//      yêu cầu tier.order >= 4, bug này chặn cứng TOÀN BỘ endgame. ĐÃ VÁ: Boss SSS thắng có
//      15% rớt 1 Lõi Đồng Hóa.
//      Đồng thời dựng Chợ Đen (GDD chỉ nhắc tên "mở khi 1 phe đạt Huyền Thoại", không định
//      nghĩa bán gì) — nội dung BLACK_MARKET_ITEMS là GIẢ ĐỊNH tự soạn, dùng Lõi Đồng Hóa
//      làm tiền tệ giao dịch, đổi Chân Ngôn Luân Hồi Kính + nguyên liệu divine. Đổi lại nếu
//      bạn có nội dung cụ thể hơn từ GDD gốc.
//   14. Rà lượt 3 (so khớp mọi export chưa từng được gọi), 3 BUG THẬT:
//      a) Trạm Radar Trinh Sát (idleLoot.js: dropMaterialWithRadar/getGoldDropChance) tồn
//         tại sẵn nhưng doScavenge() gọi cứng radarLevel=0, không có công trình Căn Cứ nào
//         để nâng cấp. ĐÃ VÁ: thêm BASE_STRUCTURES.TRAM_RADAR_TRINH_SAT (baseExpansion.js),
//         nâng cấp qua doUpgradeBase() sẵn có (data-driven, tự có UI/nút), doScavenge() đọc
//         state.baseLevels.TRAM_RADAR_TRINH_SAT thật thay vì hardcode 0.
//      b) rebirthPrestige.js hứa TAB12 áp buff Trọng Sinh lên 4 thứ (chỉ số gốc/sát thương/
//         tốc độ rớt đồ/độ bền Căn cứ) qua applyRebirthBuff() nhưng hàm này chưa từng được
//         gọi — chỉ chỉ số gốc/sát thương được buff (qua mult trong getActiveStats()). ĐÃ
//         VÁ: doScavenge() gọi applyRebirthBuff() để tính % cơ hội rớt thêm 1 đơn vị vật
//         liệu (GIẢ ĐỊNH, xem chú thích tại chỗ vì GDD không cho công thức "tốc độ" cụ
//         thể); autoNightDefense() gọi applyRebirthBuff() để buff baseHp theo đúng số lần
//         Trọng Sinh thay vì hardcode 500+level*20 không đổi.
//      c) gameLoop.js tự mô tả rõ Ngày (15p) = Càn Quét/Đào Quặng, Đêm (5p) = Thủ Thành,
//         và có sẵn isDayPhase() đúng mục đích ("dùng để bật Đánh Thường/loot") nhưng chưa
//         từng được gọi — nút Càn Quét chơi được 24/7, không có nhịp Ngày/Đêm nào cả. ĐÃ
//         VÁ: doScavenge() chặn + báo log nếu gọi lúc Ban Đêm, nút btn-scavenge tự disable
//         khi isNightPhase() (khớp cách btn-boss/btn-ulti đã tự disable theo mốc).
//      d) Nhỏ: logPlayerCommand() (combatLog.js) viết sẵn nhưng chưa từng được gọi — chỉ
//         thiếu 1 dòng flavor "Lệnh: ..." khi bấm nút, không ảnh hưởng số liệu/kết quả
//         gameplay. ĐÃ VÁ: gọi ở đầu 6 hành động thủ công chính (Càn Quét/Boss/Ulti/
//         Cường Hóa/Đột Phá/Trọng Sinh).
//   15. Rà lượt 4 (so khớp export chưa gọi kể cả nội bộ giữa các module, không chỉ main.js),
//      2 gap thật thêm:
//      a) baseSupport.js: "Rào Chắn Bọc Thép Sát Độc" (owner A_Tun) mô tả tự động gom vật
//         liệu rớt sau mỗi wave Thú Triều (autoCollectFromWave()) nhưng chưa từng được gọi
//         — và runHordeDefense() (combat.js) còn không sinh dữ liệu rớt đồ cho wave nào cả,
//         khiến Thủ Thành là hành động DUY NHẤT không có phần thưởng vật chất (chỉ +8 danh
//         vọng nếu sống sót). ĐÃ VÁ: autoNightDefense() giờ sinh 1 vật liệu/wave đã xử lý
//         (dùng chung branch nhân vật đang hoạt động + cấp Trạm Radar hiện tại), gộp qua
//         autoCollectFromWave() rồi cộng vào kho — GIẢ ĐỊNH công thức số lượng vì GDD không
//         cho cụ thể, cần bạn xác nhận/chỉnh lại.
//      b) baseSupport.js: canCastUltiFree() mô tả Lò Năng Lượng Tổng miễn phí mana cá nhân
//         khi tung Ulti nếu còn Lõi Năng Lượng — nhưng hàm chưa từng được gọi, và trước đó
//         Combo Tuyệt Kỹ hoàn toàn KHÔNG có chi phí mana/năng lượng nào ở bất kỳ đâu (khác
//         các gap khác, đây không phải "quên nối" mà là "hệ thống chưa từng tồn tại"). ĐÃ
//         VÁ (GIẢ ĐỊNH tự soạn hoàn toàn, bắt buộc cần bạn xác nhận): gán chi phí 1 Tinh Thể
//         Biến Dị/lần tung Ulti; thêm công trình Căn Cứ mới LO_NANG_LUONG_TONG
//         (baseExpansion.js, xây 1 lần qua doUpgradeBase() có sẵn) miễn hẳn chi phí này.
//   16. Rà lượt 5 (so khớp export chưa gọi + toàn bộ id trong index.html), không còn bug
//      chức năng nào — chỉ còn 2 chỗ polish UI (không phải bug logic):
//      a) materials.js có TIER_COLORS (Trắng/Xanh/Tím/Vàng) nhưng thanh Vật Liệu trước đây
//         hiện mọi vật liệu cùng 1 màu, không phân biệt độ hiếm như Trang Bị đã làm. ĐÃ VÁ:
//         dựng MATERIAL_TIER_INDEX (tra tên -> tier) 1 lần, gắn class .mat-tier0..3 (màu
//         theo style.css) vào từng chip Vật Liệu.
//      b) factionsReputation.js có getNextReputationTier() nhưng UI chỉ hiện bậc Danh Vọng
//         hiện tại, không hiện còn thiếu bao nhiêu điểm tới bậc kế tiếp. ĐÃ VÁ: chip Danh
//         Vọng giờ hiện thêm "(còn X tới <bậc kế>)" hoặc "(Tối đa)" nếu đã Huyền Thoại.

import { CHARACTER_IDS, getCharacter } from './core/content/characters.js';
import { getStatsAtLevel, calcDamage } from './core/combatMath.js';
import {
    getTierForLevel,
    BREAKTHROUGH_MATERIAL_BRANCH,
    EVOLUTION_TIERS, getBreakthroughRequirement
} from './core/content/evolutionTiers.js';
import { normalScavenge, runHordeDefense, runBossFight } from './core/combat.js';
import { runUltimateCombo } from './core/ultimateCombo.js';
import { createWallet, addCurrency, canAfford, spendCurrency, CURRENCIES } from './core/currencies.js';
import { dropMaterialWithRadar, getGoldDropChance } from './core/idleLoot.js';
import { getMaterialName, MATERIAL_BRANCHES, TIER_COLORS } from './core/content/materials.js';
import { attemptEnhance, MAX_ENHANCE_LEVEL } from './core/enhancement.js';
import { getTranPhapMitigation, getTurretShotsFired, autoCollectFromWave, canCastUltiFree } from './core/baseSupport.js';
import {
    createLoopState, tickGameLoop, isNightPhase, isDayPhase, getRemainingInPhase, getPhaseProgress, PHASES
} from './core/gameLoop.js';
import { BASE_STRUCTURES, recycleItem, getVirtualShieldBonus, isTurretActive } from './core/baseExpansion.js';
import { TIER_ORDER, ENEMY_CODEX, getEnemiesForTier } from './core/content/enemyCodex.js';
import { STORY_CHAPTERS } from './core/content/story.js';
import {
    FACTION_IDS, FACTIONS, createReputationState, getReputationTier, getNextReputationTier, addReputation, hasBlackMarketAccess
} from './core/content/factionsReputation.js';
import { canRebirth, performRebirth, getRebirthBuffMultiplier, applyRebirthBuff } from './core/rebirthPrestige.js';
import { EQUIPMENT_SLOTS, createEmptyLoadout, equip, unequip } from './core/content/equipmentSlots.js';
import { RECIPES, getRecipesFor, canCraft, craft } from './core/content/recipes.js';
import { SKILL_TREE } from './core/content/skillTree.js';
import {
    createLogBuffer, pushLog, renderAsLines,
    logNormalScavenge, logHordeDefense, logBossFight, logUltimateCombo, logLootCollected, logPlayerCommand
} from './ui/combatLog.js';

// GIẢ ĐỊNH glue (xem ghi chú #7)
const CHARACTER_FACTION_MAP = {
    A_TUN: 'CONG_XUONG_CO_GIOI_TU_DO',
    BAO: 'LIEN_MINH_SINH_TON',
    HAN_LAP: 'TU_TIEN_GIOI_BAN_DIA'
};

// GIẢ ĐỊNH glue (xem ghi chú #5): map mỗi công thức -> đúng 1 slot trang bị + rarityTier
const RECIPE_SLOT_MAP = {
    A_TUN_CUA_XOAY_TITANIUM: 'Vũ Khí Càn Quét',
    A_TUN_PHAO_LASER_PHAN_RA: 'Lõi Sát Độc',
    A_TUN_CHIEN_HAM_LOI_CO_KHI: 'Khung Xe/Mạn Giáp',
    BAO_SUNG_TIEU_LIEN_XUNG_DIEN: 'Vũ Khí Chính',
    BAO_PHAO_PLASMA_HAT_NHAN: 'Thiết Bị EMP',
    BAO_BO_GIAP_BA_CHU_VO_CUC: 'Giáp Exo-Suit',
    HAN_LAP_THANH_CHUC_KIEM: 'Tráp Kiếm',
    HAN_LAP_HU_THIEN_DINH: 'Cổ Bảo/Trấn Bảo',
    HAN_LAP_CHAN_NGON_BAO_LUAN: 'Pháp Bảo Thời Gian'
};
const RECIPE_RARITY = { normal: 1, divine: 3 }; // 0 Trắng..3 Vàng (thang materials.js)
const SAVE_KEY = 'tam-gioi-tan-the-save-v1';

// VÁ (mục #16): materials.js có sẵn TIER_COLORS (['Trắng','Xanh','Tím','Vàng']) để phân biệt
// độ hiếm vật liệu nhưng chưa từng được gắn vào UI — thanh Vật Liệu trước đây chỉ hiện
// "tên: số lượng" đơn sắc, không phân biệt màu tier như Trang Bị đã làm. Dựng bảng tra
// tên vật liệu -> chỉ số tier (0-3) 1 lần từ MATERIAL_BRANCHES để tô màu chip theo tier.
const MATERIAL_TIER_INDEX = {};
for (const branch of Object.values(MATERIAL_BRANCHES)) {
    branch.tiers.forEach((name, idx) => { MATERIAL_TIER_INDEX[name] = idx; });
}

// VÁ (mục #12): map nhân vật -> nhánh trong ENEMY_CODEX, để log chiến đấu gọi đúng tên quái
// theo GDD thay vì chỉ in số dmg suông. Dùng đúng logic nhánh như CHARACTER_FACTION_MAP.
const CHARACTER_ENEMY_BRANCH_MAP = {
    A_TUN: 'SAT_DOC_CO_KHI',
    BAO: 'ZOMBIE_TAN_THE',
    HAN_LAP: 'PHAM_NHAN_TU_TIEN'
};
function getEnemyName(charId, tierKey) {
    const branch = CHARACTER_ENEMY_BRANCH_MAP[charId];
    const entry = getEnemiesForTier(tierKey);
    return entry[branch] || 'Kẻ thù vô danh';
}

// VÁ (mục #13): Chợ Đen — GDD chỉ nhắc tên (mở khi 1 phe đạt Huyền Thoại) nhưng không định
// nghĩa nội dung bán gì, nên đây là GIẢ ĐỊNH glue tự soạn, dùng Lõi Đồng Hóa (currency hiếm
// nhất, sẵn có vai trò "Trọng Sinh + đột phá mốc 5" trong currencies.js) làm tiền tệ giao
// dịch. Đổi lại BLACK_MARKET_ITEMS nếu bạn có nội dung cụ thể hơn từ GDD.
const BLACK_MARKET_ITEMS = [
    {
        id: 'BM_DIVINE_MAT_BUNDLE',
        name: 'Túi Nguyên Liệu Divine',
        desc: '+2 đơn vị nguyên liệu ngẫu nhiên của 1 công thức [THẦN CẤP] thuộc nhân vật đang chơi.',
        cost: { LOI_DONG_HOA: 2 },
        effect: (charId) => {
            const divineRecipes = getRecipesFor(charId).filter(r => r.grade === 'divine');
            if (divineRecipes.length === 0) return {};
            const recipe = divineRecipes[Math.floor(Math.random() * divineRecipes.length)];
            const ingredientNames = Object.keys(recipe.ingredients);
            const matName = ingredientNames[Math.floor(Math.random() * ingredientNames.length)];
            state.materials[matName] = (state.materials[matName] || 0) + 2;
            return { [matName]: 2 };
        }
    },
    {
        id: 'BM_TINH_THE_BIEN_DI',
        name: 'Tinh Thể Biến Dị (đổi Phế Liệu Sắt)',
        desc: '+1 Tinh Thể Biến Dị — nguồn độc lập với Boss SSS, dùng Phế Liệu Sắt (rớt đều từ Càn Quét).',
        cost: { PHE_LIEU_SAT: 500 },
        effect: () => {
            addCurrency(state.wallet, 'TINH_THE_BIEN_DI', 1);
            return {};
        }
    },
    {
        id: 'BM_LUAN_HOI_KINH',
        name: 'Chân Ngôn Luân Hồi Kính',
        desc: '+1 Chân Ngôn Luân Hồi Kính — nguồn phụ, không cần cày lại toàn bộ Chương V mỗi lần Trọng Sinh.',
        cost: { LOI_DONG_HOA: 5 },
        effect: () => {
            state.luanHoiKinhCount = (state.luanHoiKinhCount || 0) + 1;
            return {};
        }
    }
];

// VÁ (mục #11): nối module baseExpansion.js (TAB4.2 — trước đây import ở đâu cả, "Căn Cứ"
// chỉ là object rỗng {} không làm gì). 3 công trình, mỗi công trình max cấp 10, dùng Phế
// Liệu Sắt (currency nền tảng) để nâng cấp — GIẢ ĐỊNH chi phí vì GDD không cho số cụ thể.
const MAX_BASE_STRUCTURE_LEVEL = 10;
const BASE_UPGRADE_COST_PER_LEVEL = 150; // Phế Liệu Sắt, chi phí = (cấp hiện tại + 1) × số này

// ---------------------------------------------------------------------------
// STATE
// ---------------------------------------------------------------------------
// VÁ #18: mô phỏng thật cho thấy `level * 10` đòi hỏi CHÍNH XÁC 49.500 lần Càn Quét thắng/nhân
// vật để lên Lv100 (= 10 * Σ 1..99), tức 148.500 lần bấm tay cho 3 nhân vật — không có
// auto-farm nào bù lại (Càn Quét là hành động thủ công duy nhất tạo killCount). Hạ độ dốc
// xuống còn khoảng 1/18 (Σ (3 + floor(level/2)), 1..99 ≈ 2.747 quái/nhân vật ≈ 8.241 tổng 3
// nhân vật) — vẫn giữ đường cong tăng dần theo cấp (đúng cảm giác GDD "cấp sau cần cày nhiều
// hơn cấp trước"), chỉ giảm độ dốc để chơi tay vẫn khả thi. Đổi hằng số nếu muốn tốc độ khác.
const EXP_PER_LEVEL = (level) => 3 + Math.floor(level / 2); // GIẢ ĐỊNH glue — xem ghi chú #1 ở đầu file

const state = {
    activeChar: 'A_TUN',
    charLevels: { A_TUN: 1, BAO: 1, HAN_LAP: 1 },
    killCounts: { A_TUN: 0, BAO: 0, HAN_LAP: 0 },
    wallet: createWallet(),
    materials: {},              // tên vật liệu -> số lượng
    weaponEnhanceLevel: 0,      // GIẢ ĐỊNH glue — xem ghi chú #4
    reputation: createReputationState(),
    loopState: createLoopState(),
    logBuffer: createLogBuffer(120),
    completedQuests: new Set(), // VÁ #24 — giờ chỉ ghi khi ĐÃ đủ questProgress, xem hàm advanceQuestProgress()
    questProgress: {},          // VÁ #24 — questName -> số trận thắng tích lũy khi đủ level cho quest đó
    // VÁ #17 (xem ghi chú tại getActiveStats()): mốc đột phá order cao nhất ĐÃ đột phá thành
    // công theo từng nhân vật. 0 = mốc khởi đầu, không cần đột phá. Trước đây KHÔNG có state
    // này ở đâu cả — tier hiển thị/dùng để gate nội dung suy thẳng từ level, khiến nút Đột Phá
    // không gate được gì.
    breakthroughTiers: { A_TUN: 0, BAO: 0, HAN_LAP: 0 },
    rebirthCount: 0,
    luanHoiKinhCount: 0,
    baseLevels: { TRAN_PHAP_HO_THANH: 0, TURRET_CANH_GAC: 0, XUONG_PHAN_RA_TAI_CHE: 0, TRAM_RADAR_TRINH_SAT: 0, LO_NANG_LUONG_TONG: 0 }, // VÁ #11, #14, #15
    loadouts: {
        A_TUN: createEmptyLoadout('A_TUN'),
        BAO: createEmptyLoadout('BAO'),
        HAN_LAP: createEmptyLoadout('HAN_LAP')
    },
};

function log(type, text) {
    pushLog(state.logBuffer, type, text);
}

log('system', 'Tam Giới Tận Thế — kết nối hệ thống hoàn tất. 3 Main đã sẵn sàng.');

// ---------------------------------------------------------------------------
// GLUE: sinh chỉ số quái tạm thời theo level người chơi (xem ghi chú #2)
// ---------------------------------------------------------------------------
const TIER_ENEMY_MULTIPLIER = { D_C: 1, B_A: 3, S: 8, SSS: 20 };

function evolutionOrderToEnemyTier(order) {
    if (order <= 0) return 'D_C';
    if (order === 1) return 'B_A';
    if (order === 2) return 'S';
    return 'SSS';
}

function generateEnemyStats(level, tierKey) {
    const mult = TIER_ENEMY_MULTIPLIER[tierKey] ?? 1;
    return {
        hp: Math.round(40 * level * mult),
        def: Math.round(3 * level * mult * 0.4),
        // VÁ #18: quái trước đây không có ATK — không thể đánh trả, nên Càn Quét chỉ có 1
        // chiều "người chơi đánh quái", không có cách nào để quái khiến người chơi thua thật.
        // GIẢ ĐỊNH tỉ lệ (GDD không cho công thức riêng): cùng bậc độ lớn với DEF phía trên.
        atk: Math.round(1.5 * level * mult),
        resist: tierKey === 'SSS' ? 0.15 : 0
    };
}

// VÁ #18: BUG THẬT — normalScavenge() (combat.js) định nghĩa thắng = `dmg > 0`. Vì ATK người
// chơi luôn dương (không nhân vật nào có ATK = 0), điều kiện này LUÔN đúng — Càn Quét thắng
// 100% bất kể HP/DEF quái, khiến 2 chỉ số đó chỉ là số trang trí. Hệ quả: buff Trọng Sinh
// (chỉ số gốc/sát thương, applyRebirthBuff) không hề ảnh hưởng đến việc cày level — chỉ có
// tác dụng thật ở Boss SSS/Ultimate Combo (nơi runBossFight/runUltimateCombo đã có ngưỡng
// thắng/thua thật từ đầu). ĐÃ VÁ: mô phỏng trao đổi đòn 2 chiều ở main.js — không sửa
// combat.js (vẫn gọi normalScavenge() để tính damagePerHit/hitsToKill của người chơi y hệt
// công thức cũ), chỉ thêm quái đánh trả mỗi lượt bằng ATK mới ở trên. Thua nếu HP người chơi
// về 0 trước khi hạ được quái — win/lose giờ phụ thuộc thật vào HP/DEF quái (và ATK quái mới).
function runScavengeExchange(playerStats, enemy) {
    const atkResult = normalScavenge(
        { atk: playerStats.atk ?? 20, armorPen: 0, critDamage: playerStats.crit ?? 0 },
        enemy
    );
    const playerDef = playerStats.def ?? 0;
    const enemyDmgPerHit = calcDamage(enemy.atk, playerDef);
    const DAMAGE_VARIANCE = 0.20; // VÁ #23: ±20% biến động mỗi đòn, xem ghi chú trên
    const withVariance = (base) => base * (1 + (Math.random() * 2 - 1) * DAMAGE_VARIANCE);
    let enemyHp = enemy.hp;
    let playerHp = playerStats.hp ?? 1;
    let rounds = 0;
    while (enemyHp > 0 && playerHp > 0 && rounds < 500) {
        enemyHp -= withVariance(atkResult.damagePerHit);
        rounds++;
        if (enemyHp > 0) playerHp -= withVariance(enemyDmgPerHit);
    }
    return {
        win: enemyHp <= 0 && playerHp > 0,
        damagePerHit: atkResult.damagePerHit,
        hitsToKill: atkResult.hitsToKill,
        enemyDamagePerHit: enemyDmgPerHit,
        roundsSurvived: rounds,
        playerHpRemaining: Math.max(0, Math.round(playerHp)),
        enemyHpRemaining: Math.max(0, Math.round(enemyHp))
    };
}

// ---------------------------------------------------------------------------
// HÀNH ĐỘNG NGƯỜI CHƠI
// ---------------------------------------------------------------------------
// VÁ #19: BUG THẬT (phát hiện ở vòng rà sâu sau VÁ #17/#18) — story.js (getUnlockedChapter/
// getNextChapter/isStoryComplete) và skillTree.js (getUnlockedSkills) đều TỰ gọi lại
// getTierForLevel(level) bên trong, hoàn toàn độc lập với state.breakthroughTiers mới thêm ở
// VÁ #17. Hậu quả nghiêm trọng nhất: checkLevelUp() gọi isStoryComplete(state.charLevels) để
// quyết định có cấp "Chân Ngôn Luân Hồi Kính" (vật phẩm bắt buộc để Trọng Sinh) hay không — đã
// XÁC NHẬN BẰNG MÔ PHỎNG THẬT: 3 nhân vật lên Lv85+ mà CHƯA từng bấm Đột Phá lần nào vẫn khiến
// isStoryComplete() trả về true, tức người chơi vẫn nhận được vật phẩm Trọng Sinh và đủ điều
// kiện Trọng Sinh — y hệt lỗ hổng VÁ #17 nhưng đi vòng qua story.js, vô hiệu hóa gate vừa vá.
// Skill Tree bị nhẹ hơn (chỉ hiện sai danh sách kỹ năng đã mở, không phải exploit tiến trình)
// nhưng cùng gốc. ĐÃ VÁ: 2 hàm cục bộ dưới đây tính "mốc hiệu lực" (effective tier order) của
// TỪNG nhân vật/toàn đội bằng đúng công thức min(mốc-theo-level, mốc-đã-đột-phá) như
// getActiveStats(), rồi dùng trực tiếp STORY_CHAPTERS/SKILL_TREE (dữ liệu, không phải hàm suy
// từ level) — không sửa story.js/skillTree.js (giữ nguyên core, chỉ thêm glue ở main.js).
function getEffectiveTierOrderFor(charId) {
    const level = state.charLevels[charId];
    const levelOrder = getTierForLevel(charId, level).order;
    const unlockedOrder = state.breakthroughTiers[charId] ?? 0;
    return Math.min(levelOrder, unlockedOrder);
}

function getUnlockedChapterEffective() {
    const minOrder = Math.min(...CHARACTER_IDS.map(getEffectiveTierOrderFor));
    let unlocked = STORY_CHAPTERS[0];
    for (const chapter of STORY_CHAPTERS) {
        if (minOrder >= chapter.requiredTierOrder) unlocked = chapter;
    }
    return unlocked;
}

function getNextChapterEffective() {
    const current = getUnlockedChapterEffective();
    return STORY_CHAPTERS.find(c => c.order === current.order + 1) || null;
}

function isStoryCompleteEffective() {
    return getUnlockedChapterEffective().order === STORY_CHAPTERS[STORY_CHAPTERS.length - 1].order;
}

function getUnlockedSkillsEffective(charId) {
    const order = getEffectiveTierOrderFor(charId);
    return SKILL_TREE[charId].filter(t => t.order <= order).flatMap(t => t.skills);
}

function getActiveStats() {
    const level = state.charLevels[state.activeChar];
    const rawStats = getStatsAtLevel(state.activeChar, level);
    const mult = getRebirthBuffMultiplier(state.rebirthCount); // GIẢ ĐỊNH glue: áp buff Trọng Sinh lên chỉ số gốc (trừ crit, vốn là tỉ lệ)
    const stats = {};
    for (const [k, v] of Object.entries(rawStats)) stats[k] = k === 'crit' ? v : v * mult;
    // VÁ #17: BUG THẬT NGHIÊM TRỌNG — trước đây `tier: getTierForLevel(state.activeChar, level)`
    // lấy Mốc Tiến Hóa THUẦN theo level, không hề đọc trạng thái "đã đột phá" nào cả (vì trạng
    // thái đó không tồn tại — xem VÁ #17 ở khai báo state.breakthroughTiers). Hệ quả: người
    // chơi lên Lv21/41/61/81 là tự động có tier mới (mở quái mạnh hơn ở Càn Quét, Boss SSS ở
    // Lv61+, Ulti ở Lv81+) dù CHƯA TỪNG bấm Đột Phá / chưa từng đủ nguyên liệu — nút Đột Phá
    // (doBreakthrough) chỉ trừ nguyên liệu + in log, không gate gì. Toàn bộ TAB7.2 (nguyên
    // liệu đột phá) vô nghĩa về gameplay. ĐÃ VÁ: tier thật = giao giữa "mốc level cho phép tối
    // đa" và "mốc đã đột phá" — không bao giờ tự vượt quá mốc đã đột phá, dù đủ level.
    const levelTierOrder = getTierForLevel(state.activeChar, level).order;
    const unlockedOrder = state.breakthroughTiers[state.activeChar] ?? 0;
    const effectiveOrder = Math.min(levelTierOrder, unlockedOrder);
    const tier = EVOLUTION_TIERS[state.activeChar][effectiveOrder];
    return { level, stats, tier };
}

// VÁ #24: thay "Nhiệm Vụ Thử Thách" (evolutionTiers.js req.quest, dùng để gate Đột Phá) từ
// auto-complete tức thì (GIẢ ĐỊNH #3 cũ — coi như xong ngay khi đủ level, khiến "nhiệm vụ"
// chỉ là hư danh) sang một điều kiện THẬT SỰ phải cày để đạt: hạ đủ QUEST_TARGET_WINS trận
// (Càn Quét/Boss/Ultimate Combo, tính từ lúc đủ level cho mốc đó) mới được đánh dấu hoàn
// thành. Đây vẫn là GIẢ ĐỊNH (evolutionTiers.js gốc chỉ có TÊN nhiệm vụ dạng chuỗi, không mô
// tả nội dung/số lượng cụ thể phải làm gì — không có hệ Nhiệm Vụ thật nào được cấp), nhưng
// khác GIẢ ĐỊNH cũ ở chỗ giờ đòi hỏi hành động thật lặp lại thay vì tự động hoàn thành ngay
// khi bấm nút, đúng tinh thần "thử thách" hơn.
const QUEST_TARGET_WINS = 10;

function advanceQuestProgress(charId) {
    const level = state.charLevels[charId];
    const unlockedOrder = state.breakthroughTiers[charId] ?? 0;
    const targetOrder = unlockedOrder + 1;
    const targetTierExists = EVOLUTION_TIERS[charId].some(t => t.order === targetOrder);
    if (!targetTierExists) return; // đã ở mốc tối đa, không còn nhiệm vụ nào để cày
    const req = getBreakthroughRequirement(charId, targetOrder);
    if (!req || level < req.requiredLevel) return; // chưa đủ level thì trận thắng này không tính
    if (state.completedQuests.has(req.quest)) return; // đã xong rồi, không cần đếm thêm

    const current = (state.questProgress[req.quest] ?? 0) + 1;
    state.questProgress[req.quest] = current;
    if (current >= QUEST_TARGET_WINS) {
        state.completedQuests.add(req.quest);
        log('effect', `📜 Nhiệm vụ hoàn thành: ${req.quest}! Đủ điều kiện Đột Phá (nếu đã đủ nguyên liệu).`);
    }
}

function checkLevelUp(charId) {
    const level = state.charLevels[charId];
    if (level >= 100) return;
    const needed = EXP_PER_LEVEL(level);
    if (state.killCounts[charId] >= needed) {
        state.killCounts[charId] -= needed;
        state.charLevels[charId] = Math.min(100, level + 1);
        log('effect', `${getCharacter(charId).name} lên cấp ${state.charLevels[charId]}!`);
        if (isStoryCompleteEffective() && state.luanHoiKinhCount < 1) { // VÁ #19
            state.luanHoiKinhCount = 1; // GIẢ ĐỊNH glue — xem ghi chú #8
            log('effect', '🌀 Cốt truyện hoàn tất! Nhận được Chân Ngôn Luân Hồi Kính — đủ điều kiện Trọng Sinh.');
        }
    }
}

function doScavenge() {
    // VÁ (mục #14): trước đây isDayPhase() tồn tại (đúng như comment gốc trong gameLoop.js
    // "dùng để bật Đánh Thường/loot") nhưng chưa từng được gọi — Càn Quét chơi được 24/7,
    // phá nhịp Ngày (Càn Quét/Đào Quặng) / Đêm (Thủ Thành) mà gameLoop.js mô tả.
    if (!isDayPhase(state.loopState)) {
        log('system', 'Ban đêm — Thú Triều đang vây Căn Cứ, không thể Càn Quét. Chờ trời sáng.');
        render();
        return;
    }
    const { level, stats, tier } = getActiveStats();
    const enemyTierKey = evolutionOrderToEnemyTier(tier.order);
    const enemy = generateEnemyStats(level, enemyTierKey);
    // VÁ (mục #14 nhỏ): logPlayerCommand() (combatLog.js) viết sẵn nhưng chưa từng được
    // gọi — thiếu 1 dòng flavor "Lệnh: ..." khi bấm nút. Giờ gọi ở đầu mỗi hành động thủ
    // công chính (Càn Quét/Boss/Ulti/Cường Hóa/Đột Phá/Trọng Sinh).
    logPlayerCommand(state.logBuffer, `Càn Quét (${getCharacter(state.activeChar).name})`);
    // VÁ (mục #12): trước đây log không bao giờ nói đang đánh con gì — giờ gọi tên thật từ
    // ENEMY_CODEX (nhánh đúng theo nhân vật đang chơi).
    log('system', `Chạm trán: ${getEnemyName(state.activeChar, enemyTierKey)}.`);
    // VÁ #18: trước đây gọi thẳng normalScavenge() và win luôn = true — giờ dùng
    // runScavengeExchange() (mô phỏng 2 chiều thật, xem chú thích tại định nghĩa hàm).
    const result = runScavengeExchange(stats, enemy);
    logNormalScavenge(state.logBuffer, result);
    if (!result.win) {
        log('dmg', `${getCharacter(state.activeChar).name} bị đánh lui trước ${getEnemyName(state.activeChar, enemyTierKey)} — quái còn ${fmt(result.enemyHpRemaining)} HP. Không nhận được gì.`);
    }
    if (result.win) {
        const branchId = BREAKTHROUGH_MATERIAL_BRANCH[state.activeChar];
        // VÁ (mục #14): trước đây gọi cứng dropMaterialWithRadar(branchId, 0) — Trạm Radar
        // Trinh Sát (baseExpansion.js) tồn tại trong idleLoot.js nhưng không có công trình
        // Căn Cứ nào để nâng cấp, radarLevel luôn = 0 vĩnh viễn. Giờ đọc cấp thật từ
        // state.baseLevels.TRAM_RADAR_TRINH_SAT (công trình mới, nâng qua doUpgradeBase()
        // như 3 công trình Căn Cứ còn lại).
        const radarLevel = state.baseLevels.TRAM_RADAR_TRINH_SAT ?? 0;
        const drop = dropMaterialWithRadar(branchId, radarLevel);
        state.materials[drop.name] = (state.materials[drop.name] || 0) + 1;
        const lootThisTurn = { [drop.name]: 1 };

        // VÁ (mục #14): rebirthPrestige.js ghi rõ TAB12 áp buff Trọng Sinh lên 4 thứ (Chỉ số
        // gốc, Sát thương, Tốc độ rớt đồ, Độ bền Căn cứ) qua applyRebirthBuff() — hàm này
        // được viết sẵn nhưng chưa từng được gọi, "Tốc độ rớt đồ" không hề tăng theo số lần
        // Trọng Sinh. GIẢ ĐỊNH (GDD không cho công thức cụ thể): dropMaterialWithRadar chỉ
        // rớt đúng 1 đơn vị/lần thắng nên không thể "nhân" trực tiếp — diễn dịch "tốc độ" là
        // % cơ hội rớt thêm 1 đơn vị vật liệu vừa nhận, bằng đúng phần buff vượt quá 100%
        // (ví dụ Trọng Sinh 20 lần = +20% => 20% cơ hội rớt gấp đôi vật liệu đó).
        const dropRateMult = applyRebirthBuff(
            { baseStats: 0, damage: 0, dropRate: 1, baseDurability: 0 },
            state.rebirthCount
        ).dropRate;
        const bonusChance = dropRateMult - 1;
        if (bonusChance > 0 && Math.random() < bonusChance) {
            state.materials[drop.name] += 1;
            lootThisTurn[drop.name] += 1;
        }

        // GIẢ ĐỊNH glue (xem ghi chú #5): 40% rớt thêm 1-3 đơn vị nguyên liệu công thức
        // 'normal' của nhân vật hiện tại, để hệ Chế Tạo có đường vào chơi được thật.
        if (Math.random() < 0.4) {
            const normalRecipes = getRecipesFor(state.activeChar).filter(r => r.grade === 'normal');
            const recipe = normalRecipes[Math.floor(Math.random() * normalRecipes.length)];
            const ingredientNames = Object.keys(recipe.ingredients);
            const matName = ingredientNames[Math.floor(Math.random() * ingredientNames.length)];
            const qty = 1 + Math.floor(Math.random() * 3);
            state.materials[matName] = (state.materials[matName] || 0) + qty;
            lootThisTurn[matName] = qty;
        }

        logLootCollected(state.logBuffer, lootThisTurn);
        addCurrency(state.wallet, 'PHE_LIEU_SAT', 5 + level);
        // VÁ #21 (2/3): 3% cơ hội rớt 1 Tinh Thể Biến Dị mỗi lần Càn Quét thắng — nguồn phụ nhỏ
        // giọt, không thay thế Boss SSS (vẫn 1/thắng chắc chắn) mà chỉ tránh kẹt cứng hoàn toàn.
        if (Math.random() < 0.03) {
            addCurrency(state.wallet, 'TINH_THE_BIEN_DI', 1);
            log('loot', 'Rớt hiếm: +1 Tinh Thể Biến Dị!');
        }
        addReputation(state.reputation, CHARACTER_FACTION_MAP[state.activeChar], 5);
        state.killCounts[state.activeChar]++;
        advanceQuestProgress(state.activeChar); // VÁ #24
        checkLevelUp(state.activeChar);
    }
    render();
}

function autoNightDefense() {
    const { level, tier } = getActiveStats();
    const enemyTierKey = evolutionOrderToEnemyTier(tier.order);
    const mult = TIER_ENEMY_MULTIPLIER[enemyTierKey] ?? 1;
    let waves = [1, 2, 3].map(w => ({
        count: Math.round(5 * w * mult),
        dmgPerEnemy: Math.round(2 * mult)
    }));

    // VÁ (mục #11): trước đây trận pháp bị hardcode cấp 3 vĩnh viễn, không đọc Căn Cứ thật.
    // Giờ dùng cấp thật của công trình Trận Pháp Hộ Thành (0-10, nâng qua doUpgradeBase).
    const tranPhapLevel = state.baseLevels.TRAN_PHAP_HO_THANH;
    const baseMitigation = getTranPhapMitigation(tranPhapLevel); // 20%→40% nội suy theo cấp
    const extraShield = getVirtualShieldBonus(tranPhapLevel); // +5%/cấp giáp ảo cộng thêm
    const mitigation = Math.min(0.9, 1 - (1 - baseMitigation) * (1 - extraShield));

    // VÁ: Tháp Súng Canh Gác giờ thật sự bắn hạ bớt quái trước khi chúng gây dmg — trước đây
    // isTurretActive()/getTurretShotsFired() không được gọi ở đâu cả trong toàn bộ build.
    const turretLevel = state.baseLevels.TURRET_CANH_GAC;
    if (turretLevel > 0 && isTurretActive(true)) {
        let shotsLeft = getTurretShotsFired(PHASES.NIGHT.durationSeconds) * turretLevel;
        waves = waves.map(w => {
            const share = Math.min(w.count - 1, Math.floor(shotsLeft / waves.length));
            shotsLeft -= share;
            return { ...w, count: Math.max(1, w.count - share) };
        });
    }

    // VÁ (mục #14): "Độ bền Căn cứ" là 1/4 mục TAB12 hứa áp buff Trọng Sinh nhưng
    // applyRebirthBuff() chưa từng được gọi — baseHp không hề tăng theo số lần Trọng Sinh.
    const rawBaseHp = 500 + level * 20;
    const baseHp = Math.round(applyRebirthBuff(
        { baseStats: 0, damage: 0, dropRate: 0, baseDurability: rawBaseHp },
        state.rebirthCount
    ).baseDurability);
    const result = runHordeDefense(baseHp, waves, mitigation);
    logHordeDefense(state.logBuffer, result);

    // VÁ (mục #15): baseSupport.js có "Rào Chắn Bọc Thép Sát Độc" (owner A_Tun) mô tả tự
    // động gom vật liệu rớt ra sau mỗi wave Thú Triều (autoCollectFromWave()) — hàm này chưa
    // từng được gọi, và sâu hơn: runHordeDefense() (combat.js) không hề sinh dữ liệu rớt đồ
    // cho wave nào cả — Thủ Thành trước đây là hành động DUY NHẤT trong game không có phần
    // thưởng vật chất, chỉ +8 danh vọng nếu sống sót. GIẢ ĐỊNH (GDD không cho công thức cụ
    // thể): mỗi wave đã xử lý (kể cả khi Căn Cứ cuối cùng gục ngã) rớt 1 đơn vị vật liệu —
    // dùng chung branch nhân vật đang hoạt động + cấp Trạm Radar hiện tại như Càn Quét — rồi
    // autoCollectFromWave() gộp lại thành 1 object tổng trước khi cộng vào kho.
    const branchId = BREAKTHROUGH_MATERIAL_BRANCH[state.activeChar];
    const radarLevel = state.baseLevels.TRAM_RADAR_TRINH_SAT ?? 0;
    const waveDrops = result.log.map(() => {
        const drop = dropMaterialWithRadar(branchId, radarLevel);
        return { name: drop.name, qty: 1 };
    });
    const collected = autoCollectFromWave(waveDrops);
    for (const [mat, qty] of Object.entries(collected)) {
        state.materials[mat] = (state.materials[mat] || 0) + qty;
    }
    logLootCollected(state.logBuffer, collected);

    if (result.survived) {
        addReputation(state.reputation, CHARACTER_FACTION_MAP[state.activeChar], 8);
        // VÁ #21 (2/3): cùng nguồn phụ Tinh Thể Biến Dị như Càn Quét, áp dụng khi sống sót qua đêm.
        if (Math.random() < 0.03) {
            addCurrency(state.wallet, 'TINH_THE_BIEN_DI', 1);
            log('loot', 'Rớt hiếm: +1 Tinh Thể Biến Dị (Thủ Thành)!');
        }
    }
    render();
}

function doBossFight() {
    const { level, stats, tier } = getActiveStats();
    if (tier.order < 3) {
        log('system', 'Cần đạt Mốc Tiến Hóa 4 trở lên mới thách đấu Boss SSS.');
        render();
        return;
    }
    log('system', `Thách đấu: ${getEnemyName(state.activeChar, 'SSS')}.`); // VÁ #12
    logPlayerCommand(state.logBuffer, `Quyết Chiến Boss SSS (${getCharacter(state.activeChar).name})`); // VÁ #14 nhỏ
    const boss = { hp: 3000 + level * 60, armor: 200 + level * 3, resist: 0.2, castThreshold: 400 };
    const hitCount = 8;
    const hits = Array.from({ length: hitCount }, () => (stats.atk ?? 20) * (0.9 + Math.random() * 0.3));
    const result = runBossFight(boss, hits);
    logBossFight(state.logBuffer, result);
    if (result.win) {
        addCurrency(state.wallet, 'TINH_THE_BIEN_DI', 1);
        addReputation(state.reputation, CHARACTER_FACTION_MAP[state.activeChar], 50);
        advanceQuestProgress(state.activeChar); // VÁ #24

        // VÁ (mục #13): trước đây "Lõi Đồng Hóa" (bắt buộc 3 đơn vị để đột phá Mốc 5 Tối
        // Thượng — evolutionTiers.js) KHÔNG có bất kỳ nguồn rớt nào trong toàn build, khiến
        // đột phá mốc cuối/Ultimate Combo/Trọng Sinh KHÔNG THỂ đạt được. Gắn nguồn duy nhất
        // vào Boss SSS: 15% rớt 1 Lõi Đồng Hóa.
        if (Math.random() < 0.15) {
            addCurrency(state.wallet, 'LOI_DONG_HOA', 1);
            log('loot', 'Rớt hiếm: +1 Lõi Đồng Hóa!');
        }

        // VÁ: trước đây nguyên liệu công thức 'divine' (Chiến Hạm Lõi Cơ Khí, Bộ Giáp Bá
        // Chủ Vô Cực, Chân Ngôn Bảo Luân...) KHÔNG có bất kỳ nguồn rớt nào — không thể chế
        // tạo được trong toàn bộ bản build. Gắn nguồn duy nhất vào Boss SSS (nội dung khó
        // nhất trước Ultimate Combo): 50% rớt 1 đơn vị nguyên liệu ngẫu nhiên của 1 công
        // thức 'divine' thuộc nhân vật đang chơi.
        if (Math.random() < 0.5) {
            const divineRecipes = getRecipesFor(state.activeChar).filter(r => r.grade === 'divine');
            if (divineRecipes.length > 0) {
                const recipe = divineRecipes[Math.floor(Math.random() * divineRecipes.length)];
                const ingredientNames = Object.keys(recipe.ingredients);
                const matName = ingredientNames[Math.floor(Math.random() * ingredientNames.length)];
                state.materials[matName] = (state.materials[matName] || 0) + 1;
                logLootCollected(state.logBuffer, { [matName]: 1 });
            }
        }
    }
    render();
}

function doUltimateCombo() {
    const { level, stats, tier } = getActiveStats();
    if (tier.order < 4) {
        log('system', 'Chỉ nhân vật đã đạt Mốc Tối Thượng (5) mới tung được Combo Tuyệt Kỹ.');
        render();
        return;
    }
    // VÁ (mục #15): baseSupport.js mô tả "Lò Năng Lượng Tổng" cho phép tung Ulti miễn phí
    // mana cá nhân nếu còn Lõi Năng Lượng (canCastUltiFree()) — nhưng hàm này chưa từng
    // được gọi, và trước đó KHÔNG hề có chi phí mana/năng lượng nào cho Combo Tuyệt Kỹ ở bất
    // kỳ đâu trong code (Ulti hoàn toàn miễn phí tuyệt đối). GIẢ ĐỊNH tự soạn (GDD không cho
    // công thức cụ thể, cần bạn xác nhận): gán chi phí 1 Tinh Thể Biến Dị/lần tung Ulti —
    // đúng loại currency Boss SSS rớt ra, tạo vòng lặp "cày Boss để đủ tài nguyên tung Ulti"
    // — Lò Năng Lượng Tổng (công trình Căn Cứ mới, xây 1 lần) miễn hẳn chi phí này.
    const hasEnergyCore = (state.baseLevels.LO_NANG_LUONG_TONG ?? 0) > 0;
    const ULTI_ENERGY_COST = { TINH_THE_BIEN_DI: 1 };
    if (!canCastUltiFree(hasEnergyCore)) {
        if (!canAfford(state.wallet, ULTI_ENERGY_COST)) {
            log('system', 'Cần 1 Tinh Thể Biến Dị để tung Combo Tuyệt Kỹ (hoặc xây Lò Năng Lượng Tổng ở Căn Cứ để miễn phí vĩnh viễn).');
            render();
            return;
        }
        spendCurrency(state.wallet, ULTI_ENERGY_COST);
    }
    // VÁ (mục #12): Cổ Hội (Thời Gian Đạo Tổ) là trùm cuối cố định theo cốt truyện (story.js
    // Chương V), không đổi theo nhân vật — dùng thẳng tên tier SSS nhánh Tiên Hiệp.
    logPlayerCommand(state.logBuffer, `Combo Tuyệt Kỹ (${getCharacter(state.activeChar).name})`); // VÁ #14 nhỏ
    log('system', `Đối đầu: ${ENEMY_CODEX.SSS.PHAM_NHAN_TU_TIEN}.`);
    const boss = { hp: 5000 + level * 80, armor: 300, resist: 0.25 };
    const result = runUltimateCombo(boss, stats.atk ?? 20);
    logUltimateCombo(state.logBuffer, result);

    // VÁ: Ultimate Combo (nội dung khó nhất, cần cả 3 Main ở Mốc Tối Thượng) trước đây
    // không cho phần thưởng nào cả — thắng xong tay trắng. Thêm phần thưởng tương xứng
    // độ khó: nhiều Tinh Thể Biến Dị + danh vọng + đảm bảo 1 nguyên liệu divine.
    if (result.win) {
        addCurrency(state.wallet, 'TINH_THE_BIEN_DI', 3);
        addReputation(state.reputation, CHARACTER_FACTION_MAP[state.activeChar], 100);
        advanceQuestProgress(state.activeChar); // VÁ #24
        const divineRecipes = getRecipesFor(state.activeChar).filter(r => r.grade === 'divine');
        if (divineRecipes.length > 0) {
            const recipe = divineRecipes[Math.floor(Math.random() * divineRecipes.length)];
            const ingredientNames = Object.keys(recipe.ingredients);
            const matName = ingredientNames[Math.floor(Math.random() * ingredientNames.length)];
            state.materials[matName] = (state.materials[matName] || 0) + 1;
            logLootCollected(state.logBuffer, { [matName]: 1 });
        }
    }
    render();
}

function doEnhance() {
    if (state.weaponEnhanceLevel >= MAX_ENHANCE_LEVEL) {
        log('system', 'Vũ khí đã đạt cấp cường hóa tối đa +10.');
        render();
        return;
    }
    const result = attemptEnhance(state.weaponEnhanceLevel, false);
    logPlayerCommand(state.logBuffer, `Cường Hóa Vũ Khí (+${state.weaponEnhanceLevel} → +${state.weaponEnhanceLevel + 1})`); // VÁ #14 nhỏ
    state.weaponEnhanceLevel = result.newLevel;
    if (result.success) {
        log('effect', `Cường hóa THÀNH CÔNG! Vũ khí +${result.newLevel}${result.hiddenLineUnlocked ? ' (mở khóa dòng ẩn!)' : ''}`);
    } else {
        log('dmg', result.broken ? 'Cường hóa THẤT BẠI — vũ khí vỡ, về +0.' : 'Cường hóa thất bại.');
    }
    render();
}

// VÁ #17: canBreakthrough()/performBreakthrough() (evolutionTiers.js) suy ra "mốc kế tiếp cần
// đột phá" bằng getNextTier(charId, state.level) — tức THUẦN từ level hiện tại. Điều đó đúng
// khi tier luôn == level-tier (bug cũ), nhưng giờ tier thật đã tách khỏi level (VÁ #17 ở
// getActiveStats()), nên nếu người chơi lỡ cày vượt quá 1 mốc mà CHƯA đột phá (vd Lv85 nhưng
// mới đột phá tới mốc order 1), gọi thẳng 2 hàm gốc đó sẽ tính sai "mốc kế tiếp" (suy ra từ
// tier theo level, tức order cao hơn thực tế) hoặc báo nhầm "đã tối đa". Vì vậy hàm dưới đây
// nhắm THẲNG vào breakthroughTiers[charId]+1 và tự kiểm tra điều kiện bằng
// getBreakthroughRequirement(charId, order) — hàm gốc này nhận order tường minh nên không bị
// lỗi đó. Không sửa evolutionTiers.js (giữ nguyên module core, chỉ thêm glue ở main.js).
function canBreakthroughToTier(charId, targetOrder, level) {
    const tiers = EVOLUTION_TIERS[charId];
    const targetTier = tiers.find(t => t.order === targetOrder);
    if (!targetTier) return { ok: false, reason: 'Đã ở mốc tối đa (Lv100).' };
    const req = getBreakthroughRequirement(charId, targetOrder);
    if (!req) return { ok: false, reason: 'Mốc kế tiếp không có điều kiện đột phá.' };
    if (level < req.requiredLevel) {
        return { ok: false, reason: `Cần đạt Lv${req.requiredLevel}.` };
    }
    if (!state.completedQuests.has(req.quest)) {
        return { ok: false, reason: `Chưa hoàn thành nhiệm vụ: ${req.quest}.` };
    }
    const materialName = getMaterialName(req.materialBranch, req.materialTierIndex);
    const haveMaterial = state.materials[materialName] || 0;
    if (haveMaterial < req.materialQty) {
        return { ok: false, reason: `Thiếu ${req.materialQty - haveMaterial} ${materialName}.` };
    }
    if (req.extraCurrency) {
        const have = state.wallet[req.extraCurrency.id] || 0;
        if (have < req.extraCurrency.qty) {
            return { ok: false, reason: `Thiếu ${req.extraCurrency.qty - have} ${req.extraCurrency.id}.` };
        }
    }
    return { ok: true, requirement: req, tier: targetTier };
}

function doBreakthrough() {
    const charId = state.activeChar;
    const level = state.charLevels[charId];
    logPlayerCommand(state.logBuffer, `Đột Phá (${getCharacter(charId).name})`); // VÁ #14 nhỏ
    const unlockedOrder = state.breakthroughTiers[charId] ?? 0;
    const targetOrder = unlockedOrder + 1;
    // VÁ #20 (crash thật, tự phát hiện khi rà lại VÁ #17): getBreakthroughRequirement() ném
    // Exception nếu targetOrder không tồn tại (evolutionTiers.js dòng ~97: `if (!tier) throw
    // new Error(...)`), vì nó không tự kiểm tra biên như canBreakthroughToTier() bên dưới. Một
    // nhân vật đã đột phá hết 4 lần (unlockedOrder=4, mốc tối đa) mà bấm Đột Phá lần nữa sẽ có
    // targetOrder=5 — gọi thẳng getBreakthroughRequirement(charId, 5) ở đây (TRƯỚC dòng gọi
    // canBreakthroughToTier có kiểm tra biên) sẽ CRASH luôn nút bấm, không có log báo lỗi nào
    // cả. Xác nhận bằng chạy thật: getBreakthroughRequirement('A_TUN', 5) ném
    // "Không tìm thấy mốc 5 cho nhân vật A_TUN". ĐÃ VÁ: kiểm tra mốc tồn tại trước khi gọi.
    const targetTierExists = EVOLUTION_TIERS[charId].some(t => t.order === targetOrder);
    const req = targetTierExists ? getBreakthroughRequirement(charId, targetOrder) : null;
    // VÁ #24: KHÔNG còn tự đánh dấu "hoàn thành" nhiệm vụ ở đây — giờ nhiệm vụ chỉ hoàn thành
    // thật sự qua advanceQuestProgress() (đủ QUEST_TARGET_WINS trận thắng), gọi ở doScavenge/
    // doBossFight/doUltimateCombo. Nút Đột Phá giờ chỉ KIỂM TRA, không tự cấp qua nhiệm vụ nữa.
    const check = canBreakthroughToTier(charId, targetOrder, level);
    if (check.ok) {
        const materialName = getMaterialName(check.requirement.materialBranch, check.requirement.materialTierIndex);
        state.materials[materialName] -= check.requirement.materialQty;
        if (check.requirement.extraCurrency) {
            state.wallet[check.requirement.extraCurrency.id] -= check.requirement.extraCurrency.qty;
        }
        // VÁ #17: đây là dòng thật sự "ghi lại" việc đột phá — trước đây không tồn tại ở đâu
        // cả, nên nút Đột Phá chỉ trừ nguyên liệu + in log chúc mừng suông.
        state.breakthroughTiers[charId] = targetOrder;
        log('effect', `${getCharacter(charId).name} ĐỘT PHÁ thành công lên "${check.tier.name}"!`);
    } else {
        log('system', `Chưa thể đột phá: ${check.reason}`);
    }
    render();
}

// ---------------------------------------------------------------------------
// TRANG BỊ & CHẾ TẠO
// ---------------------------------------------------------------------------
function doCraftAndEquip(recipeId) {
    const charId = state.activeChar;
    if (!canCraft(recipeId, state.materials)) {
        log('system', 'Chưa đủ nguyên liệu để chế tạo món này.');
        render();
        return;
    }
    const recipe = craft(recipeId, state.materials);
    const slotName = RECIPE_SLOT_MAP[recipeId];
    const item = {
        id: recipe.id,
        name: recipe.name,
        grade: recipe.grade,
        rarityTier: RECIPE_RARITY[recipe.grade] ?? 1
    };
    const old = equip(charId, state.loadouts[charId], slotName, item);
    log('effect', `Chế tạo & trang bị "${recipe.name}" vào ô [${slotName}]${old[slotName] ? ` (thay thế "${old[slotName].name}")` : ''}.`);
    render();
}

function doUnequip(slotName) {
    const charId = state.activeChar;
    const removed = unequip(state.loadouts[charId], slotName);
    if (removed) log('system', `Đã gỡ "${removed.name}" khỏi ô [${slotName}].`);
    render();
}

// ---------------------------------------------------------------------------
// CĂN CỨ (VÁ mục #11 — nối baseExpansion.js vào game, xem ghi chú đầu file)
// ---------------------------------------------------------------------------
function doUpgradeBase(structureId) {
    if (!BASE_STRUCTURES[structureId]) return;
    const level = state.baseLevels[structureId] ?? 0;
    if (level >= MAX_BASE_STRUCTURE_LEVEL) {
        log('system', `${BASE_STRUCTURES[structureId].name} đã đạt cấp tối đa (${MAX_BASE_STRUCTURE_LEVEL}).`);
        render();
        return;
    }
    const cost = { PHE_LIEU_SAT: (level + 1) * BASE_UPGRADE_COST_PER_LEVEL };
    if (!canAfford(state.wallet, cost)) {
        log('system', `Cần ${cost.PHE_LIEU_SAT} Phế Liệu Sắt để nâng cấp ${BASE_STRUCTURES[structureId].name} lên cấp ${level + 1}.`);
        render();
        return;
    }
    spendCurrency(state.wallet, cost);
    state.baseLevels[structureId] = level + 1;
    log('effect', `🏗️ ${BASE_STRUCTURES[structureId].name} nâng lên cấp ${level + 1}.`);
    render();
}

/** Xưởng Phân Rã & Tái Chế: gỡ 1 item đã trang bị, hoàn 70% nguyên liệu công thức gốc. */
function doRecycleSlot(slotName) {
    if ((state.baseLevels.XUONG_PHAN_RA_TAI_CHE ?? 0) < 1) {
        log('system', 'Cần xây Xưởng Phân Rã & Tái Chế (Căn Cứ) trước khi tái chế.');
        render();
        return;
    }
    const charId = state.activeChar;
    const item = state.loadouts[charId][slotName];
    if (!item) {
        log('system', 'Ô trang bị này đang trống, không có gì để tái chế.');
        render();
        return;
    }
    const recipeList = RECIPES[charId] || [];
    const recipe = recipeList.find(r => r.id === item.id);
    if (!recipe) {
        log('system', `Không tìm thấy công thức gốc của "${item.name}" để tái chế.`);
        render();
        return;
    }
    const recovered = recycleItem(recipe.ingredients);
    for (const [mat, qty] of Object.entries(recovered)) {
        if (qty > 0) state.materials[mat] = (state.materials[mat] || 0) + qty;
    }
    unequip(state.loadouts[charId], slotName);
    logLootCollected(state.logBuffer, recovered);
    log('system', `♻️ Đã tái chế "${item.name}" (${BASE_STRUCTURES.XUONG_PHAN_RA_TAI_CHE.recycleRate * 100}% nguyên liệu).`);
    render();
}

// ---------------------------------------------------------------------------
// CHỢ ĐEN (VÁ mục #13 — xem ghi chú đầu file: nội dung tự soạn vì GDD không định nghĩa)
// ---------------------------------------------------------------------------
function isBlackMarketUnlocked() {
    return FACTION_IDS.some(fid => hasBlackMarketAccess(state.reputation[fid]));
}

function doBuyBlackMarket(itemId) {
    if (!isBlackMarketUnlocked()) {
        log('system', 'Cần ít nhất 1 phe đạt bậc Huyền Thoại mới mở được Chợ Đen.');
        render();
        return;
    }
    const item = BLACK_MARKET_ITEMS.find(i => i.id === itemId);
    if (!item) return;
    if (!canAfford(state.wallet, item.cost)) {
        const costText = Object.entries(item.cost).map(([id, qty]) => `${qty} ${CURRENCIES[id].name}`).join(', ');
        log('system', `Chưa đủ tiền: cần ${costText}.`);
        render();
        return;
    }
    spendCurrency(state.wallet, item.cost);
    const gained = item.effect(state.activeChar);
    if (Object.keys(gained).length > 0) logLootCollected(state.logBuffer, gained);
    log('effect', `🖤 Chợ Đen: đã đổi "${item.name}".`);
    render();
}

// ---------------------------------------------------------------------------
// LƯU / TẢI GAME (localStorage — xem ghi chú #6)
// ---------------------------------------------------------------------------
function saveGame() {
    try {
        const payload = {
            activeChar: state.activeChar,
            charLevels: state.charLevels,
            killCounts: state.killCounts,
            wallet: state.wallet,
            materials: state.materials,
            weaponEnhanceLevel: state.weaponEnhanceLevel,
            reputation: state.reputation,
            loopState: state.loopState,
            completedQuests: Array.from(state.completedQuests),
            questProgress: state.questProgress, // VÁ #24
            breakthroughTiers: state.breakthroughTiers, // VÁ #17
            rebirthCount: state.rebirthCount,
            luanHoiKinhCount: state.luanHoiKinhCount,
            baseLevels: state.baseLevels,
            loadouts: state.loadouts,
            savedAt: Date.now()
        };
        localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
        return true;
    } catch (e) {
        console.error('Lưu game thất bại:', e);
        return false;
    }
}

function loadGame() {
    let raw;
    try {
        raw = localStorage.getItem(SAVE_KEY);
    } catch (e) {
        return false;
    }
    if (!raw) return false;
    try {
        const payload = JSON.parse(raw);
        Object.assign(state.charLevels, payload.charLevels);
        Object.assign(state.killCounts, payload.killCounts);
        Object.assign(state.wallet, payload.wallet);
        state.materials = payload.materials || {};
        state.weaponEnhanceLevel = payload.weaponEnhanceLevel || 0;
        Object.assign(state.reputation, payload.reputation);
        if (payload.loopState) Object.assign(state.loopState, payload.loopState);
        state.completedQuests = new Set(payload.completedQuests || []);
        state.questProgress = payload.questProgress || {}; // VÁ #24
        // VÁ #17: save cũ (trước bản vá) không có trường này — nếu thiếu, "cho nợ" người chơi
        // đúng mốc mà level cũ của họ đang hiện (dưới bug cũ họ ĐÃ được coi như ở mốc đó rồi,
        // dù chưa từng đột phá thật) để không đột ngột khóa lại nội dung đang chơi dở. Từ đây
        // về sau, muốn lên thêm mốc phải đột phá thật.
        if (payload.breakthroughTiers) {
            Object.assign(state.breakthroughTiers, payload.breakthroughTiers);
        } else if (payload.charLevels) {
            for (const charId of CHARACTER_IDS) {
                const lvl = payload.charLevels[charId] ?? 1;
                state.breakthroughTiers[charId] = getTierForLevel(charId, lvl).order;
            }
        }
        state.rebirthCount = payload.rebirthCount || 0;
        state.luanHoiKinhCount = payload.luanHoiKinhCount || 0;
        if (payload.baseLevels) Object.assign(state.baseLevels, payload.baseLevels);
        if (payload.loadouts) {
            for (const charId of CHARACTER_IDS) {
                const empty = createEmptyLoadout(charId);
                state.loadouts[charId] = Object.assign(empty, payload.loadouts[charId] || {});
            }
        }
        if (CHARACTER_IDS.includes(payload.activeChar)) state.activeChar = payload.activeChar;
        const awaySeconds = Math.max(0, Math.round((Date.now() - (payload.savedAt || Date.now())) / 1000));
        log('system', `Đã tải tiến trình đã lưu (vắng mặt ${Math.floor(awaySeconds / 60)} phút ${awaySeconds % 60}s).`);
        return true;
    } catch (e) {
        console.error('Tải game thất bại:', e);
        return false;
    }
}

function resetGame() {
    try { localStorage.removeItem(SAVE_KEY); } catch (e) { /* ignore */ }
    location.reload();
}

function doRebirth() {
    const fullState = {
        charLevels: state.charLevels,
        luanHoiKinhCount: state.luanHoiKinhCount,
        loadouts: state.loadouts,
        reputation: state.reputation,
        knownRecipeIds: state.knownRecipeIds || [],
        base: {},
        rebirthCount: state.rebirthCount
    };
    const check = canRebirth(fullState);
    if (!check.ok) {
        log('system', `Chưa thể Trọng Sinh: ${check.reason}`);
        render();
        return;
    }
    logPlayerCommand(state.logBuffer, 'Trọng Sinh Vô Cực'); // VÁ #14 nhỏ
    const result = performRebirth(fullState);
    if (!result.ok) {
        log('system', `Chưa thể Trọng Sinh: ${result.reason}`);
        render();
        return;
    }
    const s = result.state;
    state.charLevels = s.charLevels;
    state.loadouts = s.loadouts;
    state.reputation = s.reputation;
    state.knownRecipeIds = s.knownRecipeIds;
    state.luanHoiKinhCount = s.luanHoiKinhCount;
    state.rebirthCount = s.rebirthCount;
    // GIẢ ĐỊNH glue: performRebirth() không đề cập ví/vật liệu/nhiệm vụ/EXP — coi như thuộc
    // "Căn Cứ" (reset toàn bộ) vì đây là tiến trình theo-chu-kỳ, không phải tài sản vĩnh viễn.
    state.killCounts = { A_TUN: 0, BAO: 0, HAN_LAP: 0 };
    state.completedQuests = new Set();
    state.questProgress = {}; // VÁ #24
    state.breakthroughTiers = { A_TUN: 0, BAO: 0, HAN_LAP: 0 }; // VÁ #17: level về 1 thì mốc đột phá cũng phải về 0, không giữ lại
    state.wallet = createWallet();
    state.materials = {};
    state.weaponEnhanceLevel = 0;
    state.baseLevels = { TRAN_PHAP_HO_THANH: 0, TURRET_CANH_GAC: 0, XUONG_PHAN_RA_TAI_CHE: 0, TRAM_RADAR_TRINH_SAT: 0, LO_NANG_LUONG_TONG: 0 }; // VÁ #11, #14, #15
    const buffPct = ((getRebirthBuffMultiplier(state.rebirthCount) - 1) * 100).toFixed(0);
    log('effect', `🌀 TRỌNG SINH THÀNH CÔNG! (lần ${state.rebirthCount}) — vĩnh viễn +${buffPct}% chỉ số/sát thương/tốc độ rớt đồ/độ bền Căn cứ. Cấp độ & Căn Cứ đã reset, Danh Vọng & Công Thức giữ nguyên.`);
    render();
}

// VÁ #18: gộp logic "tick + xử lý chuyển pha" thành 1 hàm dùng chung cho cả vòng lặp
// 1s lẫn nút debug skipPhase() — trước đây skipPhase() chỉ dời mốc thời gian rồi render()
// ngay, khiến có đúng 1 khung hình hiển thị sai: nhãn pha cũ ("BAN NGÀY") nhưng đồng hồ đã
// nhảy về 00:00 (vì elapsed tính từ phaseStartedAt=0 là số rất lớn), do tickGameLoop() thật
// sự chưa chạy để lật state.loopState.phaseId — phải đợi tick 1s kế tiếp mới đúng.
function processTick() {
    const { changed } = tickGameLoop(state.loopState);
    if (changed) {
        if (isNightPhase(state.loopState)) {
            log('system', `Đêm buông xuống (Chu kỳ ${state.loopState.cycle}) — Thú Triều tấn công Căn Cứ!`);
            autoNightDefense();
        } else {
            log('system', `Ngày mới bắt đầu (Chu kỳ ${state.loopState.cycle}).`);
        }
    }
}

function skipPhase() {
    // Nút DEBUG: dời mốc bắt đầu pha hiện tại về quá khứ đủ xa rồi TỰ tick ngay lập tức
    // (không chờ setInterval 1s sau) — KHÔNG có trong thiết kế gốc, chỉ để test nhanh
    // (Ban Ngày 15 phút / Ban Đêm 5 phút thật là quá dài để demo tại chỗ).
    state.loopState.phaseStartedAt = 0;
    processTick();
    render();
}

// ---------------------------------------------------------------------------
// VÒNG LẶP GAME
// ---------------------------------------------------------------------------
setInterval(() => {
    processTick();
    render();
}, 1000);

setInterval(saveGame, 15000);
document.addEventListener('visibilitychange', () => { if (document.hidden) saveGame(); });
window.addEventListener('beforeunload', saveGame);

// ---------------------------------------------------------------------------
// RENDER
// ---------------------------------------------------------------------------
const el = (id) => document.getElementById(id);

function fmt(n) {
    return Math.round(n).toLocaleString('vi-VN');
}

function render() {
    const { level, stats, tier } = getActiveStats();
    const char = getCharacter(state.activeChar);

    // Tabs nhân vật
    for (const id of CHARACTER_IDS) {
        const btn = el(`tab-${id}`);
        btn.classList.toggle('active', id === state.activeChar);
        btn.querySelector('.tab-level').textContent = `Lv${state.charLevels[id]}`;
    }

    // Panel chỉ số
    el('char-name').textContent = char.name;
    el('char-branch').textContent = char.branch;
    el('char-tier').textContent = tier.name;
    el('char-level').textContent = `Level ${level}/100`;
    const needed = EXP_PER_LEVEL(level);
    const pct = level >= 100 ? 100 : Math.min(100, (state.killCounts[state.activeChar] / needed) * 100);
    el('exp-fill').style.width = `${pct}%`;
    el('exp-label').textContent = level >= 100 ? 'MAX' : `${state.killCounts[state.activeChar]}/${needed} quái`;

    const statLines = Object.entries(stats).map(([k, v]) => {
        const label = { hp: 'HP', atk: 'ATK', def: 'DEF', crit: 'Crit', mp: 'MP' }[k] || k;
        const value = k === 'crit' ? `${(v * 100).toFixed(1)}%` : fmt(v);
        return `<div class="stat"><span>${label}</span><b>${value}</b></div>`;
    }).join('');
    el('char-stats').innerHTML = statLines;

    // VÁ #17: chữ cũ "Đã ở mốc cao nhất hoặc đủ điều kiện đột phá" tự nó đã lộ ra sự mập mờ
    // của bug — 2 trạng thái rất khác nhau (max mốc / đã đủ level nhưng CHƯA bấm Đột Phá) bị
    // gộp làm 1 vì trước đây tier tự nhảy theo level nên "đủ điều kiện" == "đã ở mốc đó" luôn.
    // Giờ tách rõ 3 trạng thái dựa trên breakthroughTiers thật.
    const unlockedOrderForUi = state.breakthroughTiers[state.activeChar] ?? 0;
    const nextBreakthroughTier = EVOLUTION_TIERS[state.activeChar][unlockedOrderForUi + 1];
    // VÁ #25: BUG THẬT — untilNext trước đây gọi levelsUntilNextTier(charId, level), hàm này
    // tính khoảng cách tới mốc LEVEL-BRACKET kế tiếp (evolutionTiers.js LEVEL_RANGES, thuần
    // theo level hiện tại) chứ KHÔNG liên quan gì tới breakthroughTiers/unlockedOrderForUi
    // (mốc đã thật sự đột phá). Hệ quả: 1 người chơi Lv21 nhưng CHƯA đột phá mốc 2
    // (unlockedOrderForUi=0) đáng lẽ phải thấy "Đủ level — cần bấm Đột Phá", lại bị tính theo
    // level-bracket của chính Lv21 (đã lọt vào bracket mốc 2, 21-40) nên untilNext trả về
    // khoảng cách tới mốc 3 (Lv41) = 20, hiện nhầm "Còn 20 cấp tới mốc tiếp theo" dù thực ra
    // đã ĐỦ ĐIỀU KIỆN đột phá ngay bây giờ. ĐÃ VÁ: tính untilNext dựa thẳng vào minLevel của
    // nextBreakthroughTier (mốc player đang thực sự nhắm tới đột phá), không dùng
    // levelsUntilNextTier() nữa.
    const untilNext = nextBreakthroughTier ? Math.max(0, nextBreakthroughTier.minLevel - level) : 0;
    let tierNextText;
    if (untilNext > 0) {
        tierNextText = `Còn ${untilNext} cấp tới mốc tiếp theo`;
    } else if (nextBreakthroughTier) {
        // VÁ #24: trước đây chỉ nói "đủ level — bấm Đột Phá" dù nhiệm vụ thử thách thật ra
        // chưa xong (tự động hoàn thành ngầm lúc bấm nút, người chơi không hề thấy tiến độ
        // nào cả). Giờ hiện rõ tên nhiệm vụ + số trận đã thắng / cần thắng.
        const nextReq = getBreakthroughRequirement(state.activeChar, unlockedOrderForUi + 1);
        if (nextReq && !state.completedQuests.has(nextReq.quest)) {
            const progress = state.questProgress[nextReq.quest] ?? 0;
            tierNextText = `Đủ level — ${nextReq.quest}: ${progress}/${QUEST_TARGET_WINS} trận thắng`;
        } else {
            tierNextText = `Đủ điều kiện — cần bấm Đột Phá để lên "${nextBreakthroughTier.name}"`;
        }
    } else {
        tierNextText = 'Đã ở mốc cao nhất';
    }
    el('tier-next').textContent = tierNextText;

    // Pha ngày/đêm
    const night = isNightPhase(state.loopState);
    el('phase-badge').textContent = night ? '🌙 BAN ĐÊM — THỦ THÀNH' : '☀️ BAN NGÀY — CÀN QUÉT';
    el('phase-badge').className = `phase-badge ${night ? 'night' : 'day'}`;
    document.body.classList.toggle('phase-night', night);
    const remain = Math.max(0, Math.round(getRemainingInPhase(state.loopState)));
    const mm = String(Math.floor(remain / 60)).padStart(2, '0');
    const ss = String(remain % 60).padStart(2, '0');
    el('phase-timer').textContent = `${mm}:${ss}`;
    el('phase-fill').style.width = `${getPhaseProgress(state.loopState) * 100}%`;

    // Ví tiền tệ
    el('wallet-bar').innerHTML = Object.entries(state.wallet)
        .filter(([, v]) => v > 0)
        .map(([id, v]) => `<span class="chip" title="${CURRENCIES[id].desc}">${CURRENCIES[id].name}: ${fmt(v)}</span>`)
        .join('') || '<span class="chip dim">Chưa có tiền tệ nào</span>';

    // Vật liệu
    const materialEntries = Object.entries(state.materials).filter(([, v]) => v > 0);
    // VÁ (mục #16): tô màu chip theo tier thật (TIER_COLORS) thay vì 1 màu cố định cho mọi
    // vật liệu, để người chơi nhìn ra ngay vật liệu nào hiếm (Vàng) ngay từ thanh Vật Liệu.
    el('materials-bar').innerHTML = materialEntries.length
        ? materialEntries.map(([name, v]) => {
            const tierIdx = MATERIAL_TIER_INDEX[name] ?? 0;
            return `<span class="chip mat mat-tier${tierIdx}" title="Độ hiếm: ${TIER_COLORS[tierIdx]}">${name}: ${v}</span>`;
        }).join('')
        : '<span class="chip dim">Chưa có vật liệu nào</span>';

    // Vũ khí cường hóa
    el('enhance-level').textContent = `+${state.weaponEnhanceLevel}`;

    // Cốt truyện + danh vọng
    const chapter = getUnlockedChapterEffective(); // VÁ #19
    const nextChapter = getNextChapterEffective(); // VÁ #19
    el('story-chapter').textContent = chapter.name;
    el('story-summary').textContent = chapter.summary;
    el('story-next').textContent = nextChapter ? `Tiếp theo: ${nextChapter.name}` : 'Đã hoàn thành cốt truyện!';

    // VÁ (mục #16): getNextReputationTier() có sẵn nhưng chưa từng được gọi — UI trước đây
    // chỉ hiện bậc hiện tại, không hiện còn thiếu bao nhiêu điểm tới bậc Danh Vọng kế tiếp.
    el('reputation-bar').innerHTML = FACTION_IDS.map(fid => {
        const points = state.reputation[fid];
        const tierRep = getReputationTier(points);
        const next = getNextReputationTier(points);
        const progress = next ? ` (còn ${fmt(next.pointsNeeded)} tới ${next.tier.name})` : ' (Tối đa)';
        return `<span class="chip rep">${FACTIONS[fid].name}: ${tierRep.name}${progress}</span>`;
    }).join('');

    // Log chiến đấu
    const lines = renderAsLines(state.logBuffer);
    const logPanel = el('log-panel');
    logPanel.innerHTML = lines.map(l => `<div class="log-line" style="color:${l.color}">${escapeHtml(l.text)}</div>`).join('');
    logPanel.scrollTop = logPanel.scrollHeight;

    // Nút Boss/Ulti khóa theo mốc
    el('btn-boss').disabled = tier.order < 3;
    el('btn-ulti').disabled = tier.order < 4;
    // VÁ (mục #14): Càn Quét chỉ chơi được vào Ban Ngày, khớp nhịp Ngày/Đêm của gameLoop.js
    el('btn-scavenge').disabled = night;
    el('btn-scavenge').title = night ? 'Chỉ hoạt động vào Ban Ngày' : '';

    // Trang bị
    el('equip-char-name').textContent = char.name;
    const loadout = state.loadouts[state.activeChar];
    const canRecycle = (state.baseLevels.XUONG_PHAN_RA_TAI_CHE ?? 0) >= 1;
    el('equip-slots').innerHTML = EQUIPMENT_SLOTS[state.activeChar].map(slotName => {
        const item = loadout[slotName];
        return `<div class="equip-slot">
            <span class="slot-name">${slotName}</span>
            <span class="slot-item ${item ? 'filled ' + item.grade : 'empty'}">${item ? item.name : 'Trống'}</span>
            ${item ? `<button class="unequip-btn" data-slot="${slotName}">Gỡ</button>` : ''}
            ${item && canRecycle ? `<button class="recycle-btn" data-slot="${slotName}" title="Hoàn 70% nguyên liệu">♻️</button>` : ''}
        </div>`;
    }).join('');
    el('equip-slots').querySelectorAll('.unequip-btn').forEach(btn => {
        btn.addEventListener('click', () => doUnequip(btn.dataset.slot));
    });
    el('equip-slots').querySelectorAll('.recycle-btn').forEach(btn => {
        btn.addEventListener('click', () => doRecycleSlot(btn.dataset.slot));
    });

    // VÁ (mục #11): panel Căn Cứ — trước đây baseExpansion.js không nối vào UI ở đâu cả.
    el('base-list').innerHTML = Object.values(BASE_STRUCTURES).map(structure => {
        const level = state.baseLevels[structure.id] ?? 0;
        const maxed = level >= MAX_BASE_STRUCTURE_LEVEL;
        const cost = (level + 1) * BASE_UPGRADE_COST_PER_LEVEL;
        const canPay = canAfford(state.wallet, { PHE_LIEU_SAT: cost });
        let effectLine = '';
        if (structure.id === 'TRAN_PHAP_HO_THANH') {
            effectLine = `Giáp ảo phòng thủ đêm: +${(getVirtualShieldBonus(level) * 100).toFixed(0)}%`;
        } else if (structure.id === 'TURRET_CANH_GAC') {
            effectLine = level > 0 ? `Tự động hạ bớt quái mỗi đêm (${level} tháp)` : 'Chưa xây — không có turret nào bắn';
        } else if (structure.id === 'XUONG_PHAN_RA_TAI_CHE') {
            effectLine = level > 0 ? `Tái chế đồ trang bị: hoàn ${(structure.recycleRate * 100).toFixed(0)}% nguyên liệu` : 'Chưa xây — không thể tái chế đồ';
        } else if (structure.id === 'TRAM_RADAR_TRINH_SAT') {
            effectLine = `Tỉ lệ rớt vật liệu tier Vàng khi Càn Quét: ${(getGoldDropChance(level) * 100).toFixed(1)}%`;
        } else if (structure.id === 'LO_NANG_LUONG_TONG') {
            effectLine = level > 0 ? 'Combo Tuyệt Kỹ MIỄN PHÍ (không tốn Tinh Thể Biến Dị)' : 'Chưa xây — Combo Tuyệt Kỹ tốn 1 Tinh Thể Biến Dị/lần';
        }
        return `<div class="craft-row">
            <div class="craft-name">${structure.name} <span class="grade-normal">[Cấp ${level}/${MAX_BASE_STRUCTURE_LEVEL}]</span></div>
            <div class="craft-ingredients">${effectLine}</div>
            <button class="craft-btn" data-structure="${structure.id}" ${maxed || !canPay ? 'disabled' : ''}>
                ${maxed ? 'Đã tối đa' : `Nâng Cấp (${cost} Phế Liệu Sắt)`}
            </button>
        </div>`;
    }).join('');
    el('base-list').querySelectorAll('.craft-btn').forEach(btn => {
        btn.addEventListener('click', () => doUpgradeBase(btn.dataset.structure));
    });

    // VÁ (mục #13): panel Chợ Đen — mở khi 1 phe đạt Huyền Thoại.
    const bmUnlocked = isBlackMarketUnlocked();
    el('black-market-status').textContent = bmUnlocked
        ? 'Đã mở khóa — cần Huyền Thoại 1 phe bất kỳ.'
        : 'KHÓA — cần 1 phe đạt bậc Huyền Thoại (20.000 danh vọng).';
    el('black-market-list').innerHTML = BLACK_MARKET_ITEMS.map(item => {
        const costText = Object.entries(item.cost).map(([id, qty]) => `${qty} ${CURRENCIES[id].name}`).join(', ');
        const canPay = bmUnlocked && canAfford(state.wallet, item.cost);
        return `<div class="craft-row">
            <div class="craft-name">${item.name}</div>
            <div class="craft-ingredients">${item.desc}</div>
            <button class="craft-btn" data-item="${item.id}" ${canPay ? '' : 'disabled'}>Đổi (${costText})</button>
        </div>`;
    }).join('');
    el('black-market-list').querySelectorAll('.craft-btn').forEach(btn => {
        btn.addEventListener('click', () => doBuyBlackMarket(btn.dataset.item));
    });

    // Chế tạo
    el('craft-list').innerHTML = getRecipesFor(state.activeChar).map(recipe => {
        const has = canCraft(recipe.id, state.materials);
        const ingredientsHtml = Object.entries(recipe.ingredients).map(([mat, qty]) => {
            const have = state.materials[mat] || 0;
            return `<span class="${have >= qty ? 'ok' : 'missing'}">${mat} ${have}/${qty}</span>`;
        }).join(', ');
        return `<div class="craft-row">
            <div class="craft-name">${recipe.name} <span class="grade-${recipe.grade}">[${recipe.grade === 'divine' ? 'THẦN CẤP' : 'thường'}]</span></div>
            <div class="craft-ingredients">${ingredientsHtml}</div>
            <button class="craft-btn" data-recipe="${recipe.id}" ${has ? '' : 'disabled'}>Chế Tạo & Trang Bị</button>
        </div>`;
    }).join('');
    el('craft-list').querySelectorAll('.craft-btn').forEach(btn => {
        btn.addEventListener('click', () => doCraftAndEquip(btn.dataset.recipe));
    });

    // Kỹ năng đã mở khóa
    const skills = getUnlockedSkillsEffective(state.activeChar); // VÁ #19
    const typeLabel = { active: 'Chủ Động', passive: 'Bị Động', synergy: 'Phối Hợp', ulti: 'TUYỆT KỸ' };
    el('skill-list').innerHTML = skills.map(s =>
        `<span class="chip skill skill-${s.type}">[${typeLabel[s.type] || s.type}] ${s.name}</span>`
    ).join('');

    // Nút Trọng Sinh: khóa nếu chưa đủ điều kiện
    const rebirthCheck = canRebirth({
        charLevels: state.charLevels, luanHoiKinhCount: state.luanHoiKinhCount
    });
    el('btn-rebirth').disabled = !rebirthCheck.ok;
    el('btn-rebirth').title = rebirthCheck.ok ? 'Đủ điều kiện!' : rebirthCheck.reason;
    el('rebirth-info').textContent = `Đã Trọng Sinh: ${state.rebirthCount} lần | Chân Ngôn Luân Hồi Kính: ${state.luanHoiKinhCount}`;
}

function escapeHtml(str) {
    return str.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---------------------------------------------------------------------------
// WIRING SỰ KIỆN
// ---------------------------------------------------------------------------
for (const id of CHARACTER_IDS) {
    el(`tab-${id}`).addEventListener('click', () => { state.activeChar = id; render(); });
}
el('btn-scavenge').addEventListener('click', doScavenge);
el('btn-boss').addEventListener('click', doBossFight);
el('btn-ulti').addEventListener('click', doUltimateCombo);
el('btn-enhance').addEventListener('click', doEnhance);
el('btn-breakthrough').addEventListener('click', doBreakthrough);
el('btn-rebirth').addEventListener('click', doRebirth);
el('btn-skip-phase').addEventListener('click', skipPhase);
el('btn-save').addEventListener('click', () => { saveGame(); log('system', 'Đã lưu tiến trình thủ công.'); render(); });
el('btn-reset').addEventListener('click', () => {
    if (confirm('Xóa toàn bộ tiến trình đã lưu và chơi lại từ đầu?')) resetGame();
});

loadGame();
render();
